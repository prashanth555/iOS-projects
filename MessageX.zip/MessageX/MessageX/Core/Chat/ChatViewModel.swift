import Foundation
import Firebase
import SwiftUI
import UIKit
import PhotosUI
import AVFoundation
import UniformTypeIdentifiers

@MainActor
class ChatViewModel: ObservableObject {
    let chat: Chat
    @Published var messages: [Message] = []
    @Published var messageText = ""
    @Published var isLoading = true
    @Published var typingUsers: [String] = []
    @Published var replyingTo: Message?
    @Published var editingMessage: Message?
    @Published var isRecordingAudio = false
    @Published var audioProgress: Double = 0
    @Published var selectedMedia: [PhotosPickerItem] = []
    @Published var errorMessage: String?
    @Published var showError = false

    private var messageListener: ListenerRegistration?
    private var typingListener: ListenerRegistration?
    private var audioRecorder: AVAudioRecorder?
    private var audioRecordingURL: URL?
    private var typingTimer: Timer?

    init(chat: Chat) {
        self.chat = chat
        loadMessages()
        listenToTyping()
        markMessagesAsRead()
    }

    private func loadMessages() {
        messageListener = ChatService.shared.listenToMessages(chatId: chat.chatId) { [weak self] msgs in
            Task { @MainActor in
                self?.messages = msgs
                self?.isLoading = false
                self?.markMessagesAsRead()
            }
        }
    }

    private func listenToTyping() {
        guard let uid = AuthService.shared.currentUserId else { return }
        typingListener = ChatService.shared.listenToTyping(chatId: chat.chatId,
                                                           excludeUserId: uid) { [weak self] users in
            Task { @MainActor in self?.typingUsers = users }
        }
    }

    private func markMessagesAsRead() {
        guard let uid = AuthService.shared.currentUserId else { return }
        let unread = messages.filter { !$0.readBy.contains(uid) && !$0.isFromCurrentUser }
        guard !unread.isEmpty else { return }
        Task {
            try? await ChatService.shared.markAsRead(chatId: chat.chatId, userId: uid,
                                                      messageIds: unread.map { $0.messageId })
        }
    }

    // MARK: - Send Text
    func sendTextMessage() {
        guard let currentUser = AuthService.shared.currentUser,
              !messageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        var message = Message(chatId: chat.chatId, senderId: currentUser.uid,
                              senderName: currentUser.displayName,
                              content: messageText.trimmingCharacters(in: .whitespacesAndNewlines),
                              type: .text)
        if let reply = replyingTo {
            message.replyTo = Message.ReplyPreview(
                messageId: reply.messageId, senderId: reply.senderId,
                senderName: reply.senderName, content: reply.content,
                type: reply.type, mediaURL: reply.mediaData?.url
            )
        }
        messageText = ""
        replyingTo = nil
        stopTyping()

        Task {
            do {
                try await ChatService.shared.sendMessage(message)
                await sendPushIfNeeded(message: message)
            } catch { setError(error.localizedDescription) }
        }
    }

    // MARK: - Send Image
    func sendImage(_ image: UIImage) {
        guard let currentUser = AuthService.shared.currentUser else { return }
        Task {
            do {
                let mediaData = try await StorageService.shared.uploadImage(image, chatId: chat.chatId)
                var msg = Message(chatId: chat.chatId, senderId: currentUser.uid,
                                   senderName: currentUser.displayName, content: "📷 Photo", type: .image)
                msg.mediaData = mediaData
                try await ChatService.shared.sendMessage(msg)
            } catch { setError(error.localizedDescription) }
        }
    }

    // MARK: - Send Video
    func sendVideo(url: URL) {
        guard let currentUser = AuthService.shared.currentUser else { return }
        Task {
            do {
                let mediaData = try await StorageService.shared.uploadVideo(url: url, chatId: chat.chatId)
                var msg = Message(chatId: chat.chatId, senderId: currentUser.uid,
                                   senderName: currentUser.displayName, content: "🎥 Video", type: .video)
                msg.mediaData = mediaData
                try await ChatService.shared.sendMessage(msg)
            } catch { setError(error.localizedDescription) }
        }
    }

    // MARK: - Send Document/PDF
    func sendDocument(url: URL) {
        guard let currentUser = AuthService.shared.currentUser else { return }
        let isPDF = url.pathExtension.lowercased() == "pdf"
        Task {
            do {
                let mediaData = try await StorageService.shared.uploadDocument(url: url, chatId: chat.chatId)
                var msg = Message(chatId: chat.chatId, senderId: currentUser.uid,
                                   senderName: currentUser.displayName,
                                   content: isPDF ? "📋 PDF" : "📄 \(url.lastPathComponent)",
                                   type: isPDF ? .pdf : .document)
                msg.mediaData = mediaData
                try await ChatService.shared.sendMessage(msg)
            } catch { setError(error.localizedDescription) }
        }
    }

    // MARK: - Send GIF
    func sendGIF(url: String, width: Int, height: Int) {
        guard let currentUser = AuthService.shared.currentUser else { return }
        var msg = Message(chatId: chat.chatId, senderId: currentUser.uid,
                          senderName: currentUser.displayName, content: "GIF", type: .gif)
        msg.mediaData = Message.MediaData(url: url, width: width, height: height, mimeType: "image/gif")
        Task {
            do { try await ChatService.shared.sendMessage(msg) }
            catch { setError(error.localizedDescription) }
        }
    }

    // MARK: - Send Location
    func sendLocation(latitude: Double, longitude: Double) {
        guard let currentUser = AuthService.shared.currentUser else { return }
        let content = "\(latitude),\(longitude)"
        let msg = Message(chatId: chat.chatId, senderId: currentUser.uid,
                          senderName: currentUser.displayName, content: content, type: .location)
        Task {
            do { try await ChatService.shared.sendMessage(msg) }
            catch { setError(error.localizedDescription) }
        }
    }

    // MARK: - Voice Note
    func startRecording() {
        let settings: [String: Any] = [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: 44100,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(UUID().uuidString).m4a")
        audioRecordingURL = url
        try? AVAudioSession.sharedInstance().setCategory(.record, mode: .default)
        try? AVAudioSession.sharedInstance().setActive(true)
        audioRecorder = try? AVAudioRecorder(url: url, settings: settings)
        audioRecorder?.isMeteringEnabled = true
        audioRecorder?.record()
        isRecordingAudio = true
    }

    func stopRecording(send: Bool) {
        audioRecorder?.stop()
        isRecordingAudio = false
        guard send, let url = audioRecordingURL,
              let currentUser = AuthService.shared.currentUser else { return }
        Task {
            do {
                let duration = audioRecorder?.currentTime ?? 0
                var mediaData = try await StorageService.shared.uploadAudio(url: url, chatId: chat.chatId)
                mediaData.duration = duration
                var msg = Message(chatId: chat.chatId, senderId: currentUser.uid,
                                   senderName: currentUser.displayName,
                                   content: "🎤 Voice message", type: .voiceNote)
                msg.mediaData = mediaData
                try await ChatService.shared.sendMessage(msg)
                try? FileManager.default.removeItem(at: url)
            } catch { setError(error.localizedDescription) }
        }
    }

    // MARK: - Edit / Delete / React
    func editMessage(_ message: Message, newContent: String) {
        Task {
            do { try await ChatService.shared.editMessage(chatId: chat.chatId,
                                                           messageId: message.messageId,
                                                           newContent: newContent) }
            catch { setError(error.localizedDescription) }
        }
        editingMessage = nil
    }

    func deleteMessage(_ message: Message) {
        Task {
            do { try await ChatService.shared.deleteMessage(chatId: chat.chatId,
                                                             messageId: message.messageId) }
            catch { setError(error.localizedDescription) }
        }
    }

    func reactToMessage(_ message: Message, emoji: String) {
        guard let uid = AuthService.shared.currentUserId else { return }
        Task {
            do { try await ChatService.shared.addReaction(chatId: chat.chatId,
                                                           messageId: message.messageId,
                                                           emoji: emoji, userId: uid) }
            catch { setError(error.localizedDescription) }
        }
    }

    // MARK: - Typing
    func handleTyping() {
        guard let uid = AuthService.shared.currentUserId else { return }
        ChatService.shared.setTyping(true, chatId: chat.chatId, userId: uid)
        typingTimer?.invalidate()
        typingTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { [weak self] _ in
            self?.stopTyping()
        }
    }

    func stopTyping() {
        guard let uid = AuthService.shared.currentUserId else { return }
        ChatService.shared.setTyping(false, chatId: chat.chatId, userId: uid)
        typingTimer?.invalidate()
        typingTimer = nil
    }

    // MARK: - Push
    private func sendPushIfNeeded(message: Message) async {
        let otherParticipants = chat.participants.filter { $0 != message.senderId }
        for uid in otherParticipants {
            let isMuted = chat.mutedBy.contains(uid)
            if !isMuted {
                await NotificationService.shared.sendPushNotification(
                    to: uid,
                    title: message.senderName,
                    body: messagePreviewText(message),
                    data: ["chatId": chat.chatId, "type": "message"]
                )
            }
        }
    }

    private func messagePreviewText(_ message: Message) -> String {
        switch message.type {
        case .text: return message.content
        case .image: return "📷 Photo"
        case .video: return "🎥 Video"
        case .voiceNote: return "🎤 Voice message"
        case .gif: return "GIF"
        case .pdf: return "📋 PDF"
        case .document: return "📄 Document"
        default: return message.content
        }
    }

    private func setError(_ msg: String) {
        errorMessage = msg
        showError = true
    }

    var typingStatusText: String {
        switch typingUsers.count {
        case 0: return ""
        case 1: return "typing..."
        default: return "\(typingUsers.count) people typing..."
        }
    }

    var otherUser: MXUser? {
        guard chat.type == .individual,
              let uid = chat.participants.first(where: { $0 != AuthService.shared.currentUserId }),
              let info = chat.participantDetails[uid] else { return nil }
        var user = MXUser(uid: uid, phoneNumber: "", displayName: info.displayName)
        user.profileImageURL = info.profileImageURL
        user.isOnline = info.isOnline
        return user
    }

    deinit {
        messageListener?.remove()
        typingListener?.remove()
        typingTimer?.invalidate()
    }
}
