import Foundation
import SwiftUI
import Firebase
import Combine

@MainActor
class AuthViewModel: ObservableObject {
    @Published var currentUser: MXUser?
    @Published var isLoading = true
    @Published var isAuthenticated = false
    @Published var errorMessage: String?
    @Published var showError = false

    private let authService = AuthService.shared
    private var cancellables = Set<AnyCancellable>()

    init() {
        // Mirror auth state into this view model using explicit sink so Swift's
        // actor isolation checker is satisfied (assign(to:) on @MainActor published
        // properties can produce Sendable warnings in some toolchain versions).
        authService.$currentUser
            .receive(on: DispatchQueue.main)
            .sink { [weak self] user in self?.currentUser = user }
            .store(in: &cancellables)

        authService.$isAuthenticated
            .receive(on: DispatchQueue.main)
            .sink { [weak self] value in self?.isAuthenticated = value }
            .store(in: &cancellables)

        Task {
            // Brief yield so Firebase (configured in AppDelegate) is fully ready.
            try? await Task.sleep(nanoseconds: 300_000_000)
            self.currentUser = authService.currentUser
            self.isAuthenticated = authService.isAuthenticated
            self.isLoading = false
            await authService.updateOnlineStatus(isOnline: true)
        }
    }

    func refreshCurrentUser() {
        guard let uid = authService.currentUserId else { return }
        Task { await authService.fetchCurrentUser(uid: uid) }
    }

    func sendOTP(phoneNumber: String) async -> Bool {
        do {
            try await authService.sendOTP(to: phoneNumber)
            return true
        } catch {
            setError(error.localizedDescription)
            return false
        }
    }

    func verifyOTP(_ otp: String) async -> Bool {
        do {
            try await authService.verifyOTP(otp)
            await authService.updateOnlineStatus(isOnline: true)
            return true
        } catch {
            setError(error.localizedDescription)
            return false
        }
    }

    func signOut() {
        Task { await authService.updateOnlineStatus(isOnline: false) }
        try? authService.signOut()
    }

    func updateProfile(displayName: String, bio: String, imageURL: String?) async {
        do {
            try await authService.updateProfile(displayName: displayName, bio: bio, imageURL: imageURL)
        } catch {
            setError(error.localizedDescription)
        }
    }

    private func setError(_ message: String) {
        errorMessage = message
        showError = true
    }

    var isNewUser: Bool { currentUser?.displayName == currentUser?.phoneNumber }
}
