#!/bin/bash
# MessageX — Build Verification Script
# Runs on Mac. Generates the Xcode project, installs pods, then
# does a full xcodebuild compile targeting the iOS 17 simulator.
# No physical device needed. Firebase will not initialize (no .plist)
# but the app will compile successfully.
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

step() { echo -e "\n${GREEN}▶ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠ $1${NC}"; }
fail() { echo -e "${RED}✗ $1${NC}"; exit 1; }

# ── 1. Prerequisites ────────────────────────────────────────────────
step "Checking prerequisites"
command -v xcodebuild &>/dev/null || fail "Xcode command-line tools not found. Run: xcode-select --install"
command -v brew &>/dev/null       || fail "Homebrew not found. Install from https://brew.sh"

if ! command -v xcodegen &>/dev/null; then
    step "Installing XcodeGen"
    brew install xcodegen
fi

if ! command -v pod &>/dev/null; then
    step "Installing CocoaPods"
    sudo gem install cocoapods
fi

# ── 2. Place a stub GoogleService-Info.plist so the build succeeds ──
# Firebase reads this at runtime, not compile time, so a stub is fine.
PLIST_PATH="MessageX/Resources/GoogleService-Info.plist"
if [ ! -f "$PLIST_PATH" ]; then
    warn "GoogleService-Info.plist not found — creating stub so project compiles."
    warn "Replace it with the real file from Firebase Console before releasing."
    cat > "$PLIST_PATH" << 'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CLIENT_ID</key>          <string>000000000000-stub.apps.googleusercontent.com</string>
    <key>REVERSED_CLIENT_ID</key> <string>com.googleusercontent.apps.000000000000-stub</string>
    <key>BUNDLE_ID</key>          <string>com.messagex.app</string>
    <key>PROJECT_ID</key>         <string>messagex-stub</string>
    <key>STORAGE_BUCKET</key>     <string>messagex-stub.appspot.com</string>
    <key>GCM_SENDER_ID</key>      <string>000000000000</string>
    <key>GOOGLE_APP_ID</key>      <string>1:000000000000:ios:0000000000000000000000</string>
    <key>API_KEY</key>            <string>stub-key-replace-with-real-key</string>
    <key>IS_ADS_ENABLED</key>     <false/>
</dict>
</plist>
PLIST
fi

# ── 3. Generate .xcodeproj ──────────────────────────────────────────
step "Generating Xcode project (XcodeGen)"
xcodegen generate

# ── 4. Install pods ─────────────────────────────────────────────────
step "Installing CocoaPods dependencies"
pod install

# ── 5. Build for simulator ──────────────────────────────────────────
# Pick the first available iPhone 17-family simulator; fall back to any iPhone.
SIMULATOR=$(xcrun simctl list devices available -j \
    | python3 -c "
import sys, json
d = json.load(sys.stdin)
for runtime, devices in d.get('devices', {}).items():
    for dev in devices:
        if dev.get('isAvailable') and 'iPhone' in dev.get('name',''):
            print(dev['udid']); sys.exit(0)
" 2>/dev/null || echo "")

if [ -z "$SIMULATOR" ]; then
    DEST="generic/platform=iOS Simulator"
    warn "No specific simulator found — building for generic iOS Simulator."
else
    DEST="id=$SIMULATOR"
    echo "   Using simulator: $SIMULATOR"
fi

step "Building MessageX (xcodebuild — this may take a few minutes)"
xcodebuild \
    -workspace MessageX.xcworkspace \
    -scheme MessageX \
    -destination "$DEST" \
    -configuration Debug \
    CODE_SIGNING_ALLOWED=NO \
    | xcpretty --color --simple 2>/dev/null \
    || xcodebuild \
        -workspace MessageX.xcworkspace \
        -scheme MessageX \
        -destination "$DEST" \
        -configuration Debug \
        CODE_SIGNING_ALLOWED=NO

echo ""
echo -e "${GREEN}✓ Build succeeded!${NC}"
echo ""
echo "Next steps:"
echo "  1. Replace MessageX/Resources/GoogleService-Info.plist with the real one"
echo "     from your Firebase Console (console.firebase.google.com)"
echo "  2. Set your Development Team in Xcode → Signing & Capabilities"
echo "  3. Add your Giphy API key to Utilities/AppConfig.swift (optional, for GIFs)"
echo "  4. Deploy Cloud Functions:  cd functions && npm install && firebase deploy --only functions"
echo "  5. Open MessageX.xcworkspace and run on a real device"
echo ""
