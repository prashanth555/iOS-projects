#!/bin/bash
# Run this in Terminal on your Mac from the MessageX folder:
#   cd ~/Downloads/IOS\ projects/MessageX && bash fix_and_build.sh

set -euo pipefail
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

PROJECT="MessageX.xcodeproj"
SCHEME="MessageX"
PACKAGES="SourcePackages"

echo -e "${YELLOW}Step 1: Clearing DerivedData for MessageX...${NC}"
rm -rf ~/Library/Developer/Xcode/DerivedData/MessageX-*
echo "Done."

echo -e "${YELLOW}Step 2: Resolving SPM packages (downloads ~300 MB, may take 5 min)...${NC}"
xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -resolvePackageDependencies \
  -clonedSourcePackagesDirPath "$PACKAGES" \
  CODE_SIGNING_ALLOWED=NO \
  2>&1 | grep -E "Resolved|error:|warning:|Fetching|Downloading" || true
echo "Packages resolved."

echo -e "${YELLOW}Step 3: Finding available simulator...${NC}"
SIM_ID=$(xcrun simctl list devices available -j \
  | python3 -c "
import sys,json
d=json.load(sys.stdin)
for rt,devs in d.get('devices',{}).items():
  for dev in devs:
    if dev.get('isAvailable') and 'iPhone' in dev.get('name',''):
      print(dev['udid']); sys.exit(0)
" 2>/dev/null || echo "")

if [ -z "$SIM_ID" ]; then
  DEST="generic/platform=iOS Simulator"
  echo "Using generic iOS Simulator"
else
  SIM_NAME=$(xcrun simctl list devices available -j \
    | python3 -c "
import sys,json
d=json.load(sys.stdin)
for rt,devs in d.get('devices',{}).items():
  for dev in devs:
    if dev.get('udid')=='$SIM_ID':
      print(dev['name']); sys.exit(0)
" 2>/dev/null || echo "$SIM_ID")
  DEST="id=$SIM_ID"
  echo "Using simulator: $SIM_NAME"
fi

echo -e "${YELLOW}Step 4: Building (first build takes 3-8 min)...${NC}"
BUILD_LOG=$(mktemp /tmp/messagex_XXXX.log)

xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -destination "$DEST" \
  -configuration Debug \
  -clonedSourcePackagesDirPath "$PACKAGES" \
  CODE_SIGNING_ALLOWED=NO \
  build 2>&1 | tee "$BUILD_LOG" | grep -E "error:|BUILD SUCCEEDED|BUILD FAILED|Compiling|Linking" | tail -40

echo ""
if grep -q "BUILD SUCCEEDED" "$BUILD_LOG"; then
  echo -e "${GREEN}✓ BUILD SUCCEEDED${NC}"
  echo "Full log: $BUILD_LOG"
  echo ""
  echo "Next steps:"
  echo "  1. Open in Xcode, press Cmd+R to run on simulator (Demo Mode needs no Firebase)"
  echo "  2. Replace GoogleService-Info.plist with your real Firebase plist when ready"
else
  echo -e "${RED}✗ BUILD FAILED — errors:${NC}"
  grep "error:" "$BUILD_LOG" | head -20
  echo ""
  echo "Full log: $BUILD_LOG"
  echo "Paste the errors above back to Claude for fixes."
  exit 1
fi
