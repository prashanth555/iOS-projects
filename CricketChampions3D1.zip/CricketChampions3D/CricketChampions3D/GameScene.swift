import SceneKit
import SpriteKit
import UIKit
import simd

// MARK: - GameScene

final class GameScene: SCNScene, SCNPhysicsContactDelegate {

    // MARK: Properties
    weak var sceneView: SCNView?
    private let gm = GameManager.shared

    // 3D Nodes
    private(set) var cameraNode  = SCNNode()
    private var ballNode: BallNode!
    private var batsmanNode: BatsmanNode!
    private var bowlerNode: BowlerNode!
    private var fielderNodes: [FielderNode] = []
    private var stumpNodes: [SCNNode] = []
    private var bailNodes:  [SCNNode] = []

    // State
    private(set) var isBallLive = false
    private(set) var canBat     = false
    private var currentDelivery: DeliveryType = .straight

    // Ball start position (bowler's hand release point)
    private let bowlerStartPos = SCNVector3(0, 0, -15)
    private let batsmanPos     = SCNVector3(0, 0,  9.4)
    private let ballReleasePos = SCNVector3(0.3, 2.3, -11.5)

    // MARK: - Init

    override init() {
        super.init()
        physicsWorld.gravity = SCNVector3(0, -9.81, 0)
        physicsWorld.contactDelegate = self
        buildScene()
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) not supported") }

    // MARK: - Scene Construction

    private func buildScene() {
        addLights()
        addSky()
        addGround()
        addPitch()
        addBoundary()
        addStadium()
        addStumps()
        addBatsman()
        addBowler()
        addFielders()
        addBall()
        addCamera()
    }

    // MARK: Lights

    private func addLights() {
        let sun = SCNNode()
        let sunLight           = SCNLight()
        sunLight.type          = .directional
        sunLight.color         = UIColor(red: 1.0, green: 0.96, blue: 0.84, alpha: 1)
        sunLight.intensity     = 1800
        sunLight.castsShadow   = true
        sunLight.shadowColor   = UIColor(white: 0, alpha: 0.38)
        sunLight.shadowRadius  = 4
        sunLight.orthographicScale = 60
        sun.light              = sunLight
        sun.position           = SCNVector3(15, 40, 15)
        sun.eulerAngles        = SCNVector3(-Float.pi/3.5, Float.pi/5, 0)
        rootNode.addChildNode(sun)

        let ambient = SCNNode()
        let al      = SCNLight()
        al.type     = .ambient
        al.color    = UIColor(red: 0.42, green: 0.52, blue: 0.65, alpha: 1)
        al.intensity = 450
        ambient.light = al
        rootNode.addChildNode(ambient)
    }

    // MARK: Sky

    private func addSky() {
        let sky = SCNSphere(radius: 220)
        sky.segmentCount = 24
        let mat = SCNMaterial()
        mat.isDoubleSided = true
        mat.lightingModel = .constant
        mat.diffuse.contents = makeSkyGradient()
        sky.materials = [mat]
        let skyNode = SCNNode(geometry: sky)
        rootNode.addChildNode(skyNode)

        // Clouds
        for _ in 0..<14 { addCloud() }
    }

    private func makeSkyGradient() -> UIImage {
        let size = CGSize(width: 2, height: 128)
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { ctx in
            let top    = UIColor(red: 0.36, green: 0.60, blue: 0.95, alpha: 1).cgColor
            let bottom = UIColor(red: 0.62, green: 0.78, blue: 0.98, alpha: 1).cgColor
            let grad   = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                     colors: [top, bottom] as CFArray,
                                     locations: [0, 1])!
            ctx.cgContext.drawLinearGradient(grad,
                                   start: .zero,
                                   end: CGPoint(x: 0, y: 128),
                                   options: [])
        }
    }

    private func addCloud() {
        let angle  = Float.random(in: 0...(2 * Float.pi))
        let radius = Float.random(in: 70...130)
        let height = Float.random(in: 35...70)
        let cloud  = SCNNode()
        let puffs  = Int.random(in: 3...6)
        for i in 0..<puffs {
            let r    = CGFloat.random(in: 3...6)
            let puff = SCNSphere(radius: r)
            puff.firstMaterial?.lightingModel = .constant
            puff.firstMaterial?.diffuse.contents = UIColor(white: 1, alpha: 0.88)
            let n = SCNNode(geometry: puff)
            n.position = SCNVector3(Float(i)*4 - Float(puffs)*2,
                                    Float.random(in: -1...1.5),
                                    Float.random(in: -2...2))
            cloud.addChildNode(n)
        }
        cloud.position = SCNVector3(radius*cos(angle), height, radius*sin(angle))
        rootNode.addChildNode(cloud)
    }

    // MARK: Ground

    private func addGround() {
        // Main floor physics plane
        let floor          = SCNFloor()
        let mat            = SCNMaterial()
        mat.diffuse.contents   = UIColor(red: 0.18, green: 0.56, blue: 0.14, alpha: 1)
        mat.roughness.contents = 0.9
        floor.materials = [mat]
        let groundNode = SCNNode(geometry: floor)
        groundNode.physicsBody = SCNPhysicsBody(type: .static, shape: nil)
        groundNode.physicsBody?.categoryBitMask  = PhysicsCategory.ground
        groundNode.physicsBody?.collisionBitMask = PhysicsCategory.ball
        groundNode.physicsBody?.restitution      = 0.4
        groundNode.physicsBody?.friction         = 0.8
        rootNode.addChildNode(groundNode)

        // Mow pattern strips (alternating brighter green)
        let stripCount = 10
        for i in 0..<stripCount {
            let stripW: CGFloat = 13
            let total: Float    = Float(stripW) * Float(stripCount)
            let offset: Float   = Float(i) * Float(stripW) - total / 2
            let isLight         = i % 2 == 0
            let col             = isLight
                ? UIColor(red: 0.23, green: 0.64, blue: 0.17, alpha: 1)
                : UIColor(red: 0.16, green: 0.50, blue: 0.11, alpha: 1)
            let box = SCNBox(width: stripW, height: 0.01, length: 160, chamferRadius: 0)
            box.firstMaterial?.diffuse.contents = col
            let n = SCNNode(geometry: box)
            n.position = SCNVector3(offset, 0.005, 0)
            rootNode.addChildNode(n)
        }
    }

    // MARK: Pitch

    private func addPitch() {
        let pitchGeo = SCNBox(width: 3.05, height: 0.025, length: 20.12, chamferRadius: 0)
        let mat      = SCNMaterial()
        mat.diffuse.contents   = UIColor(red: 0.75, green: 0.63, blue: 0.42, alpha: 1)
        mat.roughness.contents = 0.85
        pitchGeo.materials = [mat]
        let pitch = SCNNode(geometry: pitchGeo)
        pitch.position = SCNVector3(0, 0.013, 0)
        rootNode.addChildNode(pitch)

        // Crease lines
        for z in [-9.14, -8.0, 9.14, 10.06] as [Float] {
            let crease = SCNBox(width: 3.65, height: 0.012, length: 0.07, chamferRadius: 0)
            crease.firstMaterial?.diffuse.contents = UIColor.white
            let n = SCNNode(geometry: crease)
            n.position = SCNVector3(0, 0.025, z)
            rootNode.addChildNode(n)
        }
    }

    // MARK: Boundary

    private func addBoundary() {
        let segs: Int  = 60
        let radius: Float = 65

        var pts = [SCNVector3]()
        for i in 0...segs {
            let a = Float(i) * 2 * Float.pi / Float(segs)
            pts.append(SCNVector3(radius * cos(a), 0.1, radius * sin(a)))
        }

        for i in 0..<segs {
            let s = pts[i], e = pts[i+1]
            let dx = e.x - s.x, dz = e.z - s.z
            let len = sqrt(dx*dx + dz*dz)
            let rope = SCNBox(width: 0.28, height: 0.28, length: CGFloat(len), chamferRadius: 0.1)
            let col  = i % 4 < 2 ? UIColor.white : UIColor.red
            rope.firstMaterial?.diffuse.contents = col
            let n = SCNNode(geometry: rope)
            n.position    = SCNVector3((s.x+e.x)/2, 0.14, (s.z+e.z)/2)
            n.eulerAngles = SCNVector3(0, -atan2(dz, dx), 0)
            rootNode.addChildNode(n)
        }
    }

    // MARK: Stadium

    private func addStadium() {
        let standCount  = 18
        let standRadius: Float = 78

        for i in 0..<standCount {
            let a = Float(i) * 2 * Float.pi / Float(standCount)
            for tier in 0..<3 {
                let r  = standRadius + Float(tier) * 2.5
                let tx = r * cos(a), tz = r * sin(a)
                let h  = Float(tier) * 3.5 + 2.0
                let stand = SCNBox(width: 11, height: 3.2, length: 4.5, chamferRadius: 0)
                let palette: [UIColor] = [
                    UIColor(red: 0.10, green: 0.28, blue: 0.60, alpha: 1),
                    UIColor(red: 0.60, green: 0.10, blue: 0.10, alpha: 1),
                    UIColor(red: 0.10, green: 0.48, blue: 0.10, alpha: 1)
                ]
                stand.firstMaterial?.diffuse.contents = palette[tier]
                stand.firstMaterial?.roughness.contents = 0.9
                let n = SCNNode(geometry: stand)
                n.position    = SCNVector3(tx, h, tz)
                n.eulerAngles = SCNVector3(0, a + Float.pi, 0)
                rootNode.addChildNode(n)

                // Mini spectator dots
                if tier == 0 {
                    addSpectators(at: SCNVector3(tx, h + 1.5, tz), angle: a)
                }
            }
        }

        // Floodlight towers
        for i in 0..<6 {
            let a = Float(i) * 2 * Float.pi / 6
            addFloodlight(at: SCNVector3(90 * cos(a), 0, 90 * sin(a)))
        }

        // Scoreboard
        addScoreboard()
    }

    private func addSpectators(at pos: SCNVector3, angle: Float) {
        for i in -2...2 {
            let col = [UIColor.red, UIColor.blue, UIColor.yellow,
                       UIColor.white, UIColor.cyan].randomElement()!
            let dot = SCNSphere(radius: 0.4)
            dot.firstMaterial?.diffuse.contents    = col
            dot.firstMaterial?.lightingModel       = .constant
            let n = SCNNode(geometry: dot)
            let perpAngle = angle + Float.pi/2
            n.position = SCNVector3(pos.x + cos(perpAngle)*Float(i)*1.5,
                                     pos.y,
                                     pos.z + sin(perpAngle)*Float(i)*1.5)
            rootNode.addChildNode(n)
        }
    }

    private func addFloodlight(at pos: SCNVector3) {
        let pole = SCNCylinder(radius: 0.6, height: 32)
        pole.firstMaterial?.diffuse.contents    = UIColor(white: 0.65, alpha: 1)
        pole.firstMaterial?.metalness.contents  = 0.5
        let poleNode = SCNNode(geometry: pole)
        poleNode.position = SCNVector3(pos.x, 16, pos.z)
        rootNode.addChildNode(poleNode)

        // Light bracket
        let head = SCNBox(width: 5, height: 0.6, length: 2, chamferRadius: 0.1)
        head.firstMaterial?.diffuse.contents    = UIColor.white
        head.firstMaterial?.emission.contents   = UIColor(white: 1, alpha: 0.4)
        let headNode = SCNNode(geometry: head)
        headNode.position = SCNVector3(pos.x, 32.5, pos.z)
        headNode.eulerAngles.y = atan2(pos.x, pos.z)
        rootNode.addChildNode(headNode)
    }

    private func addScoreboard() {
        let board = SCNBox(width: 22, height: 11, length: 0.8, chamferRadius: 0.5)
        board.firstMaterial?.diffuse.contents    = UIColor(red: 0.05, green: 0.05, blue: 0.08, alpha: 1)
        board.firstMaterial?.emission.contents   = UIColor(red: 0.0, green: 0.1, blue: 0.3, alpha: 0.3)
        let boardNode = SCNNode(geometry: board)
        boardNode.position = SCNVector3(0, 17, -92)
        rootNode.addChildNode(boardNode)

        let frame = SCNBox(width: 24, height: 13, length: 0.3, chamferRadius: 0.6)
        frame.firstMaterial?.diffuse.contents    = UIColor(red: 0.75, green: 0.55, blue: 0.1, alpha: 1)
        frame.firstMaterial?.metalness.contents  = 0.4
        let frameNode = SCNNode(geometry: frame)
        frameNode.position = SCNVector3(0, 17, -92.5)
        rootNode.addChildNode(frameNode)
    }

    // MARK: Stumps

    private func addStumps() {
        addStumpSet(atZ: 10.4,  prefix: "batsman")
        addStumpSet(atZ: -10.4, prefix: "bowler")
    }

    private func addStumpSet(atZ z: Float, prefix: String) {
        let gold = UIColor(red: 0.9, green: 0.72, blue: 0.25, alpha: 1)
        let xPositions: [Float] = [-0.115, 0, 0.115]

        for x in xPositions {
            let stumpGeo = SCNCylinder(radius: 0.025, height: 0.72)
            stumpGeo.firstMaterial?.diffuse.contents   = gold
            stumpGeo.firstMaterial?.metalness.contents = 0.35
            let n = SCNNode(geometry: stumpGeo)
            n.position = SCNVector3(x, 0.36, z)
            n.name     = "\(prefix)Stump"
            n.physicsBody = SCNPhysicsBody(type: .dynamic,
                                            shape: SCNPhysicsShape(geometry: stumpGeo, options: nil))
            n.physicsBody?.mass                = 0.08
            n.physicsBody?.categoryBitMask     = PhysicsCategory.stumps
            n.physicsBody?.collisionBitMask    = PhysicsCategory.ball
            n.physicsBody?.contactTestBitMask  = PhysicsCategory.ball
            n.physicsBody?.isAffectedByGravity = false
            rootNode.addChildNode(n)
            stumpNodes.append(n)
        }

        // Bails
        for x in [-0.057, 0.057] as [Float] {
            let bailGeo = SCNCylinder(radius: 0.014, height: 0.11)
            bailGeo.firstMaterial?.diffuse.contents = gold
            let bail = SCNNode(geometry: bailGeo)
            bail.position    = SCNVector3(x, 0.735, z)
            bail.eulerAngles = SCNVector3(0, 0, Float.pi/2)
            bail.physicsBody = SCNPhysicsBody(type: .dynamic,
                                               shape: SCNPhysicsShape(geometry: bailGeo, options: nil))
            bail.physicsBody?.mass                = 0.012
            bail.physicsBody?.categoryBitMask     = PhysicsCategory.stumps
            bail.physicsBody?.collisionBitMask    = PhysicsCategory.ball
            bail.physicsBody?.isAffectedByGravity = false
            rootNode.addChildNode(bail)
            bailNodes.append(bail)
        }
    }

    // MARK: Players

    private func addBatsman() {
        batsmanNode = BatsmanNode()
        batsmanNode.position = batsmanPos
        rootNode.addChildNode(batsmanNode)
    }

    private func addBowler() {
        bowlerNode = BowlerNode()
        bowlerNode.position    = bowlerStartPos
        bowlerNode.eulerAngles = SCNVector3(0, Float.pi, 0)
        rootNode.addChildNode(bowlerNode)
    }

    private func addFielders() {
        // Standard cricket field positions (x, z, facingAngle)
        let positions: [(Float, Float)] = [
            ( 4,  -12),   // 1st slip
            ( 7,  -13),   // 2nd slip
            ( 9,   -8),   // gully
            (28,   22),   // cover point
            (42,   32),   // extra cover
            (-30,  18),   // mid-wicket
            (-46,  28),   // square leg
            (-22, -52),   // long-on
            ( 22, -52),   // long-off
            (-12,  58),   // fine leg
            ( 10,  58)    // third man
        ]
        for (x, z) in positions {
            let f = FielderNode()
            f.position = SCNVector3(x, 0, z)
            // Face the batsman approx
            f.eulerAngles.y = atan2(batsmanPos.x - x, batsmanPos.z - z)
            rootNode.addChildNode(f)
            fielderNodes.append(f)
        }
    }

    private func addBall() {
        ballNode = BallNode()
        ballNode.position = ballReleasePos
        ballNode.addTrail()
        rootNode.addChildNode(ballNode)
    }

    // MARK: Camera

    private func addCamera() {
        let cam     = SCNCamera()
        cam.fieldOfView  = 58
        cam.zFar         = 350
        cam.zNear        = 0.1
        // Post-processing
        cam.bloomIntensity    = 0.6
        cam.bloomThreshold    = 0.75
        cam.vignettingIntensity = 0.25
        cam.wantsHDR          = true
        cam.wantsExposureAdaptation = true

        cameraNode.camera = cam
        cameraNode.position    = SCNVector3(2, 4.5, 20)
        cameraNode.eulerAngles = SCNVector3(-0.22, 0.05, 0)
        rootNode.addChildNode(cameraNode)
    }

    // MARK: - Gameplay API

    func startDelivery() {
        guard !isBallLive else { return }
        isBallLive = true
        canBat     = false

        // Reset ball
        ballNode.physicsBody?.velocity        = SCNVector3Zero
        ballNode.physicsBody?.angularVelocity = SCNVector4Zero
        ballNode.position = ballReleasePos

        // Choose delivery
        currentDelivery = gm.randomDelivery()
        NotificationCenter.default.post(name: .deliveryType, object: currentDelivery)

        // Bowler run-up, then release ball
        bowlerNode.resetPosition(to: bowlerStartPos)
        bowlerNode.animateRunUp { [weak self] in
            self?.releaseBall()
        }
    }

    private func releaseBall() {
        let d   = currentDelivery
        let spd = d.speed

        var vx = d.lateralDrift
        let vy = d.launchHeight
        let vz = spd

        // Add slight random variation
        vx += Float.random(in: -0.4...0.4)
        let vRandomY: Float = Float.random(in: -0.2...0.3)

        ballNode.physicsBody?.velocity        = SCNVector3(vx, vy + vRandomY, vz)
        ballNode.physicsBody?.angularVelocity = SCNVector4(0, 1, 0, spd * 0.6)

        moveCameraToDeliveryView()

        // Enable batting when ball is close enough
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            self?.canBat = true
        }

        // Timeout: if no bat swing, check outcome
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) { [weak self] in
            self?.evaluateMiss()
        }
    }

    // MARK: - Batting

    func playerSwing(direction: CGPoint) {
        guard isBallLive, canBat else { return }
        canBat = false

        let ballPos   = ballNode.presentation.position
        let batsmanP  = batsmanNode.presentation.position
        let zDist     = abs(ballPos.z - batsmanP.z)
        let xDist     = abs(ballPos.x - batsmanP.x)
        let inZone    = zDist < 2.5 && xDist < 1.4

        batsmanNode.swing(direction: direction) { [weak self] in
            guard let self = self else { return }
            if inZone {
                self.executeHit(direction: direction)
            } else {
                self.executeMiss()
            }
        }
    }

    private func executeHit(direction: CGPoint) {
        let ball   = ballNode.presentation.position
        let dx     = Float(direction.x)
        let dy     = Float(direction.y)
        let power  = Float.random(in: 16...32)

        var vx, vy, vz: Float

        if dy > 0.45 {              // drive
            vx = dx * power * 0.4; vy = power * 0.35; vz = -power
        } else if dy < -0.45 {     // pull/hook
            vx = -dx * power * 0.7; vy = power * 0.6; vz = power * 0.25
        } else if dx > 0.45 {      // cut
            vx = power * 0.85; vy = power * 0.3; vz = -power * 0.3
        } else if dx < -0.45 {     // flick
            vx = -power * 0.85; vy = power * 0.3; vz = power * 0.2
        } else {                    // straight
            vx = dx * power * 0.2; vy = power * 0.4; vz = -power * 0.9
        }

        // Edge chance (25%)
        if Float.random(in: 0...1) < 0.25 {
            vx += Float.random(in: -6...6)
            vy  = Float.random(in: 2...8)
            vz  = Float.random(in: -5...5)
        }

        ballNode.physicsBody?.velocity        = SCNVector3(vx, vy, vz)
        ballNode.physicsBody?.angularVelocity = SCNVector4(dx, 0, 1, power * 0.4)

        addHitEffect(at: ball)
        moveCameraToWideView()
        dispatchFielderChase()

        // Evaluate result after ball settles
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.2) { [weak self] in
            self?.evaluateHitResult()
        }
    }

    private func executeMiss() {
        // Dot ball – ball passes or is blocked
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            self?.evaluateMiss()
        }
    }

    private func evaluateMiss() {
        guard isBallLive else { return }
        let ball    = ballNode.presentation.position
        let stumpZ  = Float(10.4)
        let zDist   = abs(ball.z - stumpZ)
        let inLine  = abs(ball.x) < 0.4 && ball.y < 0.78

        if zDist < 1.2 && inLine {
            isBallLive = false
            animateStumpsFlying()
            broadcastWicket(.bowled)
            resetAfterBall(delay: 2.5)
        } else {
            isBallLive = false
            gm.addDotBall()
            NotificationCenter.default.post(name: .dotBall, object: nil)
            resetAfterBall(delay: 1.5)
        }
    }

    private func evaluateHitResult() {
        guard isBallLive else { return }
        isBallLive = false
        let ball  = ballNode.presentation.position
        let dist  = sqrt(ball.x*ball.x + ball.z*ball.z)

        let runs: Int
        if dist >= 65 {
            runs = 6
        } else if dist >= 58 {
            runs = 4
        } else if dist >= 40 {
            runs = Int.random(in: 2...3)
        } else if dist >= 15 {
            runs = Int.random(in: 1...2)
        } else {
            runs = 0
        }

        gm.addRuns(runs)
        NotificationCenter.default.post(name: .runsScored, object: runs)

        if runs == 6 || runs == 4 {
            NotificationCenter.default.post(name: .showRunAnim, object: runs)
        }

        resetAfterBall(delay: 1.6)
    }

    // MARK: - Helpers

    private func broadcastWicket(_ type: DismissalType) {
        gm.addWicket()
        NotificationCenter.default.post(name: .wicketFell, object: type)
    }

    private func animateStumpsFlying() {
        for n in stumpNodes where n.name == "batsmanStump" {
            let fly = SCNAction.sequence([
                SCNAction.rotateBy(x: CGFloat.random(in: -1...1),
                                   y: CGFloat.random(in: -1...1),
                                   z: CGFloat.random(in: -1...1),
                                   duration: 0.08),
                SCNAction.moveBy(x: CGFloat.random(in: -1.2...1.2), y: 2, z: CGFloat.random(in: -0.5...0.5), duration: 0.5),
                SCNAction.moveBy(x: 0, y: -2.5, z: 0, duration: 0.4)
            ])
            n.runAction(fly)
        }
        // Bail burst particle
        let burst         = SCNParticleSystem()
        burst.birthRate   = 400
        burst.particleLifeSpan = 0.5
        burst.particleSize     = 0.05
        burst.particleColor    = UIColor.yellow
        burst.spreadingAngle   = 180
        burst.particleVelocity = 4
        burst.loops            = false
        let eff = SCNNode()
        eff.position = SCNVector3(0, 0.75, 10.4)
        eff.addParticleSystem(burst)
        rootNode.addChildNode(eff)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { eff.removeFromParentNode() }
    }

    private func addHitEffect(at pos: SCNVector3) {
        let sys              = SCNParticleSystem()
        sys.birthRate        = 600
        sys.particleLifeSpan = 0.4
        sys.particleSize     = 0.055
        sys.particleColor    = UIColor.orange
        sys.spreadingAngle   = 180
        sys.particleVelocity = 6
        sys.loops            = false
        let n = SCNNode()
        n.position = pos
        n.addParticleSystem(sys)
        rootNode.addChildNode(n)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { n.removeFromParentNode() }
    }

    private func dispatchFielderChase() {
        let bv    = ballNode.physicsBody?.velocity ?? SCNVector3Zero
        let speed = sqrt(bv.x*bv.x + bv.z*bv.z)
        guard speed > 0 else { return }

        let predictedX = ballNode.position.x + bv.x * 2.5
        let predictedZ = ballNode.position.z + bv.z * 2.5
        let target     = SCNVector3(predictedX, 0, predictedZ)

        // Send nearest 2 fielders
        let sorted = fielderNodes.sorted {
            let aP = $0.presentation.position
            let bP = $1.presentation.position
            let aD = simd_distance(simd_float3(aP.x, aP.y, aP.z), simd_float3(target.x, 0, target.z))
            let bD = simd_distance(simd_float3(bP.x, bP.y, bP.z), simd_float3(target.x, 0, target.z))
            return aD < bD
        }
        sorted.prefix(2).forEach { $0.chase(to: target, duration: 2.5) }
    }

    private func resetAfterBall(delay: Double) {
        guard !gm.isGameOver else {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                self?.gm.saveHighScore()
                NotificationCenter.default.post(name: .gameOver, object: nil)
            }
            return
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            self?.resetBallAndStumps()
            self?.resetCamera()
            NotificationCenter.default.post(name: .nextBall, object: nil)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                self?.startDelivery()
            }
        }
    }

    private func resetBallAndStumps() {
        ballNode.physicsBody?.velocity        = SCNVector3Zero
        ballNode.physicsBody?.angularVelocity = SCNVector4Zero
        ballNode.position = ballReleasePos

        // Reset stump physics state
        for n in stumpNodes {
            n.physicsBody?.velocity        = SCNVector3Zero
            n.physicsBody?.angularVelocity = SCNVector4Zero
            if n.name == "batsmanStump" {
                // Snap back
                let idx = stumpNodes.filter { $0.name == "batsmanStump" }.firstIndex(of: n) ?? 0
                let xs: [Float] = [-0.115, 0, 0.115]
                n.position    = SCNVector3(xs[min(idx, 2)], 0.36, 10.4)
                n.eulerAngles = SCNVector3Zero
            }
        }
        for b in bailNodes {
            b.physicsBody?.velocity        = SCNVector3Zero
            b.physicsBody?.angularVelocity = SCNVector4Zero
            b.eulerAngles = SCNVector3(0, 0, Float.pi/2)
        }
    }

    // MARK: - Camera Moves

    private func moveCameraToDeliveryView() {
        let move = SCNAction.move(to: SCNVector3(6, 3.5, 7), duration: 0.5)
        let look = SCNAction.rotateTo(x: -0.18, y: 0.35, z: 0, duration: 0.5)
        cameraNode.constraints = []
        cameraNode.runAction(SCNAction.group([move, look]))
    }

    private func moveCameraToWideView() {
        cameraNode.constraints = []
        let move = SCNAction.move(to: SCNVector3(3, 18, 5), duration: 0.5)
        let look = SCNAction.rotateTo(x: -0.9, y: 0.1, z: 0, duration: 0.5)
        cameraNode.runAction(SCNAction.group([move, look]))
    }

    private func resetCamera() {
        cameraNode.constraints = []
        let move = SCNAction.move(to:   SCNVector3(2, 4.5, 20), duration: 0.6)
        let look = SCNAction.rotateTo(x: -0.22, y: 0.05, z: 0,  duration: 0.6)
        cameraNode.runAction(SCNAction.group([move, look]))
    }

    // MARK: - SCNPhysicsContactDelegate

    func physicsWorld(_ world: SCNPhysicsWorld, didBegin contact: SCNPhysicsContact) {
        let nodeA = contact.nodeA, nodeB = contact.nodeB
        let isBallA = nodeA.name == "ball", isBallB = nodeB.name == "ball"
        guard isBallA || isBallB else { return }

        let other = isBallA ? nodeB : nodeA
        if other.name?.contains("Stump") == true {
            // Stumps contact handled by evaluateMiss timing
        }
    }
}
