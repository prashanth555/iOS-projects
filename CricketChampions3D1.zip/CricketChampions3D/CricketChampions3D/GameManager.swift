import Foundation

// MARK: - Enums

enum GameState {
    case menu, readyToBowl, bowling, ballInFlight, result, gameOver
}

enum DismissalType: String {
    case bowled   = "BOWLED!"
    case caught   = "CAUGHT!"
    case lbw      = "LBW!"
    case runOut   = "RUN OUT!"
}

enum DeliveryType: String, CaseIterable {
    case straight  = "FAST BALL"
    case yorker    = "YORKER!"
    case bouncer   = "BOUNCER!"
    case offBreak  = "OFF BREAK"
    case legBreak  = "LEG BREAK"
    case fullToss  = "FULL TOSS"

    var speed: Float {
        switch self {
        case .straight: return 24
        case .yorker:   return 28
        case .bouncer:  return 30
        case .offBreak: return 20
        case .legBreak: return 20
        case .fullToss: return 22
        }
    }

    // Ball launch angle (Y component relative to horizontal)
    var launchHeight: Float {
        switch self {
        case .straight: return 2.5
        case .yorker:   return 0.8
        case .bouncer:  return 5.0
        case .offBreak: return 2.0
        case .legBreak: return 2.0
        case .fullToss: return 3.5
        }
    }

    // Lateral deviation
    var lateralDrift: Float {
        switch self {
        case .offBreak: return -2.5
        case .legBreak: return  2.5
        default:        return  0.0
        }
    }
}

// MARK: - Score Model

struct Innings {
    var runs: Int    = 0
    var wickets: Int = 0
    var balls: Int   = 0

    var ballsInCurrentOver: Int { balls % 6 }
    var completedOvers: Int     { balls / 6 }

    var overDisplay: String {
        return "\(completedOvers).\(ballsInCurrentOver)"
    }

    var isComplete: Bool {
        return wickets >= 10 || completedOvers >= 20
    }
}

// MARK: - GameManager

final class GameManager {

    static let shared = GameManager()

    var state: GameState = .menu
    var innings          = Innings()
    var highScore: Int {
        get { UserDefaults.standard.integer(forKey: "highScore") }
        set { UserDefaults.standard.set(newValue, forKey: "highScore") }
    }

    private init() {}

    func reset() {
        innings = Innings()
        state   = .readyToBowl
    }

    func addRuns(_ runs: Int) {
        innings.runs  += runs
        innings.balls += 1
    }

    func addWicket() {
        innings.wickets += 1
        innings.balls   += 1
    }

    func addDotBall() {
        innings.balls += 1
    }

    func addExtras(_ runs: Int) {
        innings.runs += runs
        // Extras don't add a ball to the over count in this simplified version
    }

    var scoreDisplay: String { "\(innings.runs)/\(innings.wickets)" }
    var overDisplay: String  { innings.overDisplay }

    var isGameOver: Bool { innings.isComplete }

    func saveHighScore() {
        if innings.runs > highScore {
            highScore = innings.runs
        }
    }

    func randomDelivery() -> DeliveryType {
        // Weighted random – straights are more common
        let weights: [(DeliveryType, Int)] = [
            (.straight, 35), (.yorker, 15), (.bouncer, 15),
            (.offBreak, 15), (.legBreak, 10), (.fullToss, 10)
        ]
        let total = weights.reduce(0) { $0 + $1.1 }
        var roll  = Int.random(in: 0..<total)
        for (type, weight) in weights {
            roll -= weight
            if roll < 0 { return type }
        }
        return .straight
    }
}
