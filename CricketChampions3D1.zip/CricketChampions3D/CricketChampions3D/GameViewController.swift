import UIKit
import SceneKit
import SpriteKit

final class GameViewController: UIViewController {

    // MARK: - Properties
    private var scnView:   SCNView!
    private var gameScene: GameScene!
    private var hudScene:  HUDOverlay!

    // Gesture state
    private var swipeStart: CGPoint?

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupSceneView()
        setupHUD()
        setupGestures()
        subscribeNotifications()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        GameManager.shared.reset()
        // Brief countdown then first delivery
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            self?.gameScene.startDelivery()
        }
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var prefersStatusBarHidden: Bool { true }

    // MARK: - Setup

    private func setupSceneView() {
        scnView = SCNView(frame: view.bounds)
        scnView.autoresizingMask = [.flexibleWidth, .flexibleHeight]

        gameScene = GameScene()
        gameScene.sceneView = scnView

        scnView.scene           = gameScene
        scnView.pointOfView     = gameScene.cameraNode
        scnView.antialiasingMode = .multisampling4X
        scnView.showsStatistics  = false
        scnView.allowsCameraControl = false
        scnView.preferredFramesPerSecond = 60

        view.addSubview(scnView)
    }

    private func setupHUD() {
        let size = view.bounds.size
        // Landscape size: width > height
        let hudSize = size.width > size.height ? size : CGSize(width: size.height, height: size.width)
        hudScene = HUDOverlay(size: hudSize)
        hudScene.scaleMode = .aspectFill
        scnView.overlaySKScene = hudScene
    }

    private func setupGestures() {
        let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
        pan.minimumNumberOfTouches = 1
        pan.maximumNumberOfTouches = 1
        scnView.addGestureRecognizer(pan)

        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        scnView.addGestureRecognizer(tap)
    }

    private func subscribeNotifications() {
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(onGameOver),
                                               name: .gameOver,
                                               object: nil)
    }

    // MARK: - Gestures

    @objc private func handlePan(_ gr: UIPanGestureRecognizer) {
        switch gr.state {
        case .began:
            swipeStart = gr.location(in: scnView)
        case .ended, .cancelled:
            guard let start = swipeStart else { return }
            let end       = gr.location(in: scnView)
            let dx        = end.x - start.x
            let dy        = end.y - start.y
            let len       = sqrt(dx*dx + dy*dy)
            guard len > 20 else { swipeStart = nil; return }
            let normalised = CGPoint(x: dx / len, y: -dy / len) // flip Y for game coords
            gameScene.playerSwing(direction: normalised)
            swipeStart = nil
        default:
            break
        }
    }

    @objc private func handleTap(_ gr: UITapGestureRecognizer) {
        // Tap = straight defensive push
        gameScene.playerSwing(direction: CGPoint(x: 0, y: 0.6))
    }

    // MARK: - Game Over

    @objc private func onGameOver() {
        DispatchQueue.main.async { [weak self] in
            let vc = GameOverViewController()
            vc.modalPresentationStyle = .fullScreen
            self?.present(vc, animated: true)
        }
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
