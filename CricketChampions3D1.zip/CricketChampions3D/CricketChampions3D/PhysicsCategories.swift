import Foundation

struct PhysicsCategory {
    static let none: Int     = 0
    static let ball: Int     = 1 << 0   // 1
    static let bat: Int      = 1 << 1   // 2
    static let ground: Int   = 1 << 2   // 4
    static let stumps: Int   = 1 << 3   // 8
    static let boundary: Int = 1 << 4   // 16
}

extension Notification.Name {
    static let ballBowled      = Notification.Name("cc_ballBowled")
    static let runsScored      = Notification.Name("cc_runsScored")
    static let wicketFell      = Notification.Name("cc_wicketFell")
    static let dotBall         = Notification.Name("cc_dotBall")
    static let extrasBall      = Notification.Name("cc_extrasBall")
    static let nextBall        = Notification.Name("cc_nextBall")
    static let gameOver        = Notification.Name("cc_gameOver")
    static let showRunAnim     = Notification.Name("cc_showRunAnim")
    static let deliveryType    = Notification.Name("cc_deliveryType")
}
