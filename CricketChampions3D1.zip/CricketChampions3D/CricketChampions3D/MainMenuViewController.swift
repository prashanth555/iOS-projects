import UIKit

final class MainMenuViewController: UIViewController {

    // MARK: - UI

    private let gradientLayer = CAGradientLayer()
    private let titleLabel    = UILabel()
    private let subtitleLabel = UILabel()
    private let playButton    = UIButton(type: .system)
    private let highScoreLabel = UILabel()
    private let pitchImageView = UIView()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        buildUI()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gradientLayer.frame = view.bounds
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var prefersStatusBarHidden: Bool { true }

    // MARK: - Build

    private func buildUI() {
        // Gradient background
        gradientLayer.colors = [
            UIColor(red: 0.04, green: 0.09, blue: 0.22, alpha: 1).cgColor,
            UIColor(red: 0.08, green: 0.22, blue: 0.10, alpha: 1).cgColor
        ]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint   = CGPoint(x: 1, y: 1)
        view.layer.insertSublayer(gradientLayer, at: 0)

        // Decorative cricket pitch strip
        pitchImageView.backgroundColor = UIColor(red: 0.75, green: 0.63, blue: 0.42, alpha: 0.18)
        pitchImageView.layer.cornerRadius = 4
        pitchImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(pitchImageView)

        // Stars/particles layer (simple dots)
        addStarLayer()

        // Logo / title
        titleLabel.text = "CRICKET\nCHAMPIONS 3D"
        titleLabel.numberOfLines = 2
        titleLabel.font = UIFont(name: "AvenirNext-Heavy", size: 46)
                       ?? UIFont.systemFont(ofSize: 46, weight: .heavy)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.adjustsFontSizeToFitWidth = true
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        // Drop shadow
        titleLabel.layer.shadowColor  = UIColor(red: 0, green: 0.8, blue: 0.3, alpha: 0.8).cgColor
        titleLabel.layer.shadowRadius = 12
        titleLabel.layer.shadowOpacity = 0.9
        titleLabel.layer.shadowOffset = .zero
        view.addSubview(titleLabel)

        // Subtitle
        subtitleLabel.text = "T20 BAT & BOWL"
        subtitleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        subtitleLabel.textColor = UIColor(red: 0.4, green: 0.9, blue: 0.5, alpha: 1)
        subtitleLabel.textAlignment = .center
        subtitleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(subtitleLabel)

        // Play button
        playButton.setTitle("▶  PLAY", for: .normal)
        playButton.titleLabel?.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        playButton.setTitleColor(.white, for: .normal)
        playButton.backgroundColor = UIColor(red: 0.1, green: 0.7, blue: 0.3, alpha: 1)
        playButton.layer.cornerRadius = 30
        playButton.layer.borderWidth  = 2
        playButton.layer.borderColor  = UIColor(white: 1, alpha: 0.4).cgColor
        playButton.layer.shadowColor  = UIColor(red: 0, green: 0.8, blue: 0.3, alpha: 0.7).cgColor
        playButton.layer.shadowRadius = 16
        playButton.layer.shadowOpacity = 0.8
        playButton.layer.shadowOffset  = .zero
        playButton.translatesAutoresizingMaskIntoConstraints = false
        playButton.addTarget(self, action: #selector(didTapPlay), for: .touchUpInside)
        view.addSubview(playButton)

        // High score
        let hs = GameManager.shared.highScore
        highScoreLabel.text = hs > 0 ? "Best: \(hs)" : "No games played yet"
        highScoreLabel.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        highScoreLabel.textColor = UIColor(white: 0.65, alpha: 1)
        highScoreLabel.textAlignment = .center
        highScoreLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(highScoreLabel)

        // Instructions
        let instr = UILabel()
        instr.text = "Swipe to hit • Drive • Pull • Cut • Flick"
        instr.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        instr.textColor = UIColor(white: 0.5, alpha: 1)
        instr.textAlignment = .center
        instr.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(instr)

        // Layout
        NSLayoutConstraint.activate([
            pitchImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            pitchImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 20),
            pitchImageView.widthAnchor.constraint(equalToConstant: 60),
            pitchImageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.7),

            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 24),
            titleLabel.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.55),

            subtitleLabel.centerXAnchor.constraint(equalTo: titleLabel.centerXAnchor),
            subtitleLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),

            playButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            playButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 30),
            playButton.widthAnchor.constraint(equalToConstant: 200),
            playButton.heightAnchor.constraint(equalToConstant: 60),

            highScoreLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            highScoreLabel.topAnchor.constraint(equalTo: playButton.bottomAnchor, constant: 18),

            instr.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            instr.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -14)
        ])

        animatePlayButton()
    }

    private func addStarLayer() {
        for _ in 0..<60 {
            let dot = CALayer()
            let size = CGFloat.random(in: 1...3)
            dot.backgroundColor = UIColor(white: 1, alpha: CGFloat.random(in: 0.3...0.9)).cgColor
            dot.cornerRadius    = size / 2
            let w = view.bounds.width  > 0 ? view.bounds.width  : 926
            let h = view.bounds.height > 0 ? view.bounds.height : 428
            let x = CGFloat.random(in: 0...w)
            let y = CGFloat.random(in: 0...h)
            dot.frame = CGRect(x: x, y: y, width: size, height: size)
            view.layer.addSublayer(dot)

            // Twinkle
            let anim             = CABasicAnimation(keyPath: "opacity")
            anim.fromValue       = CGFloat.random(in: 0.2...0.8)
            anim.toValue         = CGFloat.random(in: 0.5...1.0)
            anim.duration        = Double.random(in: 1.5...4.0)
            anim.autoreverses    = true
            anim.repeatCount     = .infinity
            anim.beginTime       = CACurrentMediaTime() + Double.random(in: 0...3)
            dot.add(anim, forKey: "twinkle")
        }
    }

    private func animatePlayButton() {
        UIView.animate(withDuration: 1.0,
                       delay: 0,
                       options: [.autoreverse, .repeat, .curveEaseInOut],
                       animations: {
            self.playButton.transform = CGAffineTransform(scaleX: 1.04, y: 1.04)
        })
    }

    // MARK: - Actions

    @objc private func didTapPlay() {
        let impact = UIImpactFeedbackGenerator(style: .medium)
        impact.impactOccurred()

        UIView.animate(withDuration: 0.1, animations: {
            self.playButton.transform = CGAffineTransform(scaleX: 0.93, y: 0.93)
        }) { _ in
            UIView.animate(withDuration: 0.1) {
                self.playButton.transform = .identity
            }
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { [weak self] in
            let gameVC = GameViewController()
            gameVC.modalPresentationStyle = .fullScreen
            self?.present(gameVC, animated: true)
        }
    }
}
