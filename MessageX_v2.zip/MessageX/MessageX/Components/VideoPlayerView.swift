import SwiftUI
import AVKit
import AVFoundation

struct VideoPlayerView: View {
    let urlString: String
    @State private var player: AVPlayer?
    @State private var isLoading = true
    @Environment(\.dismiss) var dismiss

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            if let player = player {
                VideoPlayer(player: player)
                    .ignoresSafeArea()
                    .onDisappear { player.pause() }
            } else if isLoading {
                ProgressView().tint(.white)
            }

            VStack {
                HStack {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .foregroundColor(.white)
                            .font(.system(size: 18, weight: .bold))
                            .padding(12)
                            .background(Color.black.opacity(0.5))
                            .clipShape(Circle())
                    }
                    Spacer()
                }
                .padding()
                Spacer()
            }
        }
        .onAppear { setupPlayer() }
    }

    private func setupPlayer() {
        guard let url = URL(string: urlString) else { return }
        player = AVPlayer(url: url)
        player?.play()
        isLoading = false
    }
}

struct InlinVideoPlayer: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        let player = AVPlayer(url: url)
        let layer = AVPlayerLayer(player: player)
        layer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(layer)
        player.play()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            layer.frame = view.bounds
        }
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {}
}

struct AudioPlayerView: View {
    let urlString: String
    @State private var player: AVAudioPlayer?
    @State private var isPlaying = false
    @State private var progress: Double = 0
    @State private var duration: Double = 0
    @State private var timer: Timer?

    var body: some View {
        HStack(spacing: 12) {
            Button { togglePlayback() } label: {
                Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 32))
                    .foregroundColor(.primaryGreen)
            }

            VStack(alignment: .leading, spacing: 4) {
                Slider(value: $progress, in: 0...max(duration, 1)) { editing in
                    if !editing, let player = player {
                        player.currentTime = progress
                    }
                }
                .accentColor(.primaryGreen)

                HStack {
                    Text(formatTime(progress))
                    Spacer()
                    Text(formatTime(duration))
                }
                .font(.caption2)
                .foregroundColor(.secondary)
            }
        }
        .onAppear { loadAudio() }
        .onDisappear { cleanup() }
    }

    private func loadAudio() {
        guard let url = URL(string: urlString) else { return }
        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data else { return }
            DispatchQueue.main.async {
                player = try? AVAudioPlayer(data: data)
                duration = player?.duration ?? 0
            }
        }.resume()
    }

    private func togglePlayback() {
        guard let player = player else { return }
        if isPlaying {
            player.pause()
            timer?.invalidate()
        } else {
            try? AVAudioSession.sharedInstance().setCategory(.playback)
            try? AVAudioSession.sharedInstance().setActive(true)
            player.play()
            startTimer()
        }
        isPlaying.toggle()
    }

    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
            progress = player?.currentTime ?? 0
            if player?.isPlaying == false {
                isPlaying = false
                timer?.invalidate()
            }
        }
    }

    private func cleanup() {
        player?.stop()
        timer?.invalidate()
    }

    private func formatTime(_ seconds: Double) -> String {
        let total = Int(seconds)
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}
