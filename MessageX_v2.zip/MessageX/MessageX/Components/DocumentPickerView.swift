import SwiftUI
import UniformTypeIdentifiers

struct DocumentPickerView: UIViewControllerRepresentable {
    let onDocumentPicked: (URL) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // UTType(filenameExtension:) can return nil for unrecognised extensions;
        // compactMap removes any nils so the picker still opens.
        let knownTypes: [UTType] = [.pdf, .text, .spreadsheet, .presentation, .archive, .data, .item]
        let extensionTypes: [UTType] = ["doc", "docx", "xls", "xlsx", "ppt", "pptx"]
            .compactMap { UTType(filenameExtension: $0) }
        let types = knownTypes + extensionTypes
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let parent: DocumentPickerView
        init(_ parent: DocumentPickerView) { self.parent = parent }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            // Start accessing security-scoped resource
            guard url.startAccessingSecurityScopedResource() else { return }
            defer { url.stopAccessingSecurityScopedResource() }

            // Copy to temp directory for upload
            let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent(url.lastPathComponent)
            try? FileManager.default.removeItem(at: tempURL)
            do {
                try FileManager.default.copyItem(at: url, to: tempURL)
                parent.onDocumentPicked(tempURL)
            } catch {
                print("Error copying document: \(error)")
            }
        }
    }
}
