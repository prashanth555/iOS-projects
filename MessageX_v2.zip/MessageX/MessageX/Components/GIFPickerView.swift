import SwiftUI
import SDWebImage

// MARK: - Giphy API Models
private struct GiphyResponse: Decodable {
    let data: [GiphyGIF]
}

struct GiphyGIF: Identifiable, Decodable {
    let id: String
    let images: GiphyImages

    var previewURL: URL? { URL(string: images.fixedWidth.url) }
    var originalURL: String { images.original.url }
    var width: Int { Int(images.original.width) ?? 480 }
    var height: Int { Int(images.original.height) ?? 270 }

    struct GiphyImages: Decodable {
        let fixedWidth: GiphyImage
        let original: GiphyImage
        enum CodingKeys: String, CodingKey {
            case fixedWidth = "fixed_width"
            case original
        }
    }

    struct GiphyImage: Decodable {
        let url: String
        let width: String
        let height: String
    }
}

// MARK: - Built-in reaction GIFs (no API key needed)
// These are stable Giphy CDN URLs — publicly accessible without auth.
private struct BuiltInGIF: Identifiable {
    let id: String       // Giphy media ID
    let label: String
    var url: URL? { URL(string: "https://media.giphy.com/media/\(id)/giphy.gif") }
    var previewURL: URL? { URL(string: "https://media.giphy.com/media/\(id)/200w.gif") }
}

private let builtInGIFs: [BuiltInGIF] = [
    BuiltInGIF(id: "111ebonMs90YLu",     label: "👍 Thumbs Up"),
    BuiltInGIF(id: "3oEjI6SIIHBdRxXI40", label: "😂 Laughing"),
    BuiltInGIF(id: "26u4cqiYI30juCOGY",  label: "👏 Applause"),
    BuiltInGIF(id: "3oEdvbpl4Rqxos6fXW", label: "👋 Wave"),
    BuiltInGIF(id: "26BRBKqUiq586bRVm",  label: "❤️ Heart"),
    BuiltInGIF(id: "l0MYt5jPR6QX5pnqM",  label: "🎉 Party"),
    BuiltInGIF(id: "DKnMqdm9i980E",       label: "🤦 Facepalm"),
    BuiltInGIF(id: "3ohfFhG5R9EEL1DH2w",  label: "😕 Confused"),
    BuiltInGIF(id: "xT9IgG50Lg7rusyxxG",  label: "🤯 Mind Blown"),
    BuiltInGIF(id: "3o7TKP9ln2Dr6ze6f6",  label: "✅ Yes"),
    BuiltInGIF(id: "3o7TKqnN349PBUtGFO",  label: "🚫 No Way"),
    BuiltInGIF(id: "YlCg4YpD3nI9W",       label: "😆 Excited"),
    BuiltInGIF(id: "1gUn2j08RnDMI",       label: "😲 Wow"),
    BuiltInGIF(id: "3o6MbnqLzeNG1ACIPVS", label: "🔥 Fire"),
    BuiltInGIF(id: "xT9IgNeJHF0E0",       label: "👍 OK"),
    BuiltInGIF(id: "3oEjI6SIIHBdRxXI40",  label: "😹 LOL"),
    BuiltInGIF(id: "26gsvynpxpB7uD84E",   label: "🙌 Celebrate"),
    BuiltInGIF(id: "3oz8xAFtqoOUUrsh7W",  label: "😴 Sleepy"),
    BuiltInGIF(id: "3oEdv3D6MyNqceMFhK",  label: "👌 Perfect"),
    BuiltInGIF(id: "26u4lOMA8JKSnL9Uk",   label: "💪 Strong"),
]

// MARK: - GIF Picker View
struct GIFPickerView: View {
    let onGIFSelected: (String, Int, Int) -> Void
    @Environment(\.dismiss) var dismiss
    @State private var searchText = ""
    @State private var apiGifs: [GiphyGIF] = []
    @State private var isLoading = false
    @State private var debounceTask: Task<Void, Never>?

    private let columns = [GridItem(.flexible(), spacing: 3),
                            GridItem(.flexible(), spacing: 3),
                            GridItem(.flexible(), spacing: 3)]

    var body: some View {
        NavigationStack {
            Group {
                if AppConfig.giphyConfigured {
                    apiGifContent
                } else {
                    builtInGifContent
                }
            }
            .navigationTitle("GIF")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                }
            }
            .if(AppConfig.giphyConfigured) { view in
                view.searchable(text: $searchText, prompt: "Search GIFs…")
                    .onChange(of: searchText) { _, query in
                        debounceTask?.cancel()
                        debounceTask = Task {
                            try? await Task.sleep(nanoseconds: 400_000_000)
                            guard !Task.isCancelled else { return }
                            await fetchGIFs(query: query.isEmpty ? nil : query)
                        }
                    }
                    .task { await fetchGIFs(query: nil) }
            }
        }
    }

    // Built-in reaction GIFs — always available, no API key required
    private var builtInGifContent: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                Text("Reactions")
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 12)
                    .padding(.top, 8)
                LazyVGrid(columns: columns, spacing: 3) {
                    ForEach(builtInGIFs) { gif in
                        SDAnimatedGIFView(url: gif.previewURL)
                            .frame(height: 110)
                            .clipped()
                            .contentShape(Rectangle())
                            .onTapGesture {
                                onGIFSelected(gif.url?.absoluteString ?? "", 480, 270)
                                dismiss()
                            }
                    }
                }
                .padding(.horizontal, 3)
                Text("Add GIPHY_API_KEY in Xcode scheme for full GIF search")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding()
            }
        }
    }

    // Full Giphy API — available when API key is set
    private var apiGifContent: some View {
        ScrollView {
            if isLoading && apiGifs.isEmpty {
                ProgressView().padding(40)
            } else {
                LazyVGrid(columns: columns, spacing: 3) {
                    ForEach(apiGifs) { gif in
                        SDAnimatedGIFView(url: gif.previewURL)
                            .frame(height: 110)
                            .clipped()
                            .contentShape(Rectangle())
                            .onTapGesture {
                                onGIFSelected(gif.originalURL, gif.width, gif.height)
                                dismiss()
                            }
                    }
                }
                .padding(.horizontal, 3)
            }
        }
    }

    private func fetchGIFs(query: String?) async {
        guard AppConfig.giphyConfigured else { return }
        let endpoint = query == nil ? "trending" : "search"
        var components = URLComponents(string: "https://api.giphy.com/v1/gifs/\(endpoint)")!
        var queryItems: [URLQueryItem] = [
            .init(name: "api_key", value: AppConfig.giphyAPIKey),
            .init(name: "limit", value: "30"),
            .init(name: "rating", value: "g")
        ]
        if let q = query, !q.isEmpty {
            queryItems.append(.init(name: "q", value: q))
        }
        components.queryItems = queryItems
        guard let url = components.url else { return }

        isLoading = true
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let response = try JSONDecoder().decode(GiphyResponse.self, from: data)
            apiGifs = response.data
        } catch {
            print("[GIFPicker] Fetch error: \(error.localizedDescription)")
        }
        isLoading = false
    }
}

// MARK: - View extension for conditional modifier
private extension View {
    @ViewBuilder
    func `if`<Content: View>(_ condition: Bool, transform: (Self) -> Content) -> some View {
        if condition { transform(self) } else { self }
    }
}

// MARK: - SDWebImage animated GIF renderer
struct SDAnimatedGIFView: UIViewRepresentable {
    let url: URL?

    func makeUIView(context: Context) -> SDAnimatedImageView {
        let view = SDAnimatedImageView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.backgroundColor = UIColor.secondarySystemBackground
        return view
    }

    func updateUIView(_ view: SDAnimatedImageView, context: Context) {
        view.sd_setImage(with: url, placeholderImage: nil, options: [.progressiveLoad])
    }
}
