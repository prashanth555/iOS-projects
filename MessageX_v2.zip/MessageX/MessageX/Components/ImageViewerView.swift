import SwiftUI

struct ImageViewerView: View {
    let imageURL: String
    @Environment(\.dismiss) var dismiss
    @State private var scale: CGFloat = 1.0
    @State private var lastScale: CGFloat = 1.0
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero
    @State private var showControls = true
    @State private var showShareSheet = false
    @State private var loadedImage: UIImage?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            if let img = loadedImage {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(scale)
                    .offset(offset)
                    .gesture(
                        MagnificationGesture()
                            .onChanged { value in
                                scale = lastScale * value
                            }
                            .onEnded { _ in
                                lastScale = scale
                                if scale < 1 { withAnimation { scale = 1; lastScale = 1; offset = .zero; lastOffset = .zero } }
                            }
                    )
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                offset = CGSize(width: lastOffset.width + value.translation.width,
                                                height: lastOffset.height + value.translation.height)
                            }
                            .onEnded { _ in lastOffset = offset }
                    )
                    .gesture(TapGesture(count: 2).onEnded {
                        withAnimation {
                            if scale > 1 { scale = 1; lastScale = 1; offset = .zero; lastOffset = .zero }
                            else { scale = 2.5; lastScale = 2.5 }
                        }
                    })
                    .onTapGesture { withAnimation { showControls.toggle() } }
            } else {
                AsyncImage(url: URL(string: imageURL)) { img in
                    img.resizable().scaledToFit()
                        .onAppear {
                            Task {
                                if let url = URL(string: imageURL),
                                   let data = try? Data(contentsOf: url) {
                                    loadedImage = UIImage(data: data)
                                }
                            }
                        }
                } placeholder: { ProgressView().tint(.white) }
            }

            if showControls {
                VStack {
                    HStack {
                        Button { dismiss() } label: {
                            Image(systemName: "xmark")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.white)
                                .padding(12)
                                .background(Color.black.opacity(0.5))
                                .clipShape(Circle())
                        }
                        Spacer()
                        Button { showShareSheet = true } label: {
                            Image(systemName: "square.and.arrow.up")
                                .font(.system(size: 18))
                                .foregroundColor(.white)
                                .padding(12)
                                .background(Color.black.opacity(0.5))
                                .clipShape(Circle())
                        }
                    }
                    .padding()
                    Spacer()

                    // Save button
                    Button {
                        if let img = loadedImage {
                            UIImageWriteToSavedPhotosAlbum(img, nil, nil, nil)
                        }
                    } label: {
                        HStack {
                            Image(systemName: "arrow.down.to.line")
                            Text("Save")
                        }
                        .foregroundColor(.white)
                        .padding(.horizontal, 20).padding(.vertical, 10)
                        .background(Color.black.opacity(0.5))
                        .cornerRadius(20)
                    }
                    .padding(.bottom, 32)
                }
                .transition(.opacity)
            }
        }
        .sheet(isPresented: $showShareSheet) {
            if let img = loadedImage { ShareSheet(items: [img]) }
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}
