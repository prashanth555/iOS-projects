import SwiftUI
import PDFKit

struct PDFPreviewView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> PDFView {
        let pdfView = PDFView()
        pdfView.autoScales = true
        pdfView.displayMode = .singlePageContinuous
        pdfView.displayDirection = .vertical
        return pdfView
    }

    func updateUIView(_ pdfView: PDFView, context: Context) {
        if let document = PDFDocument(url: url) {
            pdfView.document = document
        }
    }
}

struct PDFViewerSheet: View {
    let url: URL
    @Environment(\.dismiss) var dismiss
    @State private var shareItem: URL?
    @State private var showShareSheet = false

    var body: some View {
        NavigationStack {
            PDFPreviewView(url: url)
                .navigationTitle(url.lastPathComponent)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("Done") { dismiss() }
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button {
                            shareItem = url
                            showShareSheet = true
                        } label: {
                            Image(systemName: "square.and.arrow.up")
                        }
                    }
                }
                .sheet(isPresented: $showShareSheet) {
                    if let item = shareItem {
                        ShareSheet(items: [item])
                    }
                }
        }
    }
}

struct PDFPreviewFromURL: View {
    let urlString: String
    @State private var localURL: URL?
    @State private var isLoading = true
    @State private var showViewer = false

    var body: some View {
        Group {
            if isLoading {
                ProgressView("Loading PDF...")
            } else if let url = localURL {
                Button { showViewer = true } label: {
                    HStack {
                        Image(systemName: "doc.richtext.fill").foregroundColor(.red)
                        Text(url.lastPathComponent).lineLimit(1)
                        Spacer()
                        Image(systemName: "arrow.right.circle").foregroundColor(.primaryGreen)
                    }
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(12)
                }
                .sheet(isPresented: $showViewer) { PDFViewerSheet(url: url) }
            }
        }
        .onAppear { downloadPDF() }
    }

    private func downloadPDF() {
        guard let url = URL(string: urlString) else { return }
        URLSession.shared.downloadTask(with: url) { tempURL, _, _ in
            guard let tempURL = tempURL else { return }
            let dest = FileManager.default.temporaryDirectory.appendingPathComponent(url.lastPathComponent)
            try? FileManager.default.moveItem(at: tempURL, to: dest)
            DispatchQueue.main.async {
                localURL = dest
                isLoading = false
            }
        }.resume()
    }
}
