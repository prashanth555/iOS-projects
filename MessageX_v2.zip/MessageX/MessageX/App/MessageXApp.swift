import SwiftUI
import Firebase
import FirebaseAuth
import IQKeyboardManagerSwift

@main
struct MessageXApp: App {
    // AppDelegate must run first (Firebase.configure) before any StateObject initializer fires.
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate

    // Both are singletons; wrapping in @StateObject at the App level is correct —
    // SwiftUI holds one strong reference for the app's lifetime.
    @StateObject private var authViewModel = AuthViewModel()
    @StateObject private var callManager  = CallManager.shared

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(authViewModel)
                .environmentObject(callManager)
        }
    }
}

/// A thin root view that waits for the auth state before showing anything.
/// Keeping it separate from MessageXApp avoids accessing @EnvironmentObject
/// before the scene is fully attached.
private struct RootView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @EnvironmentObject var callManager: CallManager

    var body: some View {
        Group {
            if authViewModel.isLoading {
                SplashView()
            } else if authViewModel.currentUser != nil {
                MainTabView()
            } else {
                LoginView()
            }
        }
        .onReceive(
            NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)
        ) { _ in
            authViewModel.refreshCurrentUser()
        }
    }
}
