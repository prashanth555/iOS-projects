import Foundation
import Firebase
import FirebaseStorage
import UIKit

class StorageService {
    static let shared = StorageService()
    private let storage = Storage.storage()
    private init() {}

    // MARK: - Profile Image
    func uploadProfileImage(_ image: UIImage, userId: String) async throws -> String {
        guard let data = image.jpegData(compressionQuality: 0.7) else {
            throw StorageError.compressionFailed
        }
        let ref = storage.reference().child("profiles/\(userId)/profile.jpg")
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpeg"
        _ = try await ref.putDataAsync(data, metadata: metadata)
        return try await ref.downloadURL().absoluteString
    }

    // MARK: - Chat Image
    func uploadImage(_ image: UIImage, chatId: String) async throws -> Message.MediaData {
        guard let fullData = image.jpegData(compressionQuality: 0.8),
              let thumbData = image.resized(to: CGSize(width: 300, height: 300))?.jpegData(compressionQuality: 0.5)
        else { throw StorageError.compressionFailed }

        let msgId = UUID().uuidString
        let ref = storage.reference().child("chats/\(chatId)/images/\(msgId).jpg")
        let thumbRef = storage.reference().child("chats/\(chatId)/thumbnails/\(msgId)_thumb.jpg")
        let meta = StorageMetadata(); meta.contentType = "image/jpeg"

        async let urlFetch = ref.putDataAsync(fullData, metadata: meta)
        async let thumbFetch = thumbRef.putDataAsync(thumbData, metadata: meta)
        _ = try await (urlFetch, thumbFetch)

        let url = try await ref.downloadURL().absoluteString
        let thumbURL = try await thumbRef.downloadURL().absoluteString
        return Message.MediaData(url: url, thumbnailURL: thumbURL,
                                 width: Int(image.size.width), height: Int(image.size.height),
                                 mimeType: "image/jpeg")
    }

    // MARK: - Chat Video
    func uploadVideo(url localURL: URL, chatId: String) async throws -> Message.MediaData {
        let msgId = UUID().uuidString
        let ref = storage.reference().child("chats/\(chatId)/videos/\(msgId).mp4")
        let meta = StorageMetadata(); meta.contentType = "video/mp4"
        _ = try await ref.putFileAsync(from: localURL, metadata: meta)
        let url = try await ref.downloadURL().absoluteString
        return Message.MediaData(url: url, fileName: "\(msgId).mp4", mimeType: "video/mp4")
    }

    // MARK: - Audio/Voice Note
    func uploadAudio(url localURL: URL, chatId: String) async throws -> Message.MediaData {
        let msgId = UUID().uuidString
        let ref = storage.reference().child("chats/\(chatId)/audio/\(msgId).m4a")
        let meta = StorageMetadata(); meta.contentType = "audio/m4a"
        _ = try await ref.putFileAsync(from: localURL, metadata: meta)
        let url = try await ref.downloadURL().absoluteString
        let size = (try? FileManager.default.attributesOfItem(atPath: localURL.path)[.size] as? Int64) ?? 0
        return Message.MediaData(url: url, fileName: "\(msgId).m4a", fileSize: size, mimeType: "audio/m4a")
    }

    // MARK: - Document / PDF / File
    func uploadDocument(url localURL: URL, chatId: String) async throws -> Message.MediaData {
        let msgId = UUID().uuidString
        let ext = localURL.pathExtension
        let fileName = localURL.lastPathComponent
        let mimeType = mimeType(for: ext)
        let ref = storage.reference().child("chats/\(chatId)/documents/\(msgId).\(ext)")
        let meta = StorageMetadata(); meta.contentType = mimeType
        _ = try await ref.putFileAsync(from: localURL, metadata: meta)
        let url = try await ref.downloadURL().absoluteString
        let size = (try? FileManager.default.attributesOfItem(atPath: localURL.path)[.size] as? Int64) ?? 0
        return Message.MediaData(url: url, fileName: fileName, fileSize: size, mimeType: mimeType)
    }

    // MARK: - Status Media
    func uploadStatusImage(_ image: UIImage, userId: String) async throws -> String {
        guard let data = image.jpegData(compressionQuality: 0.8) else { throw StorageError.compressionFailed }
        let id = UUID().uuidString
        let ref = storage.reference().child("status/\(userId)/\(id).jpg")
        let meta = StorageMetadata(); meta.contentType = "image/jpeg"
        _ = try await ref.putDataAsync(data, metadata: meta)
        return try await ref.downloadURL().absoluteString
    }

    func uploadStatusVideo(url localURL: URL, userId: String) async throws -> String {
        let id = UUID().uuidString
        let ref = storage.reference().child("status/\(userId)/\(id).mp4")
        let meta = StorageMetadata(); meta.contentType = "video/mp4"
        _ = try await ref.putFileAsync(from: localURL, metadata: meta)
        return try await ref.downloadURL().absoluteString
    }

    // MARK: - Download
    func downloadData(from urlString: String, completion: @escaping (Data?) -> Void) {
        guard let url = URL(string: urlString) else { completion(nil); return }
        URLSession.shared.dataTask(with: url) { data, _, _ in completion(data) }.resume()
    }

    // MARK: - Helpers
    private func mimeType(for ext: String) -> String {
        switch ext.lowercased() {
        case "pdf": return "application/pdf"
        case "doc", "docx": return "application/msword"
        case "xls", "xlsx": return "application/vnd.ms-excel"
        case "ppt", "pptx": return "application/vnd.ms-powerpoint"
        case "txt": return "text/plain"
        case "zip": return "application/zip"
        case "mp4": return "video/mp4"
        case "mov": return "video/quicktime"
        case "mp3": return "audio/mpeg"
        case "m4a": return "audio/m4a"
        default: return "application/octet-stream"
        }
    }

    enum StorageError: LocalizedError {
        case compressionFailed
        case uploadFailed
        case downloadFailed

        var errorDescription: String? {
            switch self {
            case .compressionFailed: return "Failed to compress media."
            case .uploadFailed: return "Failed to upload file."
            case .downloadFailed: return "Failed to download file."
            }
        }
    }
}

extension UIImage {
    func resized(to size: CGSize) -> UIImage? {
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { _ in self.draw(in: CGRect(origin: .zero, size: size)) }
    }
}
