import Foundation
import Firebase
import FirebaseFirestore
import Combine

@MainActor
class ChatService: ObservableObject {
    static let shared = ChatService()
    private let db = Firestore.firestore()

    // MARK: - Chat List
    func listenToChats(userId: String, completion: @escaping ([Chat]) -> Void) -> ListenerRegistration {
        return db.collection(Constants.chatsCollection)
            .whereField("participants", arrayContains: userId)
            .order(by: "updatedAt", descending: true)
            .addSnapshotListener { snapshot, error in
                guard let docs = snapshot?.documents else { return }
                let chats = docs.compactMap { try? $0.data(as: Chat.self) }
                completion(chats)
            }
    }

    // MARK: - Messages
    func listenToMessages(chatId: String, completion: @escaping ([Message]) -> Void) -> ListenerRegistration {
        return db.collection(Constants.chatsCollection)
            .document(chatId)
            .collection(Constants.messagesCollection)
            .order(by: "timestamp", descending: false)
            .limit(toLast: 100)
            .addSnapshotListener { snapshot, error in
                guard let docs = snapshot?.documents else { return }
                let messages = docs.compactMap { try? $0.data(as: Message.self) }
                completion(messages)
            }
    }

    func sendMessage(_ message: Message) async throws {
        let data = try Firestore.Encoder().encode(message)
        try await db.collection(Constants.chatsCollection)
            .document(message.chatId)
            .collection(Constants.messagesCollection)
            .document(message.messageId)
            .setData(data)

        // Update chat's last message
        let preview = Chat.LastMessagePreview(
            messageId: message.messageId,
            content: messagePreviewText(message),
            type: message.type,
            senderId: message.senderId,
            senderName: message.senderName,
            timestamp: message.timestamp,
            isDeleted: false
        )
        let previewData = try Firestore.Encoder().encode(preview)
        try await db.collection(Constants.chatsCollection).document(message.chatId).updateData([
            "lastMessage": previewData,
            "updatedAt": Timestamp(date: Date())
        ])

        // Increment unread for other participants
        incrementUnreadCounts(chatId: message.chatId, senderId: message.senderId)
    }

    private func messagePreviewText(_ message: Message) -> String {
        switch message.type {
        case .text: return message.content
        case .image: return "📷 Photo"
        case .video: return "🎥 Video"
        case .audio: return "🎵 Audio"
        case .voiceNote: return "🎤 Voice message"
        case .gif: return "GIF"
        case .document: return "📄 \(message.mediaData?.fileName ?? "Document")"
        case .pdf: return "📋 PDF"
        case .location: return "📍 Location"
        case .contact: return "👤 Contact"
        case .sticker: return "Sticker"
        case .callMissed: return "📞 Missed call"
        case .callEnded: return "📞 Call ended"
        default: return message.content
        }
    }

    private func incrementUnreadCounts(chatId: String, senderId: String) {
        Task {
            do {
                let chatDoc = try await db.collection(Constants.chatsCollection).document(chatId).getDocument()
                guard let chat = try? chatDoc.data(as: Chat.self) else { return }
                var updates: [String: Any] = [:]
                for participantId in chat.participants where participantId != senderId {
                    let currentCount = chat.unreadCount[participantId] ?? 0
                    updates["unreadCount.\(participantId)"] = currentCount + 1
                }
                try await db.collection(Constants.chatsCollection).document(chatId).updateData(updates)
            } catch { print("Error incrementing unread: \(error)") }
        }
    }

    func markAsRead(chatId: String, userId: String, messageIds: [String]) async throws {
        let batch = db.batch()
        for msgId in messageIds {
            let ref = db.collection(Constants.chatsCollection)
                .document(chatId)
                .collection(Constants.messagesCollection)
                .document(msgId)
            batch.updateData(["readBy": FieldValue.arrayUnion([userId])], forDocument: ref)
        }
        try await batch.commit()
        try await db.collection(Constants.chatsCollection).document(chatId).updateData([
            "unreadCount.\(userId)": 0
        ])
    }

    func deleteMessage(chatId: String, messageId: String) async throws {
        try await db.collection(Constants.chatsCollection)
            .document(chatId)
            .collection(Constants.messagesCollection)
            .document(messageId)
            .updateData(["isDeleted": true, "content": "This message was deleted"])
    }

    func editMessage(chatId: String, messageId: String, newContent: String) async throws {
        try await db.collection(Constants.chatsCollection)
            .document(chatId)
            .collection(Constants.messagesCollection)
            .document(messageId)
            .updateData(["content": newContent, "editedAt": Timestamp(date: Date())])
    }

    func addReaction(chatId: String, messageId: String, emoji: String, userId: String) async throws {
        try await db.collection(Constants.chatsCollection)
            .document(chatId)
            .collection(Constants.messagesCollection)
            .document(messageId)
            .updateData(["reactions.\(emoji)": FieldValue.arrayUnion([userId])])
    }

    // MARK: - Create Chat
    func createOrGetChat(with otherUser: MXUser) async throws -> String {
        guard let currentUser = AuthService.shared.currentUser else { throw NSError(domain: "Auth", code: 0) }
        let participants = [currentUser.uid, otherUser.uid].sorted()
        let chatId = participants.joined(separator: "_")

        let chatDoc = try await db.collection(Constants.chatsCollection).document(chatId).getDocument()
        if chatDoc.exists { return chatId }

        let chat = Chat(
            chatId: chatId,
            type: .individual,
            participants: participants,
            currentUser: currentUser,
            otherUser: otherUser
        )
        let data = try Firestore.Encoder().encode(chat)
        try await db.collection(Constants.chatsCollection).document(chatId).setData(data)
        return chatId
    }

    // MARK: - Typing Indicator
    func setTyping(_ isTyping: Bool, chatId: String, userId: String) {
        db.collection(Constants.chatsCollection).document(chatId)
            .collection("typing").document(userId)
            .setData(["isTyping": isTyping, "updatedAt": Timestamp(date: Date())])
    }

    func listenToTyping(chatId: String, excludeUserId: String,
                        completion: @escaping ([String]) -> Void) -> ListenerRegistration {
        return db.collection(Constants.chatsCollection).document(chatId)
            .collection("typing")
            .whereField("isTyping", isEqualTo: true)
            .addSnapshotListener { snapshot, _ in
                let typers = snapshot?.documents
                    .filter { $0.documentID != excludeUserId }
                    .map { $0.documentID } ?? []
                completion(typers)
            }
    }

    // MARK: - Group Chat
    func createGroup(name: String, description: String?, imageURL: String?,
                     members: [MXUser]) async throws -> String {
        guard let currentUser = AuthService.shared.currentUser else { throw NSError(domain: "Auth", code: 0) }
        let chatId = UUID().uuidString
        var allMembers = members
        if !allMembers.contains(where: { $0.uid == currentUser.uid }) {
            allMembers.insert(currentUser, at: 0)
        }
        var participantDetails: [String: Chat.ParticipantInfo] = [:]
        for member in allMembers {
            participantDetails[member.uid] = Chat.ParticipantInfo(
                uid: member.uid,
                displayName: member.displayName,
                profileImageURL: member.profileImageURL,
                isOnline: false,
                role: member.uid == currentUser.uid ? .admin : .member
            )
        }
        var chat = Chat(
            chatId: chatId, type: .group,
            participants: allMembers.map { $0.uid },
            currentUser: currentUser, otherUser: nil
        )
        chat.groupName = name
        chat.groupDescription = description
        chat.groupImageURL = imageURL
        chat.groupAdmins = [currentUser.uid]
        chat.createdBy = currentUser.uid
        chat.participantDetails = participantDetails
        let data = try Firestore.Encoder().encode(chat)
        try await db.collection(Constants.chatsCollection).document(chatId).setData(data)
        return chatId
    }

    func addMembersToGroup(chatId: String, members: [MXUser]) async throws {
        let uids = members.map { $0.uid }
        var updates: [String: Any] = ["participants": FieldValue.arrayUnion(uids)]
        for member in members {
            updates["participantDetails.\(member.uid)"] = [
                "uid": member.uid,
                "displayName": member.displayName,
                "profileImageURL": member.profileImageURL as Any,
                "isOnline": false,
                "role": "member"
            ]
        }
        try await db.collection(Constants.chatsCollection).document(chatId).updateData(updates)
    }
}

// MARK: - Chat init helper
extension Chat {
    init(chatId: String, type: ChatType, participants: [String],
         currentUser: MXUser, otherUser: MXUser?) {
        self.chatId = chatId
        self.type = type
        self.participants = participants
        var details: [String: ParticipantInfo] = [:]
        details[currentUser.uid] = ParticipantInfo(
            uid: currentUser.uid, displayName: currentUser.displayName,
            profileImageURL: currentUser.profileImageURL, isOnline: true)
        if let other = otherUser {
            details[other.uid] = ParticipantInfo(
                uid: other.uid, displayName: other.displayName,
                profileImageURL: other.profileImageURL, isOnline: other.isOnline)
        }
        self.participantDetails = details
        self.unreadCount = [:]
        self.createdAt = Timestamp(date: Date())
        self.updatedAt = Timestamp(date: Date())
        self.mutedBy = []
        self.pinnedBy = []
        self.archivedBy = []
        self.disappearingMessages = .off
        self.groupAdmins = []
    }
}
