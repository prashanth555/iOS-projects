import Foundation
import Firebase
import FirebaseAuth
import FirebaseFirestore
import Combine

@MainActor
class AuthService: ObservableObject {
    static let shared = AuthService()
    private let db = Firestore.firestore()
    private var cancellables = Set<AnyCancellable>()

    @Published var currentUser: MXUser?
    @Published var isAuthenticated = false
    @Published var verificationID: String?

    var currentUserId: String? {
        if DemoMode.isActive { return DemoMode.userID }
        return Auth.auth().currentUser?.uid
    }

    private init() {
        listenToAuthState()
    }

    private func listenToAuthState() {
        guard !DemoMode.isActive else { return }
        Auth.auth().addStateDidChangeListener { [weak self] _, user in
            Task { @MainActor in
                if let user = user {
                    await self?.fetchCurrentUser(uid: user.uid)
                    self?.isAuthenticated = true
                } else {
                    self?.currentUser = nil
                    self?.isAuthenticated = false
                }
            }
        }
    }

    // MARK: - Phone Auth
    func sendOTP(to phoneNumber: String) async throws {
        let verID = try await PhoneAuthProvider.provider().verifyPhoneNumber(phoneNumber, uiDelegate: nil)
        self.verificationID = verID
    }

    func verifyOTP(_ otp: String) async throws {
        guard let verificationID = verificationID else {
            throw AuthError.missingVerificationID
        }
        let credential = PhoneAuthProvider.provider().credential(
            withVerificationID: verificationID, verificationCode: otp
        )
        let result = try await Auth.auth().signIn(with: credential)
        let isNewUser = result.additionalUserInfo?.isNewUser ?? false
        if isNewUser {
            try await createUserDocument(uid: result.user.uid,
                                        phone: result.user.phoneNumber ?? "")
        } else {
            await fetchCurrentUser(uid: result.user.uid)
        }
    }

    // MARK: - Email Auth
    func signIn(email: String, password: String) async throws {
        let result = try await Auth.auth().signIn(withEmail: email, password: password)
        await fetchCurrentUser(uid: result.user.uid)
    }

    func signUp(email: String, password: String, displayName: String) async throws {
        let result = try await Auth.auth().createUser(withEmail: email, password: password)
        try await createUserDocument(uid: result.user.uid, phone: "", displayName: displayName, email: email)
    }

    // MARK: - User Profile
    func createUserDocument(uid: String, phone: String, displayName: String = "", email: String? = nil) async throws {
        var user = MXUser(uid: uid, phoneNumber: phone, displayName: displayName.isEmpty ? phone : displayName)
        user.email = email
        let data = try Firestore.Encoder().encode(user)
        try await db.collection(Constants.usersCollection).document(uid).setData(data)
        self.currentUser = user
    }

    func updateProfile(displayName: String?, bio: String?, imageURL: String?) async throws {
        guard let uid = currentUserId else { return }
        var updates: [String: Any] = [:]
        if let name = displayName { updates["displayName"] = name }
        if let bio = bio { updates["bio"] = bio }
        if let url = imageURL { updates["profileImageURL"] = url }
        try await db.collection(Constants.usersCollection).document(uid).updateData(updates)
        await fetchCurrentUser(uid: uid)
    }

    func fetchCurrentUser(uid: String) async {
        do {
            let doc = try await db.collection(Constants.usersCollection).document(uid).getDocument()
            self.currentUser = try doc.data(as: MXUser.self)
        } catch {
            print("Error fetching user: \(error)")
        }
    }

    func updateOnlineStatus(isOnline: Bool) async {
        guard let uid = currentUserId else { return }
        try? await db.collection(Constants.usersCollection).document(uid).updateData([
            "isOnline": isOnline,
            "lastSeen": Timestamp(date: Date())
        ])
    }

    func signOut() throws {
        Task { await updateOnlineStatus(isOnline: false) }
        try Auth.auth().signOut()
        currentUser = nil
        isAuthenticated = false
    }

    enum AuthError: LocalizedError {
        case missingVerificationID
        case invalidOTP
        case userNotFound

        var errorDescription: String? {
            switch self {
            case .missingVerificationID: return "Verification ID missing. Please request OTP again."
            case .invalidOTP: return "Invalid OTP. Please try again."
            case .userNotFound: return "User not found."
            }
        }
    }
}
