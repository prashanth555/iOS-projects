import Foundation
import Firebase
import FirebaseFirestore
import WebRTC
import CallKit
import AVFoundation

@MainActor
class CallManager: NSObject, ObservableObject {
    static let shared = CallManager()
    private let db = Firestore.firestore()
    private var webRTCClient: WebRTCClient?
    private var callListener: ListenerRegistration?
    private let provider: CXProvider
    private let callController = CXCallController()

    @Published var activeCall: CallSession?
    @Published var callState: CallState = .idle
    @Published var isAudioMuted = false
    @Published var isVideoMuted = false
    @Published var isSpeakerOn = false
    @Published var callDuration: Int = 0

    private var durationTimer: Timer?
    private var callUUID: UUID?

    // Thread-safe mutable box for sharing call identity between the @MainActor
    // class and the nonisolated WebRTC delegate callbacks.
    // We write only from MainActor before WebRTC fires, so the read is safe.
    // @unchecked Sendable compiles on Swift 5.9 / Xcode 15.0+.
    private final class CallStateBox: @unchecked Sendable {
        var callId: String?
        var isCallerRole: Bool = false
    }
    private let callBox = CallStateBox()

    enum CallState {
        case idle, calling, ringing, connected, ended
    }

    private let iceServers = [
        RTCIceServer(urlStrings: ["stun:stun.l.google.com:19302"]),
        RTCIceServer(urlStrings: ["stun:stun1.l.google.com:19302"]),
        RTCIceServer(
            urlStrings: ["turn:openrelay.metered.ca:80"],
            username: "openrelayproject",
            credential: "openrelayproject"
        )
    ]

    override init() {
        let config = CXProviderConfiguration()
        config.supportsVideo = true
        config.maximumCallsPerCallGroup = 1
        config.supportedHandleTypes = [.generic, .phoneNumber]
        provider = CXProvider(configuration: config)
        super.init()
        provider.setDelegate(self, queue: nil)
        listenForIncomingCalls()
    }

    // MARK: - Outgoing Call
    func startCall(to user: MXUser, type: CallSession.CallType) async throws {
        if DemoMode.isActive {
            activeCall = CallSession(callerId: DemoMode.userID, callerName: "You (Demo)",
                                     receiverId: user.uid, receiverName: user.displayName,
                                     type: type, chatId: "demo-chat")
            callState = .connected
            callUUID = UUID()
            startDurationTimer()
            return
        }
        guard let currentUser = AuthService.shared.currentUser else { return }
        let chatId = try await ChatService.shared.createOrGetChat(with: user)
        var session = CallSession(callerId: currentUser.uid, callerName: currentUser.displayName,
                                  receiverId: user.uid, receiverName: user.displayName,
                                  type: type, chatId: chatId)
        session.callerProfileURL = currentUser.profileImageURL
        session.receiverProfileURL = user.profileImageURL

        let uuid = UUID()
        callUUID = uuid
        activeCall = session
        callState = .calling

        // Store for nonisolated delegate access before WebRTC setup
        callBox.callId = session.callId
        callBox.isCallerRole = true

        // CallKit — report outgoing call
        let handle = CXHandle(type: .generic, value: user.displayName)
        let startCallAction = CXStartCallAction(call: uuid, handle: handle)
        startCallAction.isVideo = type == .video
        let transaction = CXTransaction(action: startCallAction)
        try await callController.request(transaction)

        // Setup WebRTC and create offer
        setupWebRTC()
        webRTCClient?.setupLocalMedia(isVideo: type == .video)

        webRTCClient?.createOffer { [weak self] sdp, error in
            guard let self = self, let sdp = sdp else { return }
            var updatedSession = session
            updatedSession.offer = CallSession.RTCSessionData(sdp: sdp.sdp, type: sdp.type.toString())
            Task { @MainActor in
                self.activeCall = updatedSession
                try await self.saveCallSession(updatedSession)
                await self.listenForCallAnswer(callId: updatedSession.callId)
            }
        }
    }

    // MARK: - Accept Incoming Call
    func acceptCall() {
        guard var session = activeCall else { return }
        callBox.isCallerRole = false

        setupWebRTC()
        webRTCClient?.setupLocalMedia(isVideo: session.type == .video)

        guard let offerData = session.offer,
              let sdpType = RTCSdpType.from(string: offerData.type) else { return }

        let sdp = RTCSessionDescription(type: sdpType, sdp: offerData.sdp)
        webRTCClient?.set(remoteSdp: sdp) { [weak self] error in
            guard error == nil else { return }
            self?.webRTCClient?.createAnswer { answer, answerError in
                guard let answer = answer, answerError == nil else { return }
                Task { @MainActor in
                    guard let self = self else { return }
                    try await self.db.collection("calls").document(session.callId).updateData([
                        "answer": ["sdp": answer.sdp, "type": answer.type.toString()],
                        "status": "connected",
                        "startedAt": Timestamp(date: Date())
                    ])
                    self.callState = .connected
                    self.startDurationTimer()
                }
            }
        }

        // Add any already-accumulated caller candidates
        for candidate in session.callerCandidates {
            let ice = RTCIceCandidate(sdp: candidate.candidate,
                                      sdpMLineIndex: candidate.sdpMLineIndex ?? 0,
                                      sdpMid: candidate.sdpMid)
            webRTCClient?.set(remoteCandidate: ice) { _ in }
        }
    }

    // MARK: - Decline / End Call
    func declineCall() {
        guard let session = activeCall else { return }
        Task {
            try? await db.collection("calls").document(session.callId).updateData([
                "status": "declined", "endedAt": Timestamp(date: Date())
            ])
        }
        endCallLocally()
    }

    func endCall() {
        guard let session = activeCall else { return }
        Task {
            try? await db.collection("calls").document(session.callId).updateData([
                "status": "ended",
                "endedAt": Timestamp(date: Date()),
                "duration": callDuration
            ])
        }
        if let uuid = callUUID {
            let endAction = CXEndCallAction(call: uuid)
            let transaction = CXTransaction(action: endAction)
            callController.request(transaction) { _ in }
        }
        endCallLocally()
    }

    private func endCallLocally() {
        webRTCClient?.close()
        webRTCClient = nil
        callListener?.remove()
        callListener = nil
        stopDurationTimer()
        callState = .idle
        activeCall = nil
        callUUID = nil
        callDuration = 0
        isAudioMuted = false
        isVideoMuted = false
        isSpeakerOn = false
        callBox.callId = nil
    }

    // MARK: - Audio/Video Controls
    func toggleMute() {
        isAudioMuted.toggle()
        isAudioMuted ? webRTCClient?.muteAudio() : webRTCClient?.unmuteAudio()
    }

    func toggleVideo() {
        isVideoMuted.toggle()
        isVideoMuted ? webRTCClient?.muteVideo() : webRTCClient?.unmuteVideo()
    }

    func toggleSpeaker() {
        isSpeakerOn.toggle()
        webRTCClient?.enableSpeaker(isSpeakerOn)
    }

    func switchCamera() { webRTCClient?.switchCamera() }

    func getWebRTCClient() -> WebRTCClient? { webRTCClient }

    // MARK: - Helpers
    private func setupWebRTC() {
        webRTCClient = WebRTCClient(iceServers: iceServers)
        webRTCClient?.delegate = self
    }

    private func saveCallSession(_ session: CallSession) async throws {
        let data = try Firestore.Encoder().encode(session)
        try await db.collection("calls").document(session.callId).setData(data)
    }

    private func listenForCallAnswer(callId: String) async {
        callListener?.remove()
        callListener = db.collection("calls").document(callId)
            .addSnapshotListener { [weak self] snapshot, _ in
                guard let self = self,
                      let session = try? snapshot?.data(as: CallSession.self) else { return }
                Task { @MainActor in
                    self.activeCall = session

                    if session.status == .connected, let answerData = session.answer,
                       let sdpType = RTCSdpType.from(string: answerData.type) {
                        let sdp = RTCSessionDescription(type: sdpType, sdp: answerData.sdp)
                        self.webRTCClient?.set(remoteSdp: sdp) { _ in }
                        if self.callState != .connected {
                            self.callState = .connected
                            self.startDurationTimer()
                        }
                    } else if session.status == .declined || session.status == .ended {
                        self.endCallLocally()
                        return
                    }

                    // Apply new ICE candidates from receiver
                    for candidate in session.receiverCandidates {
                        let ice = RTCIceCandidate(sdp: candidate.candidate,
                                                   sdpMLineIndex: candidate.sdpMLineIndex ?? 0,
                                                   sdpMid: candidate.sdpMid)
                        self.webRTCClient?.set(remoteCandidate: ice) { _ in }
                    }
                }
            }
    }

    private func listenForIncomingCalls() {
        guard let uid = AuthService.shared.currentUserId else { return }
        db.collection("calls")
            .whereField("receiverId", isEqualTo: uid)
            .whereField("status", isEqualTo: "calling")
            .addSnapshotListener { [weak self] snapshot, _ in
                guard let self = self,
                      let doc = snapshot?.documents.first,
                      let session = try? doc.data(as: CallSession.self) else { return }
                Task { @MainActor in
                    guard self.activeCall == nil else { return }
                    self.activeCall = session
                    self.callState = .ringing
                    self.callBox.callId = session.callId
                    self.callBox.isCallerRole = false
                    self.reportIncomingCall(session: session)
                }
            }
    }

    private func reportIncomingCall(session: CallSession) {
        let uuid = UUID()
        callUUID = uuid
        let update = CXCallUpdate()
        update.remoteHandle = CXHandle(type: .generic, value: session.callerName)
        update.hasVideo = session.type == .video
        update.localizedCallerName = session.callerName
        provider.reportNewIncomingCall(with: uuid, update: update) { _ in }
    }

    private func startDurationTimer() {
        durationTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.callDuration += 1 }
        }
    }

    private func stopDurationTimer() {
        durationTimer?.invalidate()
        durationTimer = nil
    }
}

// MARK: - WebRTCClientDelegate
extension CallManager: WebRTCClientDelegate {
    // Called on a WebRTC background thread — cannot use await.
    // callBox is an @unchecked Sendable reference type; we write its fields
    // only from MainActor before this delegate can fire, so the read is safe.
    nonisolated func webRTCClient(_ client: WebRTCClient, didGenerateCandidate candidate: RTCIceCandidate) {
        guard let callId = callBox.callId else { return }
        let isCallerRole = callBox.isCallerRole
        let candidateData: [String: Any] = [
            "candidate": candidate.sdp,
            "sdpMid": candidate.sdpMid as Any,
            "sdpMLineIndex": candidate.sdpMLineIndex
        ]
        // Candidates go into the array for the local peer so the remote peer can apply them
        let field = isCallerRole ? "callerCandidates" : "receiverCandidates"
        Firestore.firestore().collection("calls").document(callId)
            .updateData([field: FieldValue.arrayUnion([candidateData])])
    }

    nonisolated func webRTCClient(_ client: WebRTCClient, didChangeConnectionState state: RTCIceConnectionState) {
        Task { @MainActor in
            if state == .failed || state == .disconnected { endCall() }
        }
    }

    nonisolated func webRTCClient(_ client: WebRTCClient, didReceiveData data: Data) {}

    nonisolated func webRTCClient(_ client: WebRTCClient, didReceiveRemoteVideoTrack track: RTCVideoTrack) {}
}

// MARK: - CXProviderDelegate
extension CallManager: CXProviderDelegate {
    nonisolated func providerDidReset(_ provider: CXProvider) {
        Task { @MainActor in endCallLocally() }
    }

    nonisolated func provider(_ provider: CXProvider, perform action: CXAnswerCallAction) {
        Task { @MainActor in acceptCall() }
        action.fulfill()
    }

    nonisolated func provider(_ provider: CXProvider, perform action: CXEndCallAction) {
        Task { @MainActor in endCall() }
        action.fulfill()
    }
}

// MARK: - RTCSdpType Helper
extension RTCSdpType {
    func toString() -> String {
        switch self {
        case .offer: return "offer"
        case .answer: return "answer"
        case .prAnswer: return "pranswer"
        default: return "rollback"
        }
    }

    static func from(string: String) -> RTCSdpType? {
        switch string {
        case "offer": return .offer
        case "answer": return .answer
        case "pranswer": return .prAnswer
        default: return nil
        }
    }
}
