import Foundation
import Firebase
import FirebaseMessaging
import UserNotifications

class NotificationService {
    static let shared = NotificationService()
    private let db = Firestore.firestore()
    private init() {}

    // MARK: - FCM Token
    func updateFCMToken(_ token: String) {
        guard let uid = AuthService.shared.currentUserId else { return }
        db.collection(Constants.usersCollection).document(uid)
            .updateData(["fcmToken": token])
    }

    // MARK: - Push Notifications via Cloud Function
    // Calls the Firebase Cloud Function defined in functions/index.js.
    // The function is authenticated and uses the Admin SDK — the server key
    // never lives in client code.
    func sendPushNotification(to userId: String,
                               title: String,
                               body: String,
                               data: [String: String] = [:]) async {
        // Write a notification request document; the Cloud Function picks it up.
        // This avoids exposing any server key on the client.
        let payload: [String: Any] = [
            "recipientUid": userId,
            "title": title,
            "body": body,
            "data": data,
            "createdAt": Timestamp(date: Date()),
            "processed": false
        ]
        do {
            try await db.collection("notificationQueue").addDocument(data: payload)
        } catch {
            print("[NotificationService] Failed to queue notification: \(error.localizedDescription)")
        }
    }

    // MARK: - Notification tap routing
    func handleNotificationTap(userInfo: [AnyHashable: Any]) {
        if let chatId = userInfo["chatId"] as? String {
            NotificationCenter.default.post(name: .openChat, object: chatId)
        } else if let callId = userInfo["callId"] as? String {
            NotificationCenter.default.post(name: .openCall, object: callId)
        }
    }

    // MARK: - Local notifications (for foreground delivery)
    func scheduleLocalNotification(title: String, body: String, delay: TimeInterval = 0.1) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(delay, 0.1), repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString,
                                            content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("[NotificationService] Local notification error: \(error)")
            }
        }
    }
}

extension Notification.Name {
    static let openChat = Notification.Name("openChat")
    static let openCall = Notification.Name("openCall")
}
