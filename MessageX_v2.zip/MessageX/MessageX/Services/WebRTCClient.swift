import Foundation
import WebRTC

protocol WebRTCClientDelegate: AnyObject {
    func webRTCClient(_ client: WebRTCClient, didGenerateCandidate candidate: RTCIceCandidate)
    func webRTCClient(_ client: WebRTCClient, didChangeConnectionState state: RTCIceConnectionState)
    func webRTCClient(_ client: WebRTCClient, didReceiveData data: Data)
    func webRTCClient(_ client: WebRTCClient, didReceiveRemoteVideoTrack track: RTCVideoTrack)
}

final class WebRTCClient: NSObject {
    weak var delegate: WebRTCClientDelegate?

    private static let factory: RTCPeerConnectionFactory = {
        RTCInitializeSSL()
        let encoderFactory = RTCDefaultVideoEncoderFactory()
        let decoderFactory = RTCDefaultVideoDecoderFactory()
        return RTCPeerConnectionFactory(encoderFactory: encoderFactory,
                                        decoderFactory: decoderFactory)
    }()

    private let peerConnection: RTCPeerConnection
    private let rtcAudioSession = RTCAudioSession.sharedInstance()
    private let audioQueue = DispatchQueue(label: "com.messagex.audio")
    private var videoCapturer: RTCCameraVideoCapturer?
    private var localVideoTrack: RTCVideoTrack?
    private var remoteVideoTrack: RTCVideoTrack?
    private var localDataChannel: RTCDataChannel?
    private var remoteDataChannel: RTCDataChannel?

    private var mediaConstraints: RTCMediaConstraints {
        RTCMediaConstraints(
            mandatoryConstraints: [
                kRTCMediaConstraintsOfferToReceiveAudio: kRTCMediaConstraintsValueTrue,
                kRTCMediaConstraintsOfferToReceiveVideo: kRTCMediaConstraintsValueTrue
            ],
            optionalConstraints: nil
        )
    }

    init(iceServers: [RTCIceServer]) {
        let config = RTCConfiguration()
        config.iceServers = iceServers
        config.sdpSemantics = .unifiedPlan
        config.continualGatheringPolicy = .gatherContinually

        let constraints = RTCMediaConstraints(mandatoryConstraints: nil,
                                              optionalConstraints: ["DtlsSrtpKeyAgreement": kRTCMediaConstraintsValueTrue])
        guard let pc = WebRTCClient.factory.peerConnection(with: config,
                                                           constraints: constraints,
                                                           delegate: nil) else {
            fatalError("RTCPeerConnection could not be created — check WebRTC framework is linked.")
        }
        peerConnection = pc
        super.init()
        peerConnection.delegate = self
    }

    // MARK: - Media Setup
    func setupLocalMedia(isVideo: Bool, localRenderer: RTCVideoRenderer? = nil) {
        addAudioTrack()
        if isVideo {
            addVideoTrack(localRenderer: localRenderer)
        }
        setupDataChannel()
    }

    private func addAudioTrack() {
        let audioConstraints = RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: nil)
        let audioSource = WebRTCClient.factory.audioSource(with: audioConstraints)
        let audioTrack = WebRTCClient.factory.audioTrack(with: audioSource, trackId: "audio0")
        peerConnection.add(audioTrack, streamIds: ["stream0"])
        configureAudioSession()
    }

    private func addVideoTrack(localRenderer: RTCVideoRenderer?) {
        let videoSource = WebRTCClient.factory.videoSource()
        let capturer = RTCCameraVideoCapturer(delegate: videoSource)
        self.videoCapturer = capturer

        let videoTrack = WebRTCClient.factory.videoTrack(with: videoSource, trackId: "video0")
        self.localVideoTrack = videoTrack
        if let renderer = localRenderer { videoTrack.add(renderer) }
        peerConnection.add(videoTrack, streamIds: ["stream0"])
        startCapture()
    }

    private func startCapture() {
        guard let capturer = videoCapturer,
              let device = RTCCameraVideoCapturer.captureDevices()
                .first(where: { $0.position == .front }) else { return }
        let format = RTCCameraVideoCapturer.supportedFormats(for: device).last!
        let fps = format.videoSupportedFrameRateRanges.first?.maxFrameRate ?? 30
        capturer.startCapture(with: device, format: format, fps: Int(fps))
    }

    func switchCamera() {
        guard let capturer = videoCapturer,
              let currentDevice = capturer.captureSession.inputs.first as? AVCaptureDeviceInput else { return }
        let newPosition: AVCaptureDevice.Position = currentDevice.device.position == .front ? .back : .front
        guard let newDevice = RTCCameraVideoCapturer.captureDevices()
                .first(where: { $0.position == newPosition }) else { return }
        let format = RTCCameraVideoCapturer.supportedFormats(for: newDevice).last!
        let fps = format.videoSupportedFrameRateRanges.first?.maxFrameRate ?? 30
        capturer.startCapture(with: newDevice, format: format, fps: Int(fps))
    }

    func renderRemoteVideo(to renderer: RTCVideoRenderer) {
        remoteVideoTrack?.add(renderer)
    }

    // MARK: - Offer / Answer
    func createOffer(completion: @escaping (RTCSessionDescription?, Error?) -> Void) {
        peerConnection.offer(for: mediaConstraints) { [weak self] sdp, error in
            guard let self = self, let sdp = sdp else { completion(nil, error); return }
            self.peerConnection.setLocalDescription(sdp) { error in
                completion(sdp, error)
            }
        }
    }

    func createAnswer(completion: @escaping (RTCSessionDescription?, Error?) -> Void) {
        peerConnection.answer(for: mediaConstraints) { [weak self] sdp, error in
            guard let self = self, let sdp = sdp else { completion(nil, error); return }
            self.peerConnection.setLocalDescription(sdp) { error in
                completion(sdp, error)
            }
        }
    }

    func set(remoteSdp: RTCSessionDescription, completion: @escaping (Error?) -> Void) {
        peerConnection.setRemoteDescription(remoteSdp, completionHandler: completion)
    }

    func set(remoteCandidate: RTCIceCandidate, completion: @escaping (Error?) -> Void) {
        peerConnection.add(remoteCandidate, completionHandler: completion)
    }

    // MARK: - Audio Control
    func muteAudio() {
        audioQueue.async { [weak self] in
            self?.rtcAudioSession.lockForConfiguration()
            self?.peerConnection.transceivers
                .compactMap { $0.sender.track as? RTCAudioTrack }
                .forEach { $0.isEnabled = false }
            self?.rtcAudioSession.unlockForConfiguration()
        }
    }

    func unmuteAudio() {
        audioQueue.async { [weak self] in
            self?.rtcAudioSession.lockForConfiguration()
            self?.peerConnection.transceivers
                .compactMap { $0.sender.track as? RTCAudioTrack }
                .forEach { $0.isEnabled = true }
            self?.rtcAudioSession.unlockForConfiguration()
        }
    }

    func enableSpeaker(_ enabled: Bool) {
        audioQueue.async { [weak self] in
            self?.rtcAudioSession.lockForConfiguration()
            try? self?.rtcAudioSession.overrideOutputAudioPort(enabled ? .speaker : .none)
            self?.rtcAudioSession.unlockForConfiguration()
        }
    }

    // MARK: - Video Control
    func muteVideo() {
        localVideoTrack?.isEnabled = false
    }

    func unmuteVideo() {
        localVideoTrack?.isEnabled = true
    }

    // MARK: - Data Channel
    private func setupDataChannel() {
        let config = RTCDataChannelConfiguration()
        config.isOrdered = true
        localDataChannel = peerConnection.dataChannel(forLabel: "data", configuration: config)
        localDataChannel?.delegate = self
    }

    func sendData(_ data: Data) {
        let buffer = RTCDataBuffer(data: data, isBinary: true)
        localDataChannel?.sendData(buffer)
    }

    // MARK: - Audio Session
    private func configureAudioSession() {
        rtcAudioSession.lockForConfiguration()
        try? rtcAudioSession.setCategory(.playAndRecord, mode: .voiceChat, options: [.allowBluetooth])
        try? rtcAudioSession.setActive(true)
        rtcAudioSession.unlockForConfiguration()
    }

    // MARK: - Cleanup
    func close() {
        videoCapturer?.stopCapture()
        localVideoTrack = nil
        remoteVideoTrack = nil
        peerConnection.close()
    }
}

// MARK: - RTCPeerConnectionDelegate
extension WebRTCClient: RTCPeerConnectionDelegate {
    func peerConnectionShouldNegotiate(_ peerConnection: RTCPeerConnection) {}

    func peerConnection(_ peerConnection: RTCPeerConnection, didChange state: RTCSignalingState) {}

    func peerConnection(_ peerConnection: RTCPeerConnection, didAdd stream: RTCMediaStream) {
        remoteVideoTrack = stream.videoTracks.first
        if let track = remoteVideoTrack {
            delegate?.webRTCClient(self, didReceiveRemoteVideoTrack: track)
        }
    }

    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove stream: RTCMediaStream) {}

    func peerConnection(_ peerConnection: RTCPeerConnection,
                        didChange newState: RTCIceConnectionState) {
        delegate?.webRTCClient(self, didChangeConnectionState: newState)
    }

    func peerConnection(_ peerConnection: RTCPeerConnection,
                        didChange newState: RTCIceGatheringState) {}

    func peerConnection(_ peerConnection: RTCPeerConnection,
                        didGenerate candidate: RTCIceCandidate) {
        delegate?.webRTCClient(self, didGenerateCandidate: candidate)
    }

    func peerConnection(_ peerConnection: RTCPeerConnection,
                        didRemove candidates: [RTCIceCandidate]) {}

    func peerConnection(_ peerConnection: RTCPeerConnection,
                        didOpen dataChannel: RTCDataChannel) {
        remoteDataChannel = dataChannel
        dataChannel.delegate = self
    }
}

// MARK: - RTCDataChannelDelegate
extension WebRTCClient: RTCDataChannelDelegate {
    func dataChannelDidChangeState(_ dataChannel: RTCDataChannel) {}

    func dataChannel(_ dataChannel: RTCDataChannel, didReceiveMessageWith buffer: RTCDataBuffer) {
        delegate?.webRTCClient(self, didReceiveData: buffer.data)
    }
}
