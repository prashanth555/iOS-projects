import Foundation
import Contacts
import Firebase
import FirebaseFirestore

class ContactsService {
    static let shared = ContactsService()
    private let db = Firestore.firestore()
    private init() {}

    // Fetch device contacts and find which ones use MessageX
    func syncContacts() async throws -> [MXUser] {
        let deviceNumbers = try fetchDevicePhoneNumbers()
        guard !deviceNumbers.isEmpty else { return [] }

        // Firestore whereField arrayContainsAny is limited to 10 items; batch
        var appUsers: [MXUser] = []
        let chunks = stride(from: 0, to: deviceNumbers.count, by: 10).map {
            Array(deviceNumbers[$0..<min($0 + 10, deviceNumbers.count)])
        }
        for chunk in chunks {
            let snapshot = try await db.collection(Constants.usersCollection)
                .whereField("phoneNumber", in: chunk)
                .getDocuments()
            let users = snapshot.documents.compactMap { try? $0.data(as: MXUser.self) }
            appUsers.append(contentsOf: users)
        }
        return appUsers.filter { $0.uid != AuthService.shared.currentUserId }
    }

    private func fetchDevicePhoneNumbers() throws -> [String] {
        var numbers: [String] = []
        let store = CNContactStore()
        let keys = [CNContactPhoneNumbersKey as CNKeyDescriptor]
        let request = CNContactFetchRequest(keysToFetch: keys)
        try store.enumerateContacts(with: request) { contact, _ in
            for phone in contact.phoneNumbers {
                let num = phone.value.stringValue
                    .replacingOccurrences(of: " ", with: "")
                    .replacingOccurrences(of: "-", with: "")
                    .replacingOccurrences(of: "(", with: "")
                    .replacingOccurrences(of: ")", with: "")
                if num.count >= 10 { numbers.append(num) }
            }
        }
        return Array(Set(numbers))
    }

    func requestContactsAccess() async -> Bool {
        return await withCheckedContinuation { continuation in
            CNContactStore().requestAccess(for: .contacts) { granted, _ in
                continuation.resume(returning: granted)
            }
        }
    }

    func searchUsers(query: String) async throws -> [MXUser] {
        let snapshot = try await db.collection(Constants.usersCollection)
            .whereField("phoneNumber", isGreaterThanOrEqualTo: query)
            .whereField("phoneNumber", isLessThan: query + "\u{f8ff}")
            .limit(to: 20)
            .getDocuments()
        return snapshot.documents
            .compactMap { try? $0.data(as: MXUser.self) }
            .filter { $0.uid != AuthService.shared.currentUserId }
    }

    func blockUser(userId: String) async throws {
        guard let currentUserId = AuthService.shared.currentUserId else { return }
        try await db.collection(Constants.usersCollection).document(currentUserId).updateData([
            "blockedUsers": FieldValue.arrayUnion([userId])
        ])
    }

    func unblockUser(userId: String) async throws {
        guard let currentUserId = AuthService.shared.currentUserId else { return }
        try await db.collection(Constants.usersCollection).document(currentUserId).updateData([
            "blockedUsers": FieldValue.arrayRemove([userId])
        ])
    }
}
