import Foundation
import Firebase
import FirebaseFirestore

// DemoMode activates automatically when the placeholder GoogleService-Info.plist is present.
// All screens, navigation, and UI features work without any Firebase configuration.
enum DemoMode {

    static var isActive: Bool {
        FirebaseApp.app()?.options.projectID?.hasPrefix("messagex-placeholder") ?? false
    }

    // MARK: - Demo Users
    static let userID    = "demo-me-001"
    static let aliceID   = "demo-alice-002"
    static let bobID     = "demo-bob-003"
    static let emmaID    = "demo-emma-004"
    static let groupID   = "demo-group-001"

    static var currentUser: MXUser {
        var u = MXUser(uid: userID, phoneNumber: "+1 (555) 000-0001", displayName: "You (Demo)")
        u.bio = "Hey there! I'm using MessageX."
        u.isOnline = true
        return u
    }

    // MARK: - Sample Chats
    static var sampleChats: [Chat] {
        let now = Timestamp(date: Date())
        let oneHourAgo = Timestamp(date: Date().addingTimeInterval(-3600))
        let yesterday   = Timestamp(date: Date().addingTimeInterval(-86400))
        let twoDaysAgo  = Timestamp(date: Date().addingTimeInterval(-172800))

        // Chat 1 — Alice Johnson (online, 2 unread)
        var chat1 = Chat(
            chatId: "demo-chat-alice",
            type: .individual,
            participants: [userID, aliceID],
            participantDetails: [
                userID:  Chat.ParticipantInfo(uid: userID,  displayName: "You (Demo)",     isOnline: true),
                aliceID: Chat.ParticipantInfo(uid: aliceID, displayName: "Alice Johnson",  isOnline: true)
            ],
            unreadCount: [userID: 2, aliceID: 0],
            createdAt: twoDaysAgo,
            updatedAt: now,
            mutedBy: [], pinnedBy: [], archivedBy: [],
            disappearingMessages: .off,
            groupAdmins: []
        )
        chat1.lastMessage = Chat.LastMessagePreview(
            messageId: "m-alice-last",
            content: "Hey! Are you free this weekend? 😊",
            type: .text, senderId: aliceID, senderName: "Alice Johnson",
            timestamp: now, isDeleted: false
        )

        // Chat 2 — Bob Smith (offline, PDF shared)
        var chat2 = Chat(
            chatId: "demo-chat-bob",
            type: .individual,
            participants: [userID, bobID],
            participantDetails: [
                userID: Chat.ParticipantInfo(uid: userID,  displayName: "You (Demo)",  isOnline: true),
                bobID:  Chat.ParticipantInfo(uid: bobID,   displayName: "Bob Smith",   isOnline: false)
            ],
            unreadCount: [userID: 0, bobID: 0],
            createdAt: twoDaysAgo,
            updatedAt: oneHourAgo,
            mutedBy: [], pinnedBy: [], archivedBy: [],
            disappearingMessages: .off,
            groupAdmins: []
        )
        chat2.lastMessage = Chat.LastMessagePreview(
            messageId: "m-bob-last",
            content: "📋 PDF",
            type: .pdf, senderId: userID, senderName: "You",
            timestamp: oneHourAgo, isDeleted: false
        )

        // Chat 3 — Group "Weekend Trip 🏖️"
        var chat3 = Chat(
            chatId: "demo-chat-group",
            type: .group,
            participants: [userID, aliceID, bobID],
            participantDetails: [
                userID:  Chat.ParticipantInfo(uid: userID,  displayName: "You (Demo)",    isOnline: true,  role: .admin),
                aliceID: Chat.ParticipantInfo(uid: aliceID, displayName: "Alice Johnson", isOnline: true,  role: .member),
                bobID:   Chat.ParticipantInfo(uid: bobID,   displayName: "Bob Smith",     isOnline: false, role: .member)
            ],
            unreadCount: [userID: 1, aliceID: 0, bobID: 0],
            createdAt: yesterday,
            updatedAt: oneHourAgo,
            mutedBy: [], pinnedBy: [userID], archivedBy: [],
            disappearingMessages: .off,
            groupAdmins: [userID]
        )
        chat3.groupName = "Weekend Trip 🏖️"
        chat3.groupDescription = "Planning our beach trip!"
        chat3.createdBy = userID
        chat3.lastMessage = Chat.LastMessagePreview(
            messageId: "m-group-last",
            content: "I'll book the hotel tonight",
            type: .text, senderId: aliceID, senderName: "Alice",
            timestamp: oneHourAgo, isDeleted: false
        )

        // Chat 4 — Emma Wilson
        var chat4 = Chat(
            chatId: "demo-chat-emma",
            type: .individual,
            participants: [userID, emmaID],
            participantDetails: [
                userID:  Chat.ParticipantInfo(uid: userID,  displayName: "You (Demo)", isOnline: true),
                emmaID:  Chat.ParticipantInfo(uid: emmaID,  displayName: "Emma Wilson", isOnline: true)
            ],
            unreadCount: [userID: 0, emmaID: 0],
            createdAt: twoDaysAgo,
            updatedAt: yesterday,
            mutedBy: [], pinnedBy: [], archivedBy: [],
            disappearingMessages: .off,
            groupAdmins: []
        )
        chat4.lastMessage = Chat.LastMessagePreview(
            messageId: "m-emma-last",
            content: "😂 That's hilarious!",
            type: .text, senderId: emmaID, senderName: "Emma Wilson",
            timestamp: yesterday, isDeleted: false
        )

        return [chat1, chat2, chat3, chat4]
    }

    // MARK: - Sample Messages
    static func sampleMessages(for chatId: String) -> [Message] {
        switch chatId {
        case "demo-chat-alice": return aliceMessages
        case "demo-chat-bob":   return bobMessages
        case "demo-chat-group": return groupMessages
        case "demo-chat-emma":  return emmaMessages
        default: return []
        }
    }

    private static var aliceMessages: [Message] {
        let t = { (offset: Double) in Timestamp(date: Date().addingTimeInterval(offset)) }
        return [
            msg(id: "a1", chat: "demo-chat-alice", sender: aliceID, name: "Alice Johnson",
                content: "Hey! 👋 How are you?", type: .text, at: t(-7200)),
            msg(id: "a2", chat: "demo-chat-alice", sender: userID,  name: "You",
                content: "I'm great! Just finished work. You?", type: .text, at: t(-7100)),
            msg(id: "a3", chat: "demo-chat-alice", sender: aliceID, name: "Alice Johnson",
                content: "Same here! Finally done with that project 🎉", type: .text, at: t(-7000)),
            msg(id: "a4", chat: "demo-chat-alice", sender: userID,  name: "You",
                content: "Congrats! That was a tough one 💪", type: .text, at: t(-3600)),
            msg(id: "a5", chat: "demo-chat-alice", sender: aliceID, name: "Alice Johnson",
                content: "Thanks! Hey, are you free this weekend?", type: .text, at: t(-1800)),
            msg(id: "a6", chat: "demo-chat-alice", sender: aliceID, name: "Alice Johnson",
                content: "Hey! Are you free this weekend? 😊", type: .text, at: t(-300)),
        ]
    }

    private static var bobMessages: [Message] {
        let t = { (offset: Double) in Timestamp(date: Date().addingTimeInterval(offset)) }
        var pdfMsg = msg(id: "b3", chat: "demo-chat-bob", sender: userID, name: "You",
                         content: "📋 PDF", type: .pdf, at: t(-3600))
        pdfMsg.mediaData = Message.MediaData(
            url: "https://www.w3.org/WAI/WCAG21/Techniques/pdf/sample.pdf",
            fileName: "Project_Report.pdf",
            fileSize: 204800,
            mimeType: "application/pdf"
        )
        return [
            msg(id: "b1", chat: "demo-chat-bob", sender: bobID,   name: "Bob Smith",
                content: "Can you send me the report PDF?", type: .text, at: t(-7200)),
            msg(id: "b2", chat: "demo-chat-bob", sender: userID,  name: "You",
                content: "Sure, one sec!", type: .text, at: t(-7100)),
            pdfMsg,
            msg(id: "b4", chat: "demo-chat-bob", sender: bobID,   name: "Bob Smith",
                content: "Thanks for the PDF! 🙏", type: .text, at: t(-3500)),
            msg(id: "b5", chat: "demo-chat-bob", sender: userID,  name: "You",
                content: "No problem! Let me know if you need anything else", type: .text, at: t(-3400)),
        ]
    }

    private static var groupMessages: [Message] {
        let t = { (offset: Double) in Timestamp(date: Date().addingTimeInterval(offset)) }
        return [
            msg(id: "g1", chat: "demo-chat-group", sender: userID,  name: "You",
                content: "Hey everyone! Shall we plan the beach trip?", type: .text, at: t(-86400)),
            msg(id: "g2", chat: "demo-chat-group", sender: aliceID, name: "Alice Johnson",
                content: "Yes!! I've been waiting for this 🏖️", type: .text, at: t(-85000)),
            msg(id: "g3", chat: "demo-chat-group", sender: bobID,   name: "Bob Smith",
                content: "Count me in! Which beach?", type: .text, at: t(-84000)),
            msg(id: "g4", chat: "demo-chat-group", sender: userID,  name: "You",
                content: "I was thinking Malibu 🌊", type: .text, at: t(-83000)),
            msg(id: "g5", chat: "demo-chat-group", sender: aliceID, name: "Alice Johnson",
                content: "Perfect! What dates work for everyone?", type: .text, at: t(-7200)),
            msg(id: "g6", chat: "demo-chat-group", sender: bobID,   name: "Bob Smith",
                content: "Next weekend works for me", type: .text, at: t(-3600)),
            msg(id: "g7", chat: "demo-chat-group", sender: aliceID, name: "Alice Johnson",
                content: "I'll book the hotel tonight", type: .text, at: t(-1800)),
        ]
    }

    private static var emmaMessages: [Message] {
        let t = { (offset: Double) in Timestamp(date: Date().addingTimeInterval(offset)) }
        return [
            msg(id: "e1", chat: "demo-chat-emma", sender: userID,  name: "You",
                content: "Did you see that video I sent?", type: .text, at: t(-86400)),
            msg(id: "e2", chat: "demo-chat-emma", sender: emmaID,  name: "Emma Wilson",
                content: "Yes omg 😂😂", type: .text, at: t(-85900)),
            msg(id: "e3", chat: "demo-chat-emma", sender: userID,  name: "You",
                content: "Right?! Couldn't stop laughing", type: .text, at: t(-85800)),
            msg(id: "e4", chat: "demo-chat-emma", sender: emmaID,  name: "Emma Wilson",
                content: "😂 That's hilarious!", type: .text, at: t(-85700)),
        ]
    }

    private static func msg(id: String, chat: String, sender: String, name: String,
                             content: String, type: Message.MessageType,
                             at timestamp: Timestamp) -> Message {
        var m = Message(chatId: chat, senderId: sender, senderName: name,
                        content: content, type: type)
        m.messageId = id
        m.timestamp = timestamp
        m.readBy = [userID, sender].filter { _ in true }
        m.deliveredTo = [userID, sender]
        return m
    }
}
