import Foundation

/// Centralised app configuration.
/// Replace placeholder values before distributing the app.
enum AppConfig {
    /// Giphy API key — get a free one at https://developers.giphy.com
    /// Set the GIPHY_API_KEY environment variable in your Xcode scheme,
    /// or replace the string literal below.
    static let giphyAPIKey: String = {
        if let key = ProcessInfo.processInfo.environment["GIPHY_API_KEY"], !key.isEmpty {
            return key
        }
        return "" // set your key here or via the Xcode scheme environment variable
    }()

    static var giphyConfigured: Bool { !giphyAPIKey.isEmpty }
}
