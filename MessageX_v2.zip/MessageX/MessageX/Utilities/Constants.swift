import Foundation

struct Constants {
    // Firestore Collections
    static let usersCollection = "users"
    static let chatsCollection = "chats"
    static let messagesCollection = "messages"
    static let statusCollection = "status"
    static let callsCollection = "calls"

    // Storage Paths
    static let profilesStoragePath = "profiles"
    static let chatsStoragePath = "chats"
    static let statusStoragePath = "status"

    // App
    static let appName = "MessageX"
    static let maxMediaUploadSizeMB: Double = 100

    // Message limits
    static let textMessageMaxLength = 65536
    static let statusMaxLength = 700
    static let maxGroupMembers = 256
}
