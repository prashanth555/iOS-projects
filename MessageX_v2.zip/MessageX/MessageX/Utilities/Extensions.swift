import Foundation
import SwiftUI
import FirebaseFirestore
import AVFoundation

// MARK: - Date Formatting
extension Date {
    var chatTimestamp: String {
        let calendar = Calendar.current
        if calendar.isDateInToday(self) {
            let f = DateFormatter(); f.timeStyle = .short; return f.string(from: self)
        } else if calendar.isDateInYesterday(self) {
            return "Yesterday"
        } else if calendar.isDate(self, equalTo: Date(), toGranularity: .weekOfYear) {
            let f = DateFormatter(); f.dateFormat = "EEE"; return f.string(from: self)
        } else {
            let f = DateFormatter(); f.dateFormat = "dd/MM/yy"; return f.string(from: self)
        }
    }

    var messageTime: String {
        let f = DateFormatter(); f.timeStyle = .short; return f.string(from: self)
    }

    var fullDateTime: String {
        let f = DateFormatter(); f.dateStyle = .medium; f.timeStyle = .short
        return f.string(from: self)
    }
}

extension Timestamp {
    var chatTimestamp: String { dateValue().chatTimestamp }
    var messageTime: String { dateValue().messageTime }
}

// MARK: - File Size
extension Int64 {
    var fileSizeString: String {
        let kb = Double(self) / 1024
        let mb = kb / 1024
        if mb >= 1 { return String(format: "%.1f MB", mb) }
        return String(format: "%.0f KB", kb)
    }
}

// MARK: - Duration
extension Double {
    var durationString: String {
        let total = Int(self)
        let minutes = total / 60
        let seconds = total % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}

// MARK: - Color
extension Color {
    static let messageBubbleSent = Color("BubbleSent", bundle: nil)
    static let messageBubbleReceived = Color("BubbleReceived", bundle: nil)
    static let primaryGreen = Color(red: 0.075, green: 0.741, blue: 0.455)
    static let darkBackground = Color(UIColor.systemBackground)

    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let r = Double((int >> 16) & 0xFF) / 255
        let g = Double((int >> 8) & 0xFF) / 255
        let b = Double(int & 0xFF) / 255
        self.init(red: r, green: g, blue: b)
    }
}

// MARK: - View Modifiers
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }

    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),
                                        to: nil, from: nil, for: nil)
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat
    var corners: UIRectCorner

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners,
                                 cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

// MARK: - String
extension String {
    var isValidPhoneNumber: Bool {
        let cleaned = replacingOccurrences(of: "[^0-9+]", with: "", options: .regularExpression)
        return cleaned.count >= 10 && cleaned.count <= 15
    }

    var containsURL: Bool {
        guard let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) else {
            return false
        }
        return detector.firstMatch(in: self, range: NSRange(startIndex..., in: self)) != nil
    }

    func detectURLs() -> [URL] {
        guard let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) else {
            return []
        }
        return detector.matches(in: self, range: NSRange(startIndex..., in: self))
            .compactMap { $0.url }
    }
}

// MARK: - AVAudioSession
extension AVAudioSession {
    static func activateForPlayback() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try? AVAudioSession.sharedInstance().setActive(true)
    }
}

// MARK: - Image Gradient Overlay
extension View {
    func gradientOverlay() -> some View {
        self.overlay(
            LinearGradient(
                gradient: Gradient(colors: [.clear, .black.opacity(0.4)]),
                startPoint: .top, endPoint: .bottom
            )
        )
    }
}
