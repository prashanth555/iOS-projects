import Foundation
import Firebase
import SwiftUI

@MainActor
class StatusViewModel: ObservableObject {
    @Published var myStatus: UserStatus?
    @Published var contactStatuses: [UserStatus] = []
    @Published var isLoading = false

    private let db = Firestore.firestore()

    init() { loadStatuses() }

    func loadStatuses() {
        guard let uid = AuthService.shared.currentUserId else { return }
        isLoading = true

        // Listen to my status
        db.collection(Constants.statusCollection).document(uid)
            .addSnapshotListener { [weak self] snap, _ in
                Task { @MainActor in
                    self?.myStatus = try? snap?.data(as: UserStatus.self)
                }
            }

        // Listen to contacts' statuses
        db.collection(Constants.statusCollection)
            .whereField("userId", isNotEqualTo: uid)
            .whereField("expiresAt", isGreaterThan: Timestamp(date: Date()))
            .order(by: "userId")
            .order(by: "expiresAt", descending: true)
            .addSnapshotListener { [weak self] snap, _ in
                Task { @MainActor in
                    let statuses = snap?.documents.compactMap { try? $0.data(as: UserStatus.self) } ?? []
                    self?.contactStatuses = statuses
                    self?.isLoading = false
                }
            }
    }

    func postTextStatus(text: String, backgroundColor: String, textColor: String) async throws {
        guard let currentUser = AuthService.shared.currentUser else { return }
        let item = UserStatus.StatusItem(
            id: UUID().uuidString,
            type: .text,
            content: text,
            backgroundColor: backgroundColor,
            textColor: textColor,
            duration: 5,
            viewers: [],
            timestamp: Timestamp(date: Date()),
            privacy: .everyone
        )
        try await saveStatus(for: currentUser, item: item)
    }

    func postImageStatus(image: UIImage, caption: String?) async throws {
        guard let currentUser = AuthService.shared.currentUser else { return }
        let imageURL = try await StorageService.shared.uploadStatusImage(image, userId: currentUser.uid)
        let item = UserStatus.StatusItem(
            id: UUID().uuidString,
            type: .image,
            content: imageURL,
            caption: caption,
            duration: 5,
            viewers: [],
            timestamp: Timestamp(date: Date()),
            privacy: .everyone
        )
        try await saveStatus(for: currentUser, item: item)
    }

    func postVideoStatus(videoURL: URL, caption: String?) async throws {
        guard let currentUser = AuthService.shared.currentUser else { return }
        let url = try await StorageService.shared.uploadStatusVideo(url: videoURL, userId: currentUser.uid)
        let item = UserStatus.StatusItem(
            id: UUID().uuidString,
            type: .video,
            content: url,
            caption: caption,
            duration: 15,
            viewers: [],
            timestamp: Timestamp(date: Date()),
            privacy: .everyone
        )
        try await saveStatus(for: currentUser, item: item)
    }

    private func saveStatus(for user: MXUser, item: UserStatus.StatusItem) async throws {
        let statusDoc = db.collection(Constants.statusCollection).document(user.uid)
        let doc = try await statusDoc.getDocument()

        if let existing = try? doc.data(as: UserStatus.self) {
            var items = existing.items
            items.append(item)
            try await statusDoc.updateData([
                "items": try Firestore.Encoder().encode(items),
                "expiresAt": Timestamp(date: Date().addingTimeInterval(86400))
            ])
        } else {
            let status = UserStatus(
                statusId: user.uid,
                userId: user.uid,
                userName: user.displayName,
                userProfileURL: user.profileImageURL,
                items: [item],
                createdAt: Timestamp(date: Date()),
                expiresAt: Timestamp(date: Date().addingTimeInterval(86400))
            )
            let data = try Firestore.Encoder().encode(status)
            try await statusDoc.setData(data)
        }
    }

    func markItemViewed(statusId: String, itemId: String) async {
        guard let uid = AuthService.shared.currentUserId else { return }
        do {
            // Firestore can't update an element inside an array field directly,
            // so we fetch the document, mutate the item, and write it back.
            let docRef = db.collection(Constants.statusCollection).document(statusId)
            let snap = try await docRef.getDocument()
            guard var status = try? snap.data(as: UserStatus.self) else { return }
            guard let idx = status.items.firstIndex(where: { $0.id == itemId }) else { return }
            guard !status.items[idx].viewers.contains(uid) else { return }
            status.items[idx].viewers.append(uid)
            let encodedItems = try Firestore.Encoder().encode(status.items)
            try await docRef.updateData(["items": encodedItems])
        } catch {
            print("[StatusViewModel] markItemViewed error: \(error.localizedDescription)")
        }
    }

    func deleteMyStatus() async {
        guard let uid = AuthService.shared.currentUserId else { return }
        try? await db.collection(Constants.statusCollection).document(uid).delete()
    }

    var viewedStatuses: [UserStatus] { contactStatuses.filter { $0.isViewed } }
    var unviewedStatuses: [UserStatus] { contactStatuses.filter { !$0.isViewed } }
}
