import SwiftUI
import PhotosUI

struct CreateStatusView: View {
    @ObservedObject var viewModel: StatusViewModel
    @Environment(\.dismiss) var dismiss
    @State private var selectedTab = 0
    @State private var statusText = ""
    @State private var selectedBGColor = "#25D366"
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var statusImage: UIImage?
    @State private var caption = ""
    @State private var isPosting = false

    private let bgColors = ["#25D366", "#128C7E", "#075E54", "#FF6B6B", "#4ECDC4",
                             "#45B7D1", "#96CEB4", "#FFEAA7", "#DDA0DD", "#000000"]

    var body: some View {
        NavigationStack {
            TabView(selection: $selectedTab) {
                // Text status
                textStatusEditor.tag(0)
                    .tabItem { Label("Text", systemImage: "textformat") }

                // Photo/Video status
                photoStatusEditor.tag(1)
                    .tabItem { Label("Photo", systemImage: "photo") }
            }
            .navigationTitle("Create Status")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: post) {
                        if isPosting { ProgressView() }
                        else { Text("Post").bold().foregroundColor(.primaryGreen) }
                    }
                    .disabled(isPosting || canPost == false)
                }
            }
        }
    }

    private var textStatusEditor: some View {
        ZStack {
            Color(hex: selectedBGColor).ignoresSafeArea()
            VStack {
                Spacer()
                TextField("Type a status...", text: $statusText, axis: .vertical)
                    .font(.system(size: 24, weight: .medium))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .padding(24)
                    .frame(maxWidth: .infinity)
                Spacer()

                // Color picker
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(bgColors, id: \.self) { color in
                            Circle()
                                .fill(Color(hex: color))
                                .frame(width: 36, height: 36)
                                .overlay(Circle().stroke(selectedBGColor == color ? .white : .clear, lineWidth: 3))
                                .onTapGesture { selectedBGColor = color }
                        }
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.bottom, 32)
            }
        }
    }

    private var photoStatusEditor: some View {
        VStack(spacing: 20) {
            PhotosPicker(selection: $selectedPhoto, matching: .any(of: [.images, .videos])) {
                Group {
                    if let img = statusImage {
                        Image(uiImage: img)
                            .resizable().scaledToFit()
                            .cornerRadius(16)
                    } else {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color(.secondarySystemBackground))
                            .overlay(
                                VStack(spacing: 12) {
                                    Image(systemName: "photo.badge.plus")
                                        .font(.system(size: 48))
                                        .foregroundColor(.primaryGreen)
                                    Text("Choose Photo or Video")
                                        .foregroundColor(.primary)
                                }
                            )
                            .frame(height: 300)
                    }
                }
            }
            .onChange(of: selectedPhoto) { _, item in
                Task {
                    if let data = try? await item?.loadTransferable(type: Data.self),
                       let img = UIImage(data: data) {
                        statusImage = img
                    }
                }
            }

            TextField("Add a caption...", text: $caption)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)

            Spacer()
        }
        .padding(.top, 20)
    }

    private var canPost: Bool {
        switch selectedTab {
        case 0: return !statusText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        case 1: return statusImage != nil
        default: return false
        }
    }

    private func post() {
        isPosting = true
        Task {
            do {
                if selectedTab == 0 {
                    try await viewModel.postTextStatus(text: statusText, backgroundColor: selectedBGColor, textColor: "#FFFFFF")
                } else if let img = statusImage {
                    try await viewModel.postImageStatus(image: img, caption: caption.isEmpty ? nil : caption)
                }
                dismiss()
            } catch {
                print("Error posting status: \(error)")
            }
            isPosting = false
        }
    }
}
