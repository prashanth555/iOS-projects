import SwiftUI
import PhotosUI

struct StatusListView: View {
    @ObservedObject var viewModel: StatusViewModel
    @State private var showCreateStatus = false
    @State private var selectedStatus: UserStatus?
    @State private var showViewer = false
    @State private var selectedPhoto: PhotosPickerItem?

    var body: some View {
        NavigationStack {
            List {
                // My status
                Section {
                    myStatusRow
                }

                // Recent updates (unviewed)
                if !viewModel.unviewedStatuses.isEmpty {
                    Section("Recent Updates") {
                        ForEach(viewModel.unviewedStatuses) { status in
                            StatusRow(status: status, isViewed: false)
                                .onTapGesture {
                                    selectedStatus = status
                                    showViewer = true
                                }
                        }
                    }
                }

                // Viewed updates
                if !viewModel.viewedStatuses.isEmpty {
                    Section("Viewed Updates") {
                        ForEach(viewModel.viewedStatuses) { status in
                            StatusRow(status: status, isViewed: true)
                                .onTapGesture {
                                    selectedStatus = status
                                    showViewer = true
                                }
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Status")
            .navigationBarTitleDisplayMode(.large)
            .sheet(isPresented: $showCreateStatus) {
                CreateStatusView(viewModel: viewModel)
            }
            .fullScreenCover(item: $selectedStatus) { status in
                StatusViewerView(statuses: [status], viewModel: viewModel)
            }
        }
    }

    private var myStatusRow: some View {
        HStack(spacing: 14) {
            Button { showCreateStatus = true } label: {
                ZStack(alignment: .bottomTrailing) {
                    if let myStatus = viewModel.myStatus,
                       let firstItem = myStatus.items.first {
                        Group {
                            if firstItem.type == .text {
                                Circle()
                                    .fill(Color(hex: firstItem.backgroundColor ?? "#25D366"))
                                    .overlay(Text(firstItem.content.prefix(2))
                                        .font(.caption.bold()).foregroundColor(.white))
                            } else {
                                AsyncImage(url: URL(string: firstItem.content)) { img in
                                    img.resizable().scaledToFill()
                                } placeholder: { Circle().fill(Color(.systemGray4)) }
                            }
                        }
                        .frame(width: 56, height: 56).clipShape(Circle())
                        .overlay(Circle().stroke(Color.primaryGreen, lineWidth: 3))
                    } else {
                        AsyncImage(url: URL(string: AuthService.shared.currentUser?.profileImageURL ?? "")) { img in
                            img.resizable().scaledToFill()
                        } placeholder: {
                            Circle().fill(Color(.systemGray4))
                                .overlay(Text(AuthService.shared.currentUser?.displayName.prefix(1) ?? "?")
                                    .font(.headline).foregroundColor(.white))
                        }
                        .frame(width: 56, height: 56).clipShape(Circle())
                    }

                    Circle()
                        .fill(Color.primaryGreen)
                        .frame(width: 20, height: 20)
                        .overlay(Image(systemName: "plus").font(.caption2.bold()).foregroundColor(.white))
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("My Status").font(.headline)
                Text(viewModel.myStatus != nil ? "Tap to add status" : "Add to My Status")
                    .font(.subheadline).foregroundColor(.secondary)
            }

            Spacer()
        }
        .padding(.vertical, 4)
    }
}

struct StatusRow: View {
    let status: UserStatus
    let isViewed: Bool

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .stroke(isViewed ? Color.gray : Color.primaryGreen, lineWidth: 3)
                    .frame(width: 58, height: 58)

                Group {
                    if let first = status.items.first {
                        if first.type == .text {
                            Circle()
                                .fill(Color(hex: first.backgroundColor ?? "#25D366"))
                                .overlay(Text(first.content.prefix(2))
                                    .font(.caption.bold()).foregroundColor(.white))
                        } else {
                            AsyncImage(url: URL(string: first.content)) { img in
                                img.resizable().scaledToFill()
                            } placeholder: { Circle().fill(Color(.systemGray4)) }
                        }
                    }
                }
                .frame(width: 50, height: 50).clipShape(Circle())
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(status.userName).font(.headline)
                Text(status.items.last?.timestamp.chatTimestamp ?? "")
                    .font(.subheadline).foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}
