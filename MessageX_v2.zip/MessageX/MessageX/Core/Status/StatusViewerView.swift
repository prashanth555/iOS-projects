import SwiftUI
import AVKit

struct StatusViewerView: View {
    let statuses: [UserStatus]
    @ObservedObject var viewModel: StatusViewModel
    @Environment(\.dismiss) var dismiss
    @State private var currentStatusIndex = 0
    @State private var currentItemIndex = 0
    @State private var progress: CGFloat = 0
    @State private var timer: Timer?
    @State private var isPaused = false

    private var currentStatus: UserStatus { statuses[currentStatusIndex] }
    private var currentItem: UserStatus.StatusItem? {
        guard currentItemIndex < currentStatus.items.count else { return nil }
        return currentStatus.items[currentItemIndex]
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            // Content
            if let item = currentItem {
                contentView(item)
            }

            // Top overlay
            VStack {
                // Progress bars
                HStack(spacing: 4) {
                    ForEach(0..<currentStatus.items.count, id: \.self) { i in
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                Capsule().fill(Color.white.opacity(0.4)).frame(height: 3)
                                Capsule().fill(Color.white)
                                    .frame(width: progressWidth(for: i, in: geo.size.width), height: 3)
                            }
                        }
                        .frame(height: 3)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.top, 8)

                // Header
                HStack {
                    AsyncImage(url: URL(string: currentStatus.userProfileURL ?? "")) { img in
                        img.resizable().scaledToFill()
                    } placeholder: { Circle().fill(Color.white.opacity(0.3)) }
                    .frame(width: 36, height: 36).clipShape(Circle())

                    VStack(alignment: .leading, spacing: 2) {
                        Text(currentStatus.userName).font(.headline).foregroundColor(.white)
                        Text(currentItem?.timestamp.chatTimestamp ?? "")
                            .font(.caption).foregroundColor(.white.opacity(0.8))
                    }

                    Spacer()

                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .foregroundColor(.white)
                            .font(.system(size: 18, weight: .bold))
                    }
                }
                .padding(.horizontal, 16).padding(.top, 8)

                Spacer()

                // Caption
                if let caption = currentItem?.caption {
                    Text(caption)
                        .font(.body).foregroundColor(.white)
                        .padding(.horizontal, 20)
                        .padding(.bottom, 80)
                        .shadow(radius: 4)
                }
            }

            // Tap zones
            HStack {
                // Tap left to go back
                Rectangle().fill(Color.clear)
                    .onTapGesture { goBack() }
                    .frame(maxWidth: 100)

                Spacer()

                // Tap right to go forward
                Rectangle().fill(Color.clear)
                    .onTapGesture { goForward() }
                    .frame(maxWidth: 100)
            }
            .contentShape(Rectangle())
            .gesture(LongPressGesture(minimumDuration: 0.2).onChanged { _ in
                isPaused = true; timer?.invalidate()
            }.onEnded { _ in
                isPaused = false; startTimer()
            })
        }
        .onAppear { startTimer() }
        .onDisappear { timer?.invalidate() }
    }

    @ViewBuilder
    private func contentView(_ item: UserStatus.StatusItem) -> some View {
        switch item.type {
        case .text:
            ZStack {
                Color(hex: item.backgroundColor ?? "#25D366").ignoresSafeArea()
                Text(item.content)
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(Color(hex: item.textColor ?? "#FFFFFF"))
                    .multilineTextAlignment(.center)
                    .padding(32)
            }
        case .image:
            AsyncImage(url: URL(string: item.content)) { img in
                img.resizable().scaledToFit()
            } placeholder: { ProgressView() }
        case .video:
            if let videoURL = URL(string: item.content) {
                VideoPlayer(player: AVPlayer(url: videoURL))
                    .ignoresSafeArea()
            } else {
                Color.black
            }
        default:
            Color.black
        }
    }

    private func progressWidth(for index: Int, in totalWidth: CGFloat) -> CGFloat {
        if index < currentItemIndex { return totalWidth }
        if index == currentItemIndex { return totalWidth * progress }
        return 0
    }

    private func startTimer() {
        guard let item = currentItem else { return }
        progress = 0
        timer?.invalidate()
        let duration = item.duration
        let interval = 0.05
        var elapsed = 0.0
        timer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [self] t in
            elapsed += interval
            progress = CGFloat(elapsed / duration)
            if elapsed >= duration { t.invalidate(); goForward() }
        }
    }

    private func goForward() {
        if currentItemIndex < currentStatus.items.count - 1 {
            currentItemIndex += 1
            startTimer()
        } else if currentStatusIndex < statuses.count - 1 {
            currentStatusIndex += 1
            currentItemIndex = 0
            startTimer()
        } else {
            dismiss()
        }
    }

    private func goBack() {
        if currentItemIndex > 0 {
            currentItemIndex -= 1
            startTimer()
        } else if currentStatusIndex > 0 {
            currentStatusIndex -= 1
            currentItemIndex = max(0, statuses[currentStatusIndex].items.count - 1)
            startTimer()
        }
    }
}
