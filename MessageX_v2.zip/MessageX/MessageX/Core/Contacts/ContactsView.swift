import SwiftUI

struct ContactsView: View {
    @ObservedObject var viewModel: ContactsViewModel
    @State private var selectedUser: MXUser?
    @State private var showChat = false
    @State private var chatToOpen: Chat?
    @State private var showCreateGroup = false

    var body: some View {
        NavigationStack {
            Group {
                if viewModel.isLoading {
                    ProgressView("Loading contacts...")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    contactList
                }
            }
            .navigationTitle("Contacts")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $viewModel.searchText, prompt: "Search contacts")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showCreateGroup = true } label: {
                        Image(systemName: "person.3")
                            .foregroundColor(.primaryGreen)
                    }
                }
            }
            .sheet(isPresented: $showCreateGroup) { CreateGroupView() }
            .navigationDestination(item: $chatToOpen) { chat in
                ChatView(chat: chat)
            }
        }
    }

    private var contactList: some View {
        List {
            Section {
                Button {
                    // Invite friends
                } label: {
                    HStack(spacing: 14) {
                        Image(systemName: "person.badge.plus.fill")
                            .font(.system(size: 22))
                            .foregroundColor(.primaryGreen)
                            .frame(width: 48, height: 48)
                            .background(Color.primaryGreen.opacity(0.1))
                            .clipShape(Circle())
                        Text("Invite Friends")
                            .font(.headline)
                    }
                }

                Button { showCreateGroup = true } label: {
                    HStack(spacing: 14) {
                        Image(systemName: "person.3.fill")
                            .font(.system(size: 22))
                            .foregroundColor(.primaryGreen)
                            .frame(width: 48, height: 48)
                            .background(Color.primaryGreen.opacity(0.1))
                            .clipShape(Circle())
                        Text("New Group")
                            .font(.headline)
                    }
                }
            }

            ForEach(viewModel.groupedContacts, id: \.0) { letter, users in
                Section(header: Text(letter).font(.caption.bold()).foregroundColor(.secondary)) {
                    ForEach(users) { user in
                        ContactRow(user: user)
                            .onTapGesture { openChat(with: user) }
                    }
                }
            }
        }
        .listStyle(.plain)
        .refreshable { viewModel.loadContacts() }
    }

    private func openChat(with user: MXUser) {
        Task {
            do {
                let chatId = try await ChatService.shared.createOrGetChat(with: user)
                // Build a minimal Chat object for navigation
                var chat = Chat(chatId: chatId, type: .individual,
                                participants: [AuthService.shared.currentUserId ?? "", user.uid],
                                currentUser: AuthService.shared.currentUser ?? MXUser(uid: "", phoneNumber: "", displayName: ""),
                                otherUser: user)
                chatToOpen = chat
            } catch {}
        }
    }
}

struct ContactRow: View {
    let user: MXUser

    var body: some View {
        HStack(spacing: 14) {
            ZStack(alignment: .bottomTrailing) {
                AsyncImage(url: URL(string: user.profileImageURL ?? "")) { img in
                    img.resizable().scaledToFill()
                } placeholder: {
                    Circle().fill(Color(.systemGray4))
                        .overlay(Text(user.displayName.prefix(1))
                            .font(.headline).foregroundColor(.white))
                }
                .frame(width: 50, height: 50).clipShape(Circle())

                if user.isOnline {
                    Circle().fill(Color.primaryGreen).frame(width: 13, height: 13)
                        .overlay(Circle().stroke(Color(.systemBackground), lineWidth: 2))
                }
            }

            VStack(alignment: .leading, spacing: 3) {
                Text(user.displayName).font(.headline)
                Text(user.bio ?? user.lastSeenText)
                    .font(.caption).foregroundColor(.secondary).lineLimit(1)
            }

            Spacer()

            Button {} label: {
                Image(systemName: "phone")
                    .foregroundColor(.primaryGreen)
                    .font(.system(size: 18))
            }
        }
        .padding(.vertical, 4)
    }
}

struct NewChatView: View {
    let onChatCreated: (Chat) -> Void
    @StateObject private var viewModel = ContactsViewModel()
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack {
            ContactsView(viewModel: viewModel)
                .navigationTitle("New Chat")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("Cancel") { dismiss() }
                    }
                }
        }
    }
}
