import Foundation
import Firebase
import Combine

@MainActor
class ContactsViewModel: ObservableObject {
    @Published var contacts: [MXUser] = []
    @Published var searchResults: [MXUser] = []
    @Published var searchText = ""
    @Published var isLoading = false
    @Published var errorMessage: String?

    private var cancellables = Set<AnyCancellable>()

    init() {
        setupSearch()
        loadContacts()
    }

    func loadContacts() {
        isLoading = true
        Task {
            let granted = await ContactsService.shared.requestContactsAccess()
            if granted {
                do {
                    contacts = try await ContactsService.shared.syncContacts()
                } catch { errorMessage = error.localizedDescription }
            } else {
                await loadAllAppUsers()
            }
            isLoading = false
        }
    }

    private func loadAllAppUsers() async {
        do {
            let snapshot = try await Firestore.firestore().collection(Constants.usersCollection)
                .limit(to: 100).getDocuments()
            contacts = snapshot.documents
                .compactMap { try? $0.data(as: MXUser.self) }
                .filter { $0.uid != AuthService.shared.currentUserId }
        } catch { errorMessage = error.localizedDescription }
    }

    private func setupSearch() {
        $searchText
            .debounce(for: .milliseconds(400), scheduler: DispatchQueue.main)
            .sink { [weak self] query in
                guard let self = self else { return }
                if query.isEmpty {
                    self.searchResults = []
                } else {
                    self.searchResults = self.contacts.filter {
                        $0.displayName.localizedCaseInsensitiveContains(query) ||
                        $0.phoneNumber.contains(query)
                    }
                    if self.searchResults.isEmpty {
                        Task { await self.searchRemote(query: query) }
                    }
                }
            }
            .store(in: &cancellables)
    }

    private func searchRemote(query: String) async {
        do {
            let results = try await ContactsService.shared.searchUsers(query: query)
            searchResults = results
        } catch {}
    }

    var displayedContacts: [MXUser] {
        searchText.isEmpty ? contacts : searchResults
    }

    var groupedContacts: [(String, [MXUser])] {
        let sorted = displayedContacts.sorted { $0.displayName < $1.displayName }
        let grouped = Dictionary(grouping: sorted) { String($0.displayName.prefix(1)).uppercased() }
        return grouped.sorted { $0.key < $1.key }
    }
}
