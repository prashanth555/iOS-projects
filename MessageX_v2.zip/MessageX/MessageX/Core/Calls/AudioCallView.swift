import SwiftUI

struct AudioCallView: View {
    @EnvironmentObject var callManager: CallManager
    @Environment(\.dismiss) var dismiss
    @State private var callAnimation = false

    var call: CallSession? { callManager.activeCall }

    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(colors: [Color(hex: "1a1a2e"), Color(hex: "16213e"), Color(hex: "0f3460")],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer()

                // Caller info
                VStack(spacing: 20) {
                    // Profile image with ripple animation
                    ZStack {
                        if callManager.callState == .calling || callManager.callState == .ringing {
                            ForEach(0..<3, id: \.self) { i in
                                Circle()
                                    .stroke(Color.white.opacity(0.2 - Double(i) * 0.06), lineWidth: 1)
                                    .frame(width: 130 + CGFloat(i * 30), height: 130 + CGFloat(i * 30))
                                    .scaleEffect(callAnimation ? 1.1 : 0.95)
                                    .animation(.easeInOut(duration: 1.5)
                                        .repeatForever().delay(Double(i) * 0.3), value: callAnimation)
                            }
                        }

                        AsyncImage(url: URL(string: call?.callerProfileURL ?? "")) { img in
                            img.resizable().scaledToFill()
                        } placeholder: {
                            Circle().fill(Color.white.opacity(0.2))
                                .overlay(Text(call?.callerName.prefix(1) ?? "?")
                                    .font(.system(size: 48, weight: .bold))
                                    .foregroundColor(.white))
                        }
                        .frame(width: 120, height: 120)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.white.opacity(0.3), lineWidth: 3))
                    }

                    VStack(spacing: 8) {
                        Text(call?.callerName ?? "Unknown")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(.white)

                        Text(statusText)
                            .font(.subheadline)
                            .foregroundColor(.white.opacity(0.7))

                        if callManager.callState == .connected {
                            Text(callManager.callDuration.durationText)
                                .font(.system(size: 16, design: .monospaced))
                                .foregroundColor(.white.opacity(0.9))
                        }
                    }
                }

                Spacer()

                // Call controls
                VStack(spacing: 32) {
                    // Top controls row
                    HStack(spacing: 50) {
                        CallControlButton(
                            icon: callManager.isSpeakerOn ? "speaker.wave.3.fill" : "speaker.fill",
                            label: "Speaker",
                            isActive: callManager.isSpeakerOn,
                            action: { callManager.toggleSpeaker() }
                        )

                        CallControlButton(
                            icon: callManager.isAudioMuted ? "mic.slash.fill" : "mic.fill",
                            label: callManager.isAudioMuted ? "Unmute" : "Mute",
                            isActive: callManager.isAudioMuted,
                            action: { callManager.toggleMute() }
                        )

                        CallControlButton(
                            icon: "video.fill",
                            label: "Video",
                            action: { /* switch to video call */ }
                        )
                    }

                    // End call button
                    Button { endCall() } label: {
                        Image(systemName: "phone.down.fill")
                            .font(.system(size: 32))
                            .foregroundColor(.white)
                            .frame(width: 72, height: 72)
                            .background(Color.red)
                            .clipShape(Circle())
                            .shadow(radius: 10)
                    }
                }
                .padding(.bottom, 60)
            }
        }
        .onAppear { callAnimation = true }
        .onChange(of: callManager.callState) { _, state in
            if state == .idle { dismiss() }
        }
    }

    private var statusText: String {
        switch callManager.callState {
        case .calling: return "Calling..."
        case .ringing: return "Ringing..."
        case .connected: return "Connected"
        case .ended: return "Call ended"
        default: return ""
        }
    }

    private func endCall() {
        callManager.endCall()
        dismiss()
    }
}

struct CallControlButton: View {
    let icon: String
    let label: String
    var isActive: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 22))
                    .foregroundColor(isActive ? .primaryGreen : .white)
                    .frame(width: 56, height: 56)
                    .background(isActive ? Color.white : Color.white.opacity(0.15))
                    .clipShape(Circle())
                Text(label)
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.8))
            }
        }
    }
}

extension Int {
    var durationText: String {
        let m = self / 60; let s = self % 60
        return String(format: "%02d:%02d", m, s)
    }
}
