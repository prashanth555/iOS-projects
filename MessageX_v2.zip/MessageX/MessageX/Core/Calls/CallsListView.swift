import SwiftUI
import Firebase

struct CallsListView: View {
    @EnvironmentObject var callManager: CallManager
    @StateObject private var viewModel = CallsListViewModel()

    var body: some View {
        NavigationStack {
            Group {
                if viewModel.callHistory.isEmpty {
                    VStack(spacing: 16) {
                        Spacer()
                        Image(systemName: "phone.arrow.up.right").font(.system(size: 64)).foregroundColor(.secondary.opacity(0.3))
                        Text("No calls yet").font(.title3).foregroundColor(.secondary)
                        Spacer()
                    }
                } else {
                    List(viewModel.callHistory) { item in
                        CallHistoryRow(item: item)
                            .swipeActions {
                                Button { startCall(item: item) } label: {
                                    Label("Call back", systemImage: item.type == .video ? "video" : "phone")
                                }
                                .tint(.primaryGreen)
                            }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Calls")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {} label: { Image(systemName: "phone.arrow.up.right").foregroundColor(.primaryGreen) }
                }
            }
        }
    }

    private func startCall(item: CallHistoryItem) {
        var user = MXUser(uid: item.participantId, phoneNumber: "", displayName: item.participantName)
        user.profileImageURL = item.participantImageURL
        Task { try? await callManager.startCall(to: user, type: item.type) }
    }
}

struct CallHistoryRow: View {
    let item: CallHistoryItem

    var body: some View {
        HStack(spacing: 14) {
            AsyncImage(url: URL(string: item.participantImageURL ?? "")) { img in
                img.resizable().scaledToFill()
            } placeholder: {
                Circle().fill(Color(.systemGray4))
                    .overlay(Text(item.participantName.prefix(1)).foregroundColor(.white))
            }
            .frame(width: 48, height: 48).clipShape(Circle())

            VStack(alignment: .leading, spacing: 4) {
                Text(item.participantName).font(.headline)
                HStack(spacing: 6) {
                    Image(systemName: callIcon)
                        .font(.caption)
                        .foregroundColor(item.status == .missed ? .red : .primaryGreen)
                    Text(statusText).font(.caption).foregroundColor(.secondary)
                    Text("·").foregroundColor(.secondary)
                    Text(item.timestamp.chatTimestamp).font(.caption).foregroundColor(.secondary)
                }
            }

            Spacer()

            Button {} label: {
                Image(systemName: item.type == .video ? "video" : "phone")
                    .foregroundColor(.primaryGreen)
                    .font(.system(size: 18))
            }
        }
        .padding(.vertical, 6)
    }

    private var callIcon: String {
        switch item.status {
        case .missed: return "phone.arrow.down.left"
        case .ended: return item.isIncoming ? "phone.arrow.down.left" : "phone.arrow.up.right"
        default: return "phone"
        }
    }

    private var statusText: String {
        switch item.status {
        case .missed: return "Missed"
        case .declined: return "Declined"
        case .ended: return item.duration.map { "\($0 / 60)m \($0 % 60)s" } ?? "Ended"
        default: return item.isIncoming ? "Incoming" : "Outgoing"
        }
    }
}

@MainActor
class CallsListViewModel: ObservableObject {
    @Published var callHistory: [CallHistoryItem] = []
    private let db = Firestore.firestore()

    init() { loadCallHistory() }

    private func loadCallHistory() {
        guard let uid = AuthService.shared.currentUserId else { return }
        // Simple single-field query — no composite index required.
        // We sort client-side to avoid a Firestore index deployment step.
        db.collection("calls")
            .whereField("callerId", isEqualTo: uid)
            .limit(to: 50)
            .getDocuments { [weak self] snapshot, error in
                if let error = error {
                    print("[CallsListViewModel] Firestore error: \(error.localizedDescription)")
                    return
                }
                guard let docs = snapshot?.documents else { return }
                let items = docs.compactMap { doc -> CallHistoryItem? in
                    guard let session = try? doc.data(as: CallSession.self) else { return nil }
                    return CallHistoryItem(
                        callId: session.callId,
                        participantId: session.receiverId,
                        participantName: session.receiverName,
                        participantImageURL: session.receiverProfileURL,
                        type: session.type,
                        status: session.status,
                        timestamp: session.startedAt ?? Timestamp(date: Date()),
                        duration: session.duration,
                        isIncoming: false
                    )
                }
                .sorted { $0.timestamp.dateValue() > $1.timestamp.dateValue() }
                Task { @MainActor in self?.callHistory = items }
            }
    }
}
