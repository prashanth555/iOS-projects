import SwiftUI

struct IncomingCallView: View {
    let call: CallSession
    @EnvironmentObject var callManager: CallManager
    @State private var slideOffset: CGFloat = 0
    @State private var pulseAnimation = false

    var body: some View {
        ZStack {
            Color.black.opacity(0.5).ignoresSafeArea()
                .blur(radius: 20)

            VStack {
                Spacer()
                callCard
                    .offset(y: slideOffset)
                    .padding(.bottom, 32)
            }
        }
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.spring()) { slideOffset = 0 }
            pulseAnimation = true
        }
    }

    private var callCard: some View {
        VStack(spacing: 24) {
            // Caller info
            VStack(spacing: 12) {
                ZStack {
                    ForEach(0..<2, id: \.self) { i in
                        Circle()
                            .stroke(Color.white.opacity(0.15), lineWidth: 1)
                            .frame(width: 90 + CGFloat(i * 20), height: 90 + CGFloat(i * 20))
                            .scaleEffect(pulseAnimation ? 1.1 : 0.95)
                            .animation(.easeInOut(duration: 1.2).repeatForever().delay(Double(i) * 0.3),
                                       value: pulseAnimation)
                    }

                    AsyncImage(url: URL(string: call.callerProfileURL ?? "")) { img in
                        img.resizable().scaledToFill()
                    } placeholder: {
                        Circle().fill(Color.white.opacity(0.3))
                            .overlay(Text(call.callerName.prefix(1))
                                .font(.system(size: 32, weight: .bold))
                                .foregroundColor(.white))
                    }
                    .frame(width: 80, height: 80)
                    .clipShape(Circle())
                }

                VStack(spacing: 4) {
                    Text("Incoming \(call.type == .video ? "Video" : "Audio") Call")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.7))
                    Text(call.callerName)
                        .font(.title2.bold())
                        .foregroundColor(.white)
                }
            }

            // Call action buttons
            HStack(spacing: 60) {
                // Decline
                Button {
                    callManager.declineCall()
                } label: {
                    VStack(spacing: 8) {
                        Image(systemName: "phone.down.fill")
                            .font(.system(size: 28))
                            .foregroundColor(.white)
                            .frame(width: 68, height: 68)
                            .background(Color.red)
                            .clipShape(Circle())
                        Text("Decline")
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.8))
                    }
                }

                // Accept
                Button {
                    callManager.acceptCall()
                } label: {
                    VStack(spacing: 8) {
                        Image(systemName: call.type == .video ? "video.fill" : "phone.fill")
                            .font(.system(size: 28))
                            .foregroundColor(.white)
                            .frame(width: 68, height: 68)
                            .background(Color.primaryGreen)
                            .clipShape(Circle())
                        Text("Accept")
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.8))
                    }
                }
            }
        }
        .padding(32)
        .background(
            RoundedRectangle(cornerRadius: 32)
                .fill(.ultraThinMaterial)
                .shadow(radius: 30)
        )
        .padding(.horizontal, 20)
    }
}
