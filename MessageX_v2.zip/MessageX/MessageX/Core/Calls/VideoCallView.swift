import SwiftUI
import WebRTC

struct VideoCallView: View {
    @EnvironmentObject var callManager: CallManager
    @Environment(\.dismiss) var dismiss
    @State private var showControls = true
    @State private var controlsTimer: Timer?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            // Remote video (full screen)
            RemoteVideoView(callManager: callManager)
                .ignoresSafeArea()
                .onTapGesture { toggleControls() }

            // Local video (picture-in-picture)
            VStack {
                HStack {
                    Spacer()
                    LocalVideoView(callManager: callManager)
                        .frame(width: 100, height: 140)
                        .cornerRadius(12)
                        .overlay(RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.white.opacity(0.5), lineWidth: 1))
                        .shadow(radius: 8)
                        .padding(16)
                        .draggable(Text(""))
                }
                Spacer()
            }

            // Controls overlay
            if showControls {
                VStack {
                    // Top bar
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(callManager.activeCall?.callerName ?? "Video Call")
                                .font(.headline).foregroundColor(.white)
                            if callManager.callState == .connected {
                                Text(callManager.callDuration.durationText)
                                    .font(.caption)
                                    .foregroundColor(.white.opacity(0.8))
                            }
                        }
                        Spacer()
                    }
                    .padding()
                    .background(LinearGradient(colors: [.black.opacity(0.6), .clear],
                                               startPoint: .top, endPoint: .bottom))

                    Spacer()

                    // Bottom controls
                    HStack(spacing: 32) {
                        VideoCallControlButton(
                            icon: callManager.isAudioMuted ? "mic.slash.fill" : "mic.fill",
                            label: callManager.isAudioMuted ? "Unmute" : "Mute",
                            isActive: callManager.isAudioMuted
                        ) { callManager.toggleMute() }

                        // End call
                        Button { endCall() } label: {
                            Image(systemName: "phone.down.fill")
                                .font(.system(size: 28))
                                .foregroundColor(.white)
                                .frame(width: 68, height: 68)
                                .background(Color.red)
                                .clipShape(Circle())
                        }

                        VideoCallControlButton(
                            icon: callManager.isVideoMuted ? "video.slash.fill" : "video.fill",
                            label: callManager.isVideoMuted ? "Show" : "Hide",
                            isActive: callManager.isVideoMuted
                        ) { callManager.toggleVideo() }
                    }

                    // Extra controls row
                    HStack(spacing: 32) {
                        VideoCallControlButton(
                            icon: "camera.rotate.fill",
                            label: "Flip"
                        ) { callManager.switchCamera() }

                        VideoCallControlButton(
                            icon: callManager.isSpeakerOn ? "speaker.wave.3.fill" : "speaker.fill",
                            label: "Speaker",
                            isActive: callManager.isSpeakerOn
                        ) { callManager.toggleSpeaker() }
                    }
                    .padding(.bottom, 50)
                }
                .background(
                    LinearGradient(colors: [.clear, .black.opacity(0.7)],
                                   startPoint: .center, endPoint: .bottom)
                        .ignoresSafeArea(edges: .bottom)
                )
                .transition(.opacity)
            }
        }
        .onChange(of: callManager.callState) { _, state in
            if state == .idle { dismiss() }
        }
        .onAppear { resetControlsTimer() }
    }

    private func toggleControls() {
        withAnimation(.easeInOut(duration: 0.3)) { showControls.toggle() }
        if showControls { resetControlsTimer() }
    }

    private func resetControlsTimer() {
        controlsTimer?.invalidate()
        controlsTimer = Timer.scheduledTimer(withTimeInterval: 4, repeats: false) { _ in
            withAnimation { showControls = false }
        }
    }

    private func endCall() {
        callManager.endCall()
        dismiss()
    }
}

struct VideoCallControlButton: View {
    let icon: String
    let label: String
    var isActive: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 20))
                    .foregroundColor(isActive ? Color.black : .white)
                    .frame(width: 50, height: 50)
                    .background(isActive ? Color.white : Color.white.opacity(0.2))
                    .clipShape(Circle())
                Text(label).font(.caption2).foregroundColor(.white.opacity(0.8))
            }
        }
    }
}

// MARK: - WebRTC Video Renderers
struct RemoteVideoView: UIViewRepresentable {
    let callManager: CallManager

    func makeUIView(context: Context) -> RTCMTLVideoView {
        let view = RTCMTLVideoView(frame: .zero)
        view.videoContentMode = .scaleAspectFill
        callManager.getWebRTCClient()?.renderRemoteVideo(to: view)
        return view
    }

    func updateUIView(_ uiView: RTCMTLVideoView, context: Context) {}
}

struct LocalVideoView: UIViewRepresentable {
    let callManager: CallManager

    func makeUIView(context: Context) -> RTCMTLVideoView {
        let view = RTCMTLVideoView(frame: .zero)
        view.videoContentMode = .scaleAspectFill
        return view
    }

    func updateUIView(_ uiView: RTCMTLVideoView, context: Context) {}
}
