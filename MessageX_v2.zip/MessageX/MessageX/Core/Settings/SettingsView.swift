import SwiftUI
import PhotosUI

struct SettingsView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var showProfileEdit = false
    @State private var showPrivacySettings = false
    @State private var showNotificationSettings = false
    @State private var showChatsSettings = false
    @State private var showSignOutAlert = false
    @State private var showQRCode = false

    var body: some View {
        NavigationStack {
            List {
                // Profile Section
                if let user = authViewModel.currentUser {
                    Section {
                        Button { showProfileEdit = true } label: {
                            HStack(spacing: 16) {
                                AsyncImage(url: URL(string: user.profileImageURL ?? "")) { img in
                                    img.resizable().scaledToFill()
                                } placeholder: {
                                    Circle().fill(Color(.systemGray4))
                                        .overlay(Text(user.displayName.prefix(1))
                                            .font(.title2.bold()).foregroundColor(.white))
                                }
                                .frame(width: 64, height: 64).clipShape(Circle())

                                VStack(alignment: .leading, spacing: 4) {
                                    Text(user.displayName).font(.headline).foregroundColor(.primary)
                                    Text(user.bio ?? "Hey there! I am using MessageX.")
                                        .font(.subheadline).foregroundColor(.secondary).lineLimit(1)
                                    Text(user.phoneNumber).font(.caption).foregroundColor(.secondary)
                                }
                                Spacer()
                                VStack(spacing: 4) {
                                    Button { showQRCode = true } label: {
                                        Image(systemName: "qrcode").font(.system(size: 20))
                                            .foregroundColor(.primaryGreen)
                                    }
                                }
                            }
                        }
                    }
                }

                Section {
                    SettingsRow(icon: "key.fill", color: .primaryGreen, title: "Account") {}
                    SettingsRow(icon: "lock.shield.fill", color: .blue, title: "Privacy") {
                        showPrivacySettings = true
                    }
                    SettingsRow(icon: "bell.fill", color: .red, title: "Notifications") {
                        showNotificationSettings = true
                    }
                    SettingsRow(icon: "message.fill", color: .primaryGreen, title: "Chats") {
                        showChatsSettings = true
                    }
                    SettingsRow(icon: "arrow.triangle.2.circlepath", color: .blue, title: "Storage and Data") {}
                    SettingsRow(icon: "globe", color: .cyan, title: "App Language") {}
                }

                Section {
                    SettingsRow(icon: "questionmark.circle.fill", color: .gray, title: "Help") {}
                    SettingsRow(icon: "hand.raised.fill", color: .orange, title: "Tell a Friend") {}
                }

                Section {
                    Button(role: .destructive) {
                        showSignOutAlert = true
                    } label: {
                        HStack {
                            Spacer()
                            Text("Log Out")
                                .foregroundColor(.red)
                                .font(.headline)
                            Spacer()
                        }
                    }
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.large)
            .sheet(isPresented: $showProfileEdit) {
                ProfileEditView()
                    .environmentObject(authViewModel)
            }
            .sheet(isPresented: $showPrivacySettings) {
                PrivacySettingsView()
            }
            .sheet(isPresented: $showNotificationSettings) {
                NotificationSettingsView()
            }
            .alert("Log Out", isPresented: $showSignOutAlert) {
                Button("Log Out", role: .destructive) { authViewModel.signOut() }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Are you sure you want to log out?")
            }
        }
    }
}

struct SettingsRow: View {
    let icon: String
    let color: Color
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon)
                    .font(.system(size: 16))
                    .foregroundColor(.white)
                    .frame(width: 32, height: 32)
                    .background(color)
                    .cornerRadius(8)
                Text(title).foregroundColor(.primary)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption.bold())
                    .foregroundColor(.secondary)
            }
        }
    }
}

struct ProfileEditView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @Environment(\.dismiss) var dismiss
    @State private var displayName = ""
    @State private var bio = ""
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var newImage: UIImage?
    @State private var isSaving = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Spacer()
                        PhotosPicker(selection: $selectedPhoto, matching: .images) {
                            ZStack(alignment: .bottomTrailing) {
                                AsyncImage(url: URL(string: authViewModel.currentUser?.profileImageURL ?? "")) { img in
                                    if let newImg = newImage {
                                        Image(uiImage: newImg).resizable().scaledToFill()
                                    } else {
                                        img.resizable().scaledToFill()
                                    }
                                } placeholder: {
                                    Circle().fill(Color(.systemGray4))
                                }
                                .frame(width: 90, height: 90).clipShape(Circle())

                                Circle().fill(Color.primaryGreen).frame(width: 28, height: 28)
                                    .overlay(Image(systemName: "camera.fill").font(.caption).foregroundColor(.white))
                            }
                        }
                        .onChange(of: selectedPhoto) { _, item in
                            Task {
                                if let data = try? await item?.loadTransferable(type: Data.self),
                                   let img = UIImage(data: data) { newImage = img }
                            }
                        }
                        Spacer()
                    }
                }
                .listRowBackground(Color.clear)

                Section("Your name") {
                    TextField("Display name", text: $displayName)
                }

                Section("About") {
                    TextField("Status / Bio", text: $bio)
                }
            }
            .navigationTitle("Edit Profile")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") { saveProfile() }
                        .bold().foregroundColor(.primaryGreen)
                        .disabled(isSaving)
                }
            }
            .onAppear {
                displayName = authViewModel.currentUser?.displayName ?? ""
                bio = authViewModel.currentUser?.bio ?? ""
            }
        }
    }

    private func saveProfile() {
        isSaving = true
        Task {
            var imageURL: String? = nil
            if let img = newImage, let uid = AuthService.shared.currentUserId {
                imageURL = try? await StorageService.shared.uploadProfileImage(img, userId: uid)
            }
            await authViewModel.updateProfile(displayName: displayName, bio: bio, imageURL: imageURL)
            isSaving = false
            dismiss()
        }
    }
}

struct PrivacySettingsView: View {
    @Environment(\.dismiss) var dismiss
    @State private var lastSeen = MXUser.PrivacySetting.everyone
    @State private var profilePhoto = MXUser.PrivacySetting.everyone
    @State private var status = MXUser.PrivacySetting.everyone
    @State private var readReceipts = true

    var body: some View {
        NavigationStack {
            Form {
                Section("Who can see my personal info") {
                    Picker("Last Seen", selection: $lastSeen) {
                        ForEach(MXUser.PrivacySetting.allCases, id: \.self) { setting in
                            Text(setting.rawValue.capitalized)
                        }
                    }
                    Picker("Profile Photo", selection: $profilePhoto) {
                        ForEach(MXUser.PrivacySetting.allCases, id: \.self) { setting in
                            Text(setting.rawValue.capitalized)
                        }
                    }
                    Picker("Status", selection: $status) {
                        ForEach(MXUser.PrivacySetting.allCases, id: \.self) { setting in
                            Text(setting.rawValue.capitalized)
                        }
                    }
                }
                Section("Messages") {
                    Toggle("Read Receipts", isOn: $readReceipts)
                }
            }
            .navigationTitle("Privacy")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}

struct NotificationSettingsView: View {
    @Environment(\.dismiss) var dismiss
    @State private var messages = true
    @State private var groups = true
    @State private var calls = true
    @State private var statusUpdates = true
    @State private var sound = "Default"

    var body: some View {
        NavigationStack {
            Form {
                Section("Notifications") {
                    Toggle("Messages", isOn: $messages)
                    Toggle("Groups", isOn: $groups)
                    Toggle("Calls", isOn: $calls)
                    Toggle("Status Updates", isOn: $statusUpdates)
                }
                Section("Sound") {
                    Picker("Notification Sound", selection: $sound) {
                        Text("Default").tag("Default")
                        Text("None").tag("None")
                    }
                }
            }
            .navigationTitle("Notifications")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
