import SwiftUI

struct OTPVerificationView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    let phoneNumber: String
    @State private var otp = ""
    @State private var isLoading = false
    @State private var resendCooldown = 60
    @State private var canResend = false
    @FocusState private var isOTPFocused: Bool

    var body: some View {
        VStack(spacing: 32) {
            Spacer()

            VStack(spacing: 12) {
                Image(systemName: "message.badge.filled.fill")
                    .font(.system(size: 60))
                    .foregroundColor(.primaryGreen)
                Text("Verify your number")
                    .font(.title2.bold())
                Text("Enter the 6-digit code sent to\n\(phoneNumber)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }

            // OTP Input
            HStack(spacing: 12) {
                ForEach(0..<6, id: \.self) { index in
                    OTPCell(digit: digit(at: index))
                }
            }
            .onTapGesture { isOTPFocused = true }
            .overlay(
                TextField("", text: $otp)
                    .keyboardType(.numberPad)
                    .focused($isOTPFocused)
                    .opacity(0.01)
                    .onChange(of: otp) { old, new in
                        otp = String(new.filter { $0.isNumber }.prefix(6))
                        if otp.count == 6 { verifyOTP() }
                    }
            )

            // Verify Button
            Button(action: verifyOTP) {
                Group {
                    if isLoading {
                        ProgressView().tint(.white)
                    } else {
                        Text("Verify")
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                }
                .frame(maxWidth: .infinity).frame(height: 54)
                .background(otp.count == 6 ? Color.primaryGreen : Color.gray)
                .cornerRadius(14)
            }
            .disabled(otp.count < 6 || isLoading)
            .padding(.horizontal)

            // Resend
            HStack {
                Text("Didn't receive the code?")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                if canResend {
                    Button("Resend") { resendOTP() }
                        .font(.subheadline.bold())
                        .foregroundColor(.primaryGreen)
                } else {
                    Text("Resend in \(resendCooldown)s")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
            }

            Spacer()
        }
        .padding()
        .onAppear {
            isOTPFocused = true
            startCooldown()
        }
        .alert("Error", isPresented: $authViewModel.showError) {
            Button("OK", role: .cancel) {}
        } message: { Text(authViewModel.errorMessage ?? "") }
    }

    private func digit(at index: Int) -> String {
        guard index < otp.count else { return "" }
        return String(otp[otp.index(otp.startIndex, offsetBy: index)])
    }

    private func verifyOTP() {
        guard otp.count == 6 else { return }
        isLoading = true
        Task {
            _ = await authViewModel.verifyOTP(otp)
            isLoading = false
        }
    }

    private func resendOTP() {
        canResend = false
        Task { _ = await authViewModel.sendOTP(phoneNumber: phoneNumber) }
        startCooldown()
    }

    private func startCooldown() {
        resendCooldown = 60
        canResend = false
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            resendCooldown -= 1
            if resendCooldown <= 0 { canResend = true; timer.invalidate() }
        }
    }
}

struct OTPCell: View {
    let digit: String
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12)
                .strokeBorder(digit.isEmpty ? Color(.systemGray4) : Color.primaryGreen, lineWidth: 2)
                .frame(width: 48, height: 56)
                .background(Color(.secondarySystemBackground).cornerRadius(12))
            Text(digit)
                .font(.title2.bold())
        }
    }
}
