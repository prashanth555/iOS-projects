import SwiftUI
import PhotosUI

struct ProfileSetupView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @Environment(\.dismiss) var dismiss
    @State private var displayName = ""
    @State private var bio = ""
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var profileImage: UIImage?
    @State private var isLoading = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 28) {
                    Text("Set up your profile")
                        .font(.title2.bold())
                        .padding(.top)

                    // Profile Photo
                    PhotosPicker(selection: $selectedPhoto, matching: .images) {
                        ZStack(alignment: .bottomTrailing) {
                            Group {
                                if let img = profileImage {
                                    Image(uiImage: img)
                                        .resizable().scaledToFill()
                                } else {
                                    Image(systemName: "person.circle.fill")
                                        .resizable()
                                        .foregroundColor(.gray)
                                }
                            }
                            .frame(width: 110, height: 110)
                            .clipShape(Circle())

                            Circle()
                                .fill(Color.primaryGreen)
                                .frame(width: 34, height: 34)
                                .overlay(Image(systemName: "camera.fill").foregroundColor(.white).font(.system(size: 14)))
                        }
                    }
                    .onChange(of: selectedPhoto) { _, item in
                        Task {
                            if let data = try? await item?.loadTransferable(type: Data.self),
                               let img = UIImage(data: data) {
                                profileImage = img
                            }
                        }
                    }

                    // Name & Bio Fields
                    VStack(spacing: 16) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Your Name").font(.caption).foregroundColor(.secondary)
                            TextField("Display name", text: $displayName)
                                .textFieldStyle(.roundedBorder)
                                .submitLabel(.done)
                        }

                        VStack(alignment: .leading, spacing: 6) {
                            Text("About (optional)").font(.caption).foregroundColor(.secondary)
                            TextField("Hey there! I am using MessageX.", text: $bio)
                                .textFieldStyle(.roundedBorder)
                        }
                    }
                    .padding(.horizontal)

                    Button(action: saveProfile) {
                        Group {
                            if isLoading { ProgressView().tint(.white) }
                            else { Text("Save").font(.headline).foregroundColor(.white) }
                        }
                        .frame(maxWidth: .infinity).frame(height: 54)
                        .background(displayName.count >= 2 ? Color.primaryGreen : Color.gray)
                        .cornerRadius(14)
                    }
                    .disabled(displayName.count < 2 || isLoading)
                    .padding(.horizontal)
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }

    private func saveProfile() {
        isLoading = true
        Task {
            var imageURL: String? = nil
            if let img = profileImage, let uid = AuthService.shared.currentUserId {
                imageURL = try? await StorageService.shared.uploadProfileImage(img, userId: uid)
            }
            await authViewModel.updateProfile(displayName: displayName, bio: bio, imageURL: imageURL)
            isLoading = false
            dismiss()
        }
    }
}
