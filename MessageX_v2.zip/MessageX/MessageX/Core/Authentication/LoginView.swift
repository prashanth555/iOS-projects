import SwiftUI

struct LoginView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var phoneNumber = ""
    @State private var countryCode = "+1"
    @State private var showOTPView = false
    @State private var isLoading = false

    private let countryCodes = ["+1", "+44", "+91", "+61", "+81", "+86", "+49", "+33", "+55", "+52"]

    var body: some View {
        NavigationStack {
            ZStack {
                Color(.systemBackground).ignoresSafeArea()
                VStack(spacing: 32) {
                    Spacer()
                    // Logo
                    VStack(spacing: 12) {
                        Image(systemName: "bubble.left.and.bubble.right.fill")
                            .font(.system(size: 72))
                            .foregroundColor(.primaryGreen)
                        Text("MessageX")
                            .font(.largeTitle.bold())
                        Text("Simple. Fast. Secure.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }

                    Spacer()

                    // Phone Input
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Enter your phone number")
                            .font(.headline)
                            .padding(.horizontal)

                        HStack {
                            Menu {
                                ForEach(countryCodes, id: \.self) { code in
                                    Button(code) { countryCode = code }
                                }
                            } label: {
                                HStack {
                                    Text(countryCode)
                                        .font(.body.bold())
                                    Image(systemName: "chevron.down")
                                        .font(.caption)
                                }
                                .padding()
                                .background(Color(.secondarySystemBackground))
                                .cornerRadius(12)
                            }
                            TextField("Phone number", text: $phoneNumber)
                                .keyboardType(.phonePad)
                                .padding()
                                .background(Color(.secondarySystemBackground))
                                .cornerRadius(12)
                        }
                        .padding(.horizontal)

                        Text("We'll send a verification code to this number.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(.horizontal)
                    }

                    // Send OTP Button
                    Button(action: sendOTP) {
                        Group {
                            if isLoading {
                                ProgressView().tint(.white)
                            } else {
                                Text("Continue")
                                    .font(.headline)
                                    .foregroundColor(.white)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(phoneNumber.count >= 7 ? Color.primaryGreen : Color.gray)
                        .cornerRadius(14)
                    }
                    .disabled(phoneNumber.count < 7 || isLoading)
                    .padding(.horizontal)

                    Spacer()

                    Text("By continuing, you agree to our Terms of Service and Privacy Policy.")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
            }
            .navigationDestination(isPresented: $showOTPView) {
                OTPVerificationView(phoneNumber: "\(countryCode)\(phoneNumber)")
                    .environmentObject(authViewModel)
            }
            .alert("Error", isPresented: $authViewModel.showError, actions: {
                Button("OK", role: .cancel) {}
            }, message: {
                Text(authViewModel.errorMessage ?? "An error occurred.")
            })
        }
    }

    private func sendOTP() {
        isLoading = true
        Task {
            let success = await authViewModel.sendOTP(phoneNumber: "\(countryCode)\(phoneNumber)")
            isLoading = false
            if success { showOTPView = true }
        }
    }
}
