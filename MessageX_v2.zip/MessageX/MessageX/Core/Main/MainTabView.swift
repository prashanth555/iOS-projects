import SwiftUI

struct MainTabView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @EnvironmentObject var callManager: CallManager
    @StateObject private var chatListVM = ChatListViewModel()
    @StateObject private var statusVM = StatusViewModel()
    @StateObject private var contactsVM = ContactsViewModel()
    @State private var selectedTab = 0
    @State private var showIncomingCall = false

    var body: some View {
        ZStack {
            TabView(selection: $selectedTab) {
                ChatListView(viewModel: chatListVM)
                    .tabItem {
                        Label("Chats", systemImage: selectedTab == 0 ? "bubble.left.and.bubble.right.fill" : "bubble.left.and.bubble.right")
                    }
                    .badge(chatListVM.totalUnreadCount > 0 ? chatListVM.totalUnreadCount : 0)
                    .tag(0)

                StatusListView(viewModel: statusVM)
                    .tabItem {
                        Label("Status", systemImage: selectedTab == 1 ? "circle.inset.filled" : "circle")
                    }
                    .tag(1)

                CallsListView()
                    .tabItem {
                        Label("Calls", systemImage: selectedTab == 2 ? "phone.fill" : "phone")
                    }
                    .tag(2)

                ContactsView(viewModel: contactsVM)
                    .tabItem {
                        Label("Contacts", systemImage: selectedTab == 3 ? "person.2.fill" : "person.2")
                    }
                    .tag(3)

                SettingsView()
                    .tabItem {
                        Label("Settings", systemImage: selectedTab == 4 ? "gearshape.fill" : "gearshape")
                    }
                    .tag(4)
            }
            .accentColor(.primaryGreen)

            // Incoming call overlay
            if callManager.callState == .ringing, let call = callManager.activeCall {
                IncomingCallView(call: call)
                    .zIndex(100)
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .openChat)) { notification in
            if let chatId = notification.object as? String {
                selectedTab = 0
                // Navigate to chat - handled via NavigationPath
            }
        }
        .sheet(isPresented: .init(
            get: { authViewModel.isNewUser },
            set: { _ in }
        )) {
            ProfileSetupView()
                .environmentObject(authViewModel)
        }
    }
}
