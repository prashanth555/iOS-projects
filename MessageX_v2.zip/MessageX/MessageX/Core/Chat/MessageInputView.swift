import SwiftUI
import PhotosUI

struct MessageInputView: View {
    @ObservedObject var viewModel: ChatViewModel
    @Binding var showAttachmentMenu: Bool
    @Binding var showGIFPicker: Bool
    @Binding var showDocumentPicker: Bool
    @FocusState private var isTextFocused: Bool

    var body: some View {
        VStack(spacing: 0) {
            Divider()

            // Reply preview bar
            if let reply = viewModel.replyingTo {
                replyBar(reply)
            }

            // Edit preview bar
            if let editing = viewModel.editingMessage {
                editBar(editing)
            }

            // Input row
            HStack(alignment: .bottom, spacing: 10) {
                // Attachment button
                Button {
                    hideKeyboard()
                    showAttachmentMenu = true
                } label: {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 30))
                        .foregroundColor(.primaryGreen)
                }

                // Text field
                HStack(alignment: .bottom) {
                    // GIF
                    Button { showGIFPicker = true } label: {
                        Text("GIF")
                            .font(.caption.bold())
                            .foregroundColor(.primaryGreen)
                            .padding(.horizontal, 6).padding(.vertical, 4)
                            .overlay(RoundedRectangle(cornerRadius: 4)
                                .stroke(Color.primaryGreen, lineWidth: 1))
                    }

                    TextField(viewModel.editingMessage != nil ? "Edit message..." : "Message",
                              text: $viewModel.messageText, axis: .vertical)
                        .lineLimit(1...6)
                        .focused($isTextFocused)
                        .onChange(of: viewModel.messageText) { _, _ in
                            viewModel.handleTyping()
                        }

                    // Emoji (placeholder)
                    Button {} label: {
                        Image(systemName: "face.smiling")
                            .foregroundColor(.secondary)
                    }
                }
                .padding(.horizontal, 12).padding(.vertical, 8)
                .background(Color(.secondarySystemBackground))
                .cornerRadius(22)

                // Send or mic
                if viewModel.messageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                    && viewModel.editingMessage == nil {
                    // Voice note button
                    Button {
                        if viewModel.isRecordingAudio {
                            viewModel.stopRecording(send: true)
                        } else {
                            viewModel.startRecording()
                        }
                    } label: {
                        Image(systemName: viewModel.isRecordingAudio ? "stop.circle.fill" : "mic.circle.fill")
                            .font(.system(size: 30))
                            .foregroundColor(viewModel.isRecordingAudio ? .red : .primaryGreen)
                    }
                    .simultaneousGesture(
                        LongPressGesture(minimumDuration: 0.3).onEnded { _ in
                            viewModel.startRecording()
                        }
                    )
                } else {
                    // Send button
                    Button {
                        if let editing = viewModel.editingMessage {
                            viewModel.editMessage(editing, newContent: viewModel.messageText)
                        } else {
                            viewModel.sendTextMessage()
                        }
                        isTextFocused = false
                    } label: {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.system(size: 30))
                            .foregroundColor(.primaryGreen)
                    }
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)

            // Recording indicator
            if viewModel.isRecordingAudio {
                HStack {
                    Circle().fill(Color.red).frame(width: 10, height: 10)
                    Text("Recording...").font(.caption).foregroundColor(.red)
                    Spacer()
                    Button { viewModel.stopRecording(send: false) } label: {
                        Text("Cancel").font(.caption).foregroundColor(.secondary)
                    }
                }
                .padding(.horizontal, 16).padding(.bottom, 8)
            }
        }
        .background(Color(.systemBackground))
    }

    private func replyBar(_ reply: Message) -> some View {
        HStack {
            Rectangle().fill(Color.primaryGreen).frame(width: 3)
            VStack(alignment: .leading, spacing: 2) {
                Text("Reply to \(reply.senderName)")
                    .font(.caption.bold()).foregroundColor(.primaryGreen)
                Text(reply.content).font(.caption).foregroundColor(.secondary).lineLimit(1)
            }
            Spacer()
            Button { viewModel.replyingTo = nil } label: {
                Image(systemName: "xmark.circle.fill").foregroundColor(.secondary)
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 6)
        .background(Color(.systemGray6))
    }

    private func editBar(_ msg: Message) -> some View {
        HStack {
            Image(systemName: "pencil").foregroundColor(.primaryGreen)
            VStack(alignment: .leading, spacing: 2) {
                Text("Editing message")
                    .font(.caption.bold()).foregroundColor(.primaryGreen)
                Text(msg.content).font(.caption).foregroundColor(.secondary).lineLimit(1)
            }
            Spacer()
            Button {
                viewModel.editingMessage = nil
                viewModel.messageText = ""
            } label: {
                Image(systemName: "xmark.circle.fill").foregroundColor(.secondary)
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 6)
        .background(Color(.systemGray6))
        .onAppear { viewModel.messageText = msg.content }
    }
}
