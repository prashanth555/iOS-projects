import SwiftUI
import AVKit
import AVFoundation

struct MessageBubbleView: View {
    let message: Message
    let showSenderName: Bool
    let onReply: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void
    let onReact: (String) -> Void
    let onImageTap: (String) -> Void

    @State private var showContextMenu = false
    @State private var isPlaying = false
    @State private var audioPlayer: AVAudioPlayer?
    @State private var audioProgress: Double = 0
    @State private var showReactionPicker = false

    private let emojis = ["❤️", "😂", "😮", "😢", "👍", "👎"]

    var body: some View {
        HStack(alignment: .bottom, spacing: 6) {
            if message.isFromCurrentUser { Spacer(minLength: 60) }

            VStack(alignment: message.isFromCurrentUser ? .trailing : .leading, spacing: 2) {
                // Reply preview
                if let reply = message.replyTo {
                    replyView(reply)
                }

                // Main bubble
                bubbleContent
                    .background(bubbleBackground)
                    .cornerRadius(18, corners: message.isFromCurrentUser
                        ? [.topLeft, .topRight, .bottomLeft]
                        : [.topLeft, .topRight, .bottomRight])
                    .onLongPressGesture { showContextMenu = true }
                    .contextMenu { contextMenuContent }

                // Reactions
                if !message.reactions.isEmpty {
                    reactionsView
                }
            }
            .padding(.horizontal, 4)

            if !message.isFromCurrentUser { Spacer(minLength: 60) }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 2)
    }

    // MARK: - Bubble Content
    @ViewBuilder
    private var bubbleContent: some View {
        VStack(alignment: .leading, spacing: 4) {
            if showSenderName && !message.isFromCurrentUser {
                Text(message.senderName)
                    .font(.caption.bold())
                    .foregroundColor(.primaryGreen)
                    .padding(.horizontal, 12).padding(.top, 8)
            }

            switch message.type {
            case .text: textBubble
            case .image: imageBubble
            case .video: videoBubble
            case .voiceNote, .audio: audioBubble
            case .gif: gifBubble
            case .document: documentBubble
            case .pdf: pdfBubble
            case .location: locationBubble
            case .callMissed, .callEnded: callBubble
            default: textBubble
            }

            // Timestamp + status
            HStack(spacing: 4) {
                if message.editedAt != nil {
                    Text("edited").font(.system(size: 10)).foregroundColor(.secondary)
                }
                Text(message.timestamp.messageTime)
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
                if message.isFromCurrentUser {
                    Image(systemName: message.statusIcon)
                        .font(.system(size: 11))
                        .foregroundColor(.blue.opacity(0.8))
                }
            }
            .padding(.horizontal, 12).padding(.bottom, 6)
        }
    }

    // MARK: - Text
    private var textBubble: some View {
        Group {
            if message.isDeleted {
                Text("🚫 This message was deleted")
                    .italic().foregroundColor(.secondary)
                    .font(.subheadline)
                    .padding(.horizontal, 12).padding(.top, 6)
            } else {
                Text(message.content)
                    .font(.body)
                    .foregroundColor(message.isFromCurrentUser ? .white : .primary)
                    .padding(.horizontal, 12).padding(.top, 6)
                    .textSelection(.enabled)
            }
        }
    }

    // MARK: - Image
    private var imageBubble: some View {
        Group {
            if let url = message.mediaData?.url {
                AsyncImage(url: URL(string: url)) { img in
                    img.resizable().scaledToFit()
                        .onTapGesture { onImageTap(url) }
                } placeholder: {
                    Rectangle()
                        .fill(Color(.systemGray5))
                        .overlay(ProgressView())
                }
                .frame(maxWidth: 260, maxHeight: 320)
                .cornerRadius(14)
            }
        }
        .padding(4)
    }

    // MARK: - Video
    private var videoBubble: some View {
        ZStack {
            if let url = message.mediaData?.url {
                AsyncImage(url: URL(string: message.mediaData?.thumbnailURL ?? url)) { img in
                    img.resizable().scaledToFit()
                } placeholder: {
                    Rectangle().fill(Color.black.opacity(0.6))
                }
                .frame(maxWidth: 260, maxHeight: 300)
                .cornerRadius(14)
                .overlay(
                    Image(systemName: "play.circle.fill")
                        .font(.system(size: 48))
                        .foregroundColor(.white.opacity(0.9))
                )
                .onTapGesture {
                    // Open video player
                }
            }
        }
        .padding(4)
    }

    // MARK: - Audio/Voice Note
    private var audioBubble: some View {
        HStack(spacing: 10) {
            Button {
                toggleAudioPlayback()
            } label: {
                Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 36))
                    .foregroundColor(message.isFromCurrentUser ? .white : .primaryGreen)
            }

            VStack(alignment: .leading, spacing: 4) {
                ProgressView(value: audioProgress)
                    .tint(message.isFromCurrentUser ? .white : .primaryGreen)
                    .frame(width: 120)

                HStack {
                    Text(message.mediaData?.duration?.durationString ?? "0:00")
                        .font(.caption2)
                        .foregroundColor(message.isFromCurrentUser ? .white.opacity(0.8) : .secondary)
                    Spacer()
                    Image(systemName: "waveform")
                        .font(.caption2)
                        .foregroundColor(message.isFromCurrentUser ? .white.opacity(0.8) : .secondary)
                }
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 8)
        .frame(width: 200)
    }

    // MARK: - GIF
    private var gifBubble: some View {
        Group {
            if let url = message.mediaData?.url {
                AsyncImage(url: URL(string: url)) { img in
                    img.resizable().scaledToFit()
                } placeholder: {
                    Rectangle().fill(Color(.systemGray5))
                        .overlay(Text("GIF").foregroundColor(.secondary))
                }
                .frame(maxWidth: 260, maxHeight: 280)
                .cornerRadius(14)
            }
        }
        .padding(4)
    }

    // MARK: - Document
    private var documentBubble: some View {
        HStack(spacing: 12) {
            Image(systemName: "doc.fill")
                .font(.system(size: 32))
                .foregroundColor(message.isFromCurrentUser ? .white : .primaryGreen)

            VStack(alignment: .leading, spacing: 2) {
                Text(message.mediaData?.fileName ?? "Document")
                    .font(.subheadline.bold())
                    .lineLimit(2)
                    .foregroundColor(message.isFromCurrentUser ? .white : .primary)
                if let size = message.mediaData?.fileSize {
                    Text(size.fileSizeString)
                        .font(.caption)
                        .foregroundColor(message.isFromCurrentUser ? .white.opacity(0.7) : .secondary)
                }
            }
        }
        .padding(12)
        .onTapGesture { openDocument() }
    }

    // MARK: - PDF
    private var pdfBubble: some View {
        HStack(spacing: 12) {
            Image(systemName: "doc.richtext.fill")
                .font(.system(size: 32))
                .foregroundColor(.red)

            VStack(alignment: .leading, spacing: 2) {
                Text(message.mediaData?.fileName ?? "PDF Document")
                    .font(.subheadline.bold()).lineLimit(2)
                    .foregroundColor(message.isFromCurrentUser ? .white : .primary)
                Text("PDF").font(.caption)
                    .foregroundColor(message.isFromCurrentUser ? .white.opacity(0.7) : .secondary)
            }
        }
        .padding(12)
        .onTapGesture { openPDF() }
    }

    // MARK: - Location
    private var locationBubble: some View {
        let parts = message.content.split(separator: ",")
        let lat = Double(parts.first ?? "0") ?? 0
        let lon = Double(parts.last ?? "0") ?? 0
        return VStack(alignment: .leading, spacing: 4) {
            Image(systemName: "map.fill")
                .font(.system(size: 24))
                .foregroundColor(message.isFromCurrentUser ? .white : .primaryGreen)
            Text("Location").font(.subheadline)
                .foregroundColor(message.isFromCurrentUser ? .white : .primary)
            Text("\(String(format: "%.4f", lat)), \(String(format: "%.4f", lon))")
                .font(.caption).foregroundColor(.secondary)
        }
        .padding(12)
        .onTapGesture { openMaps(lat: lat, lon: lon) }
    }

    // MARK: - Call
    private var callBubble: some View {
        HStack(spacing: 10) {
            Image(systemName: message.type == .callMissed ? "phone.down.fill" : "phone.fill")
                .foregroundColor(message.type == .callMissed ? .red : .primaryGreen)
            VStack(alignment: .leading) {
                Text(message.type == .callMissed ? "Missed call" : "Call ended")
                    .font(.subheadline)
                Text(message.content).font(.caption).foregroundColor(.secondary)
            }
        }
        .padding(12)
    }

    // MARK: - Reply
    private func replyView(_ reply: Message.ReplyPreview) -> some View {
        HStack(spacing: 8) {
            Rectangle()
                .fill(Color.primaryGreen)
                .frame(width: 3)
            VStack(alignment: .leading, spacing: 2) {
                Text(reply.senderName)
                    .font(.caption.bold())
                    .foregroundColor(.primaryGreen)
                Text(reply.content)
                    .font(.caption)
                    .lineLimit(2)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.horizontal, 10).padding(.vertical, 6)
        .background(Color(.systemGray5).opacity(0.5))
        .cornerRadius(8)
        .padding(.horizontal, 4).padding(.top, 4)
    }

    // MARK: - Reactions
    private var reactionsView: some View {
        HStack(spacing: 4) {
            ForEach(Array(message.reactions.keys.sorted()), id: \.self) { emoji in
                let count = message.reactions[emoji]?.count ?? 0
                HStack(spacing: 2) {
                    Text(emoji).font(.caption)
                    if count > 1 { Text("\(count)").font(.caption2) }
                }
                .padding(.horizontal, 6).padding(.vertical, 2)
                .background(Color(.systemGray5))
                .cornerRadius(10)
                .onTapGesture { onReact(emoji) }
            }
        }
    }

    // MARK: - Context Menu
    @ViewBuilder
    private var contextMenuContent: some View {
        Button { onReply() } label: { Label("Reply", systemImage: "arrowshape.turn.up.left") }
        if message.isFromCurrentUser && message.type == .text {
            Button { onEdit() } label: { Label("Edit", systemImage: "pencil") }
        }
        Button { UIPasteboard.general.string = message.content } label: {
            Label("Copy", systemImage: "doc.on.doc")
        }
        Menu("React") {
            ForEach(emojis, id: \.self) { emoji in
                Button(emoji) { onReact(emoji) }
            }
        }
        if message.isFromCurrentUser {
            Button(role: .destructive) { onDelete() } label: {
                Label("Delete", systemImage: "trash")
            }
        }
    }

    // MARK: - Bubble Background
    private var bubbleBackground: Color {
        if message.isDeleted { return Color(.systemGray5) }
        return message.isFromCurrentUser ? .primaryGreen : Color(.secondarySystemBackground)
    }

    // MARK: - Helpers
    private func toggleAudioPlayback() {
        guard let urlString = message.mediaData?.url,
              let url = URL(string: urlString) else { return }
        if isPlaying {
            audioPlayer?.pause()
            isPlaying = false
        } else {
            URLSession.shared.dataTask(with: url) { data, _, _ in
                guard let data = data else { return }
                DispatchQueue.main.async {
                    self.audioPlayer = try? AVAudioPlayer(data: data)
                    self.audioPlayer?.play()
                    self.isPlaying = true
                }
            }.resume()
        }
    }

    private func openDocument() {
        guard let urlStr = message.mediaData?.url, let url = URL(string: urlStr) else { return }
        UIApplication.shared.open(url)
    }

    private func openPDF() { openDocument() }

    private func openMaps(lat: Double, lon: Double) {
        if let url = URL(string: "maps://?ll=\(lat),\(lon)") {
            UIApplication.shared.open(url)
        }
    }
}

// MARK: - Typing Indicator
struct TypingIndicatorView: View {
    @State private var animate = false
    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<3, id: \.self) { i in
                Circle()
                    .fill(Color(.systemGray3))
                    .frame(width: 8, height: 8)
                    .scaleEffect(animate ? 1.2 : 0.8)
                    .animation(.easeInOut(duration: 0.5)
                        .repeatForever().delay(Double(i) * 0.15),
                               value: animate)
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 10)
        .background(Color(.secondarySystemBackground))
        .cornerRadius(18, corners: [.topLeft, .topRight, .bottomRight])
        .onAppear { animate = true }
    }
}
