import Foundation
import Firebase
import Combine

@MainActor
class ChatListViewModel: ObservableObject {
    @Published var chats: [Chat] = []
    @Published var filteredChats: [Chat] = []
    @Published var searchText = ""
    @Published var isLoading = true
    @Published var archivedChats: [Chat] = []
    @Published var showArchived = false

    private var listener: ListenerRegistration?
    private var cancellables = Set<AnyCancellable>()

    init() {
        setupSearchListener()
        loadChats()
    }

    private func loadChats() {
        if DemoMode.isActive {
            let demos = DemoMode.sampleChats
            chats = demos
            filteredChats = demos
            isLoading = false
            return
        }
        guard let uid = AuthService.shared.currentUserId else { return }
        listener = ChatService.shared.listenToChats(userId: uid) { [weak self] chats in
            Task { @MainActor in
                guard let self = self else { return }
                let currentUid = AuthService.shared.currentUserId ?? ""
                self.archivedChats = chats.filter { $0.archivedBy.contains(currentUid) }
                self.chats = chats
                    .filter { !$0.archivedBy.contains(currentUid) }
                    .sorted {
                        let lPin = $0.pinnedBy.contains(currentUid)
                        let rPin = $1.pinnedBy.contains(currentUid)
                        if lPin != rPin { return lPin }
                        let lTime = $0.lastMessage?.timestamp.dateValue() ?? $0.createdAt.dateValue()
                        let rTime = $1.lastMessage?.timestamp.dateValue() ?? $1.createdAt.dateValue()
                        return lTime > rTime
                    }
                self.filteredChats = self.chats
                self.isLoading = false
            }
        }
    }

    private func setupSearchListener() {
        $searchText
            .debounce(for: .milliseconds(300), scheduler: DispatchQueue.main)
            .sink { [weak self] query in
                guard let self = self else { return }
                if query.isEmpty {
                    self.filteredChats = self.chats
                } else {
                    self.filteredChats = self.chats.filter {
                        $0.displayName.localizedCaseInsensitiveContains(query) ||
                        ($0.lastMessage?.content.localizedCaseInsensitiveContains(query) ?? false)
                    }
                }
            }
            .store(in: &cancellables)
    }

    func pinChat(_ chat: Chat) async {
        guard let uid = AuthService.shared.currentUserId else { return }
        let isPinned = chat.pinnedBy.contains(uid)
        let update: [String: Any] = isPinned
            ? ["pinnedBy": FieldValue.arrayRemove([uid])]
            : ["pinnedBy": FieldValue.arrayUnion([uid])]
        try? await Firestore.firestore().collection(Constants.chatsCollection)
            .document(chat.chatId).updateData(update)
    }

    func muteChat(_ chat: Chat) async {
        guard let uid = AuthService.shared.currentUserId else { return }
        let isMuted = chat.mutedBy.contains(uid)
        let update: [String: Any] = isMuted
            ? ["mutedBy": FieldValue.arrayRemove([uid])]
            : ["mutedBy": FieldValue.arrayUnion([uid])]
        try? await Firestore.firestore().collection(Constants.chatsCollection)
            .document(chat.chatId).updateData(update)
    }

    func archiveChat(_ chat: Chat) async {
        guard let uid = AuthService.shared.currentUserId else { return }
        let isArchived = chat.archivedBy.contains(uid)
        let update: [String: Any] = isArchived
            ? ["archivedBy": FieldValue.arrayRemove([uid])]
            : ["archivedBy": FieldValue.arrayUnion([uid])]
        try? await Firestore.firestore().collection(Constants.chatsCollection)
            .document(chat.chatId).updateData(update)
    }

    func deleteChat(_ chat: Chat) async {
        try? await Firestore.firestore().collection(Constants.chatsCollection)
            .document(chat.chatId).delete()
    }

    var totalUnreadCount: Int {
        chats.reduce(0) { $0 + $1.currentUserUnreadCount }
    }

    deinit { listener?.remove() }
}
