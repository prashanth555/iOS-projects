import SwiftUI

struct ChatListView: View {
    @ObservedObject var viewModel: ChatListViewModel
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var showNewChat = false
    @State private var showContactSearch = false
    @State private var navigationPath = NavigationPath()

    var body: some View {
        NavigationStack(path: $navigationPath) {
            Group {
                if viewModel.isLoading {
                    ProgressView("Loading chats...")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if viewModel.filteredChats.isEmpty && viewModel.searchText.isEmpty {
                    EmptyChatListView(showNewChat: $showNewChat)
                } else {
                    chatList
                }
            }
            .navigationTitle("Chats")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $viewModel.searchText, prompt: "Search chats")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack(spacing: 16) {
                        Button { showNewChat = true } label: {
                            Image(systemName: "square.and.pencil")
                                .foregroundColor(.primaryGreen)
                        }
                    }
                }
            }
            .navigationDestination(for: Chat.self) { chat in
                ChatView(chat: chat)
            }
            .sheet(isPresented: $showNewChat) {
                NewChatView { chat in
                    showNewChat = false
                    navigationPath.append(chat)
                }
            }
        }
    }

    private var chatList: some View {
        List {
            if !viewModel.archivedChats.isEmpty {
                Button {
                    viewModel.showArchived.toggle()
                } label: {
                    HStack {
                        Image(systemName: "archivebox.fill")
                            .foregroundColor(.primaryGreen)
                        Text("Archived (\(viewModel.archivedChats.count))")
                            .foregroundColor(.primary)
                        Spacer()
                        Image(systemName: viewModel.showArchived ? "chevron.up" : "chevron.down")
                            .foregroundColor(.secondary)
                            .font(.caption)
                    }
                }

                if viewModel.showArchived {
                    ForEach(viewModel.archivedChats) { chat in
                        ChatRowView(chat: chat)
                            .onTapGesture { navigationPath.append(chat) }
                    }
                }
            }

            ForEach(viewModel.filteredChats) { chat in
                ChatRowView(chat: chat)
                    .onTapGesture { navigationPath.append(chat) }
                    .swipeActions(edge: .leading) {
                        Button {
                            Task { await viewModel.pinChat(chat) }
                        } label: {
                            Label(chat.isPinnedByCurrentUser ? "Unpin" : "Pin",
                                  systemImage: chat.isPinnedByCurrentUser ? "pin.slash" : "pin")
                        }
                        .tint(.orange)
                    }
                    .swipeActions(edge: .trailing) {
                        Button(role: .destructive) {
                            Task { await viewModel.archiveChat(chat) }
                        } label: {
                            Label("Archive", systemImage: "archivebox")
                        }
                        Button {
                            Task { await viewModel.muteChat(chat) }
                        } label: {
                            Label(chat.isMutedByCurrentUser ? "Unmute" : "Mute",
                                  systemImage: chat.isMutedByCurrentUser ? "bell" : "bell.slash")
                        }
                        .tint(.gray)
                    }
                    .listRowSeparator(.hidden)
                    .listRowInsets(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16))
            }
        }
        .listStyle(.plain)
    }
}

struct ChatRowView: View {
    let chat: Chat

    var body: some View {
        HStack(spacing: 14) {
            // Avatar
            ZStack(alignment: .bottomTrailing) {
                AsyncImage(url: URL(string: chat.displayImageURL ?? "")) { image in
                    image.resizable().scaledToFill()
                } placeholder: {
                    Circle()
                        .fill(Color(.systemGray4))
                        .overlay(Text(chat.displayName.prefix(1))
                            .font(.title2.bold()).foregroundColor(.white))
                }
                .frame(width: 54, height: 54)
                .clipShape(Circle())

                if chat.isOtherPersonOnline && chat.type == .individual {
                    Circle()
                        .fill(Color.primaryGreen)
                        .frame(width: 14, height: 14)
                        .overlay(Circle().stroke(Color(.systemBackground), lineWidth: 2))
                }
            }

            // Chat info
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    HStack(spacing: 4) {
                        if chat.isPinnedByCurrentUser {
                            Image(systemName: "pin.fill")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                        Text(chat.displayName)
                            .font(.headline)
                            .lineLimit(1)
                    }
                    Spacer()
                    Text(chat.lastMessage?.timestamp.chatTimestamp ?? chat.createdAt.chatTimestamp)
                        .font(.caption)
                        .foregroundColor(chat.currentUserUnreadCount > 0 ? .primaryGreen : .secondary)
                }

                HStack {
                    Group {
                        if let last = chat.lastMessage {
                            HStack(spacing: 4) {
                                if last.senderId == AuthService.shared.currentUserId {
                                    Image(systemName: "checkmark")
                                        .font(.caption2)
                                        .foregroundColor(.secondary)
                                }
                                Text(last.isDeleted ? "This message was deleted" : last.content)
                                    .italic(last.isDeleted)
                            }
                        } else {
                            Text("No messages yet").italic()
                        }
                    }
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .lineLimit(1)

                    Spacer()

                    HStack(spacing: 6) {
                        if chat.isMutedByCurrentUser {
                            Image(systemName: "bell.slash.fill")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                        if chat.currentUserUnreadCount > 0 {
                            Text("\(chat.currentUserUnreadCount)")
                                .font(.caption2.bold())
                                .foregroundColor(.white)
                                .padding(.horizontal, 6).padding(.vertical, 2)
                                .background(chat.isMutedByCurrentUser ? Color.gray : Color.primaryGreen)
                                .clipShape(Capsule())
                        }
                    }
                }
            }
        }
        .padding(.vertical, 10)
    }
}

struct EmptyChatListView: View {
    @Binding var showNewChat: Bool
    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            Image(systemName: "bubble.left.and.bubble.right")
                .font(.system(size: 72))
                .foregroundColor(.primaryGreen.opacity(0.3))
            Text("No chats yet").font(.title2.bold())
            Text("Tap the pencil icon to start a conversation.")
                .font(.subheadline).foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            Button("Start a Chat") { showNewChat = true }
                .buttonStyle(.borderedProminent)
                .tint(.primaryGreen)
            Spacer()
        }
        .padding()
    }
}
