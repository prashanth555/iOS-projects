import SwiftUI
import PhotosUI

struct ChatView: View {
    let chat: Chat
    @StateObject private var viewModel: ChatViewModel
    @EnvironmentObject var callManager: CallManager
    @State private var showMediaPicker = false
    @State private var showDocumentPicker = false
    @State private var showGIFPicker = false
    @State private var showAttachmentMenu = false
    @State private var showVideoCall = false
    @State private var showAudioCall = false
    @State private var selectedItems: [PhotosPickerItem] = []
    @State private var showImageViewer = false
    @State private var viewerImageURL: String?
    @State private var scrollProxy: ScrollViewProxy?
    @Environment(\.dismiss) var dismiss

    init(chat: Chat) {
        self.chat = chat
        _viewModel = StateObject(wrappedValue: ChatViewModel(chat: chat))
    }

    var body: some View {
        VStack(spacing: 0) {
            messagesArea
            MessageInputView(viewModel: viewModel,
                             showAttachmentMenu: $showAttachmentMenu,
                             showGIFPicker: $showGIFPicker,
                             showDocumentPicker: $showDocumentPicker)
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(false)
        .toolbar { toolbarContent }
        .sheet(isPresented: $showGIFPicker) {
            GIFPickerView { gifURL, width, height in
                viewModel.sendGIF(url: gifURL, width: width, height: height)
                showGIFPicker = false
            }
        }
        .sheet(isPresented: $showDocumentPicker) {
            DocumentPickerView { url in
                viewModel.sendDocument(url: url)
            }
        }
        .sheet(isPresented: $showVideoCall) {
            if let uid = chat.participants.first(where: { $0 != AuthService.shared.currentUserId }),
               let info = chat.participantDetails[uid] {
                VideoCallView()
                    .environmentObject(callManager)
            }
        }
        .fullScreenCover(isPresented: $showAudioCall) {
            if let uid = chat.participants.first(where: { $0 != AuthService.shared.currentUserId }),
               let info = chat.participantDetails[uid] {
                AudioCallView()
                    .environmentObject(callManager)
            }
        }
        .onChange(of: selectedItems) { _, items in
            handleSelectedPhotos(items)
        }
        .confirmationDialog("Attachment", isPresented: $showAttachmentMenu) {
            PhotosPicker(selection: $selectedItems, maxSelectionCount: 10, matching: .any(of: [.images, .videos])) {
                Label("Photo & Video", systemImage: "photo")
            }
            Button("Document") { showDocumentPicker = true }
            Button("GIF") { showGIFPicker = true }
            Button("Cancel", role: .cancel) {}
        }
        .alert("Error", isPresented: $viewModel.showError) {
            Button("OK", role: .cancel) {}
        } message: { Text(viewModel.errorMessage ?? "") }
    }

    // MARK: - Messages Area
    private var messagesArea: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 2) {
                    ForEach(viewModel.messages) { message in
                        MessageBubbleView(
                            message: message,
                            showSenderName: chat.type == .group,
                            onReply: { viewModel.replyingTo = message },
                            onEdit: { viewModel.editingMessage = message },
                            onDelete: { viewModel.deleteMessage(message) },
                            onReact: { emoji in viewModel.reactToMessage(message, emoji: emoji) },
                            onImageTap: { url in viewerImageURL = url; showImageViewer = true }
                        )
                        .id(message.messageId)
                    }

                    if !viewModel.typingUsers.isEmpty {
                        TypingIndicatorView()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 16)
                    }
                }
                .padding(.vertical, 8)
            }
            .background(Color(.systemGroupedBackground))
            .onAppear {
                scrollProxy = proxy
                scrollToBottom(proxy: proxy, animated: false)
            }
            .onChange(of: viewModel.messages) { _, _ in
                scrollToBottom(proxy: proxy)
            }
        }
        .sheet(isPresented: $showImageViewer) {
            if let url = viewerImageURL {
                ImageViewerView(imageURL: url)
            }
        }
    }

    private func scrollToBottom(proxy: ScrollViewProxy, animated: Bool = true) {
        guard let last = viewModel.messages.last else { return }
        if animated {
            withAnimation { proxy.scrollTo(last.messageId, anchor: .bottom) }
        } else {
            proxy.scrollTo(last.messageId, anchor: .bottom)
        }
    }

    // MARK: - Toolbar
    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .navigationBarLeading) {
            Button { dismiss() } label: {
                Image(systemName: "chevron.left")
                    .foregroundColor(.primaryGreen)
            }
        }
        ToolbarItem(placement: .principal) {
            Button {
                // Show chat/user info
            } label: {
                HStack(spacing: 10) {
                    AsyncImage(url: URL(string: chat.displayImageURL ?? "")) { img in
                        img.resizable().scaledToFill()
                    } placeholder: {
                        Circle().fill(Color(.systemGray4))
                            .overlay(Text(chat.displayName.prefix(1))
                                .font(.headline).foregroundColor(.white))
                    }
                    .frame(width: 36, height: 36).clipShape(Circle())

                    VStack(alignment: .leading, spacing: 2) {
                        Text(chat.displayName)
                            .font(.headline).foregroundColor(.primary)
                        if !viewModel.typingStatusText.isEmpty {
                            Text(viewModel.typingStatusText)
                                .font(.caption).foregroundColor(.primaryGreen)
                        } else if chat.isOtherPersonOnline {
                            Text("online")
                                .font(.caption).foregroundColor(.primaryGreen)
                        }
                    }
                }
            }
        }
        ToolbarItem(placement: .navigationBarTrailing) {
            HStack(spacing: 20) {
                Button {
                    startCall(type: .video)
                } label: {
                    Image(systemName: "video")
                        .foregroundColor(.primaryGreen)
                }

                Button {
                    startCall(type: .audio)
                } label: {
                    Image(systemName: "phone")
                        .foregroundColor(.primaryGreen)
                }
            }
        }
    }

    private func startCall(type: CallSession.CallType) {
        guard let uid = chat.participants.first(where: { $0 != AuthService.shared.currentUserId }),
              let info = chat.participantDetails[uid] else { return }
        var user = MXUser(uid: uid, phoneNumber: "", displayName: info.displayName)
        user.profileImageURL = info.profileImageURL
        Task {
            try? await callManager.startCall(to: user, type: type)
            if type == .video { showVideoCall = true }
            else { showAudioCall = true }
        }
    }

    private func handleSelectedPhotos(_ items: [PhotosPickerItem]) {
        for item in items {
            Task {
                if let data = try? await item.loadTransferable(type: Data.self),
                   let img = UIImage(data: data) {
                    viewModel.sendImage(img)
                }
            }
        }
        selectedItems = []
    }
}
