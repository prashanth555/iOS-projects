import SwiftUI
import PhotosUI

struct CreateGroupView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var contactsVM = ContactsViewModel()
    @State private var groupName = ""
    @State private var groupDescription = ""
    @State private var selectedMembers: Set<MXUser> = []
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var groupImage: UIImage?
    @State private var isCreating = false
    @State private var step = 1 // 1 = select members, 2 = group info

    var body: some View {
        NavigationStack {
            Group {
                if step == 1 { memberSelectionStep }
                else { groupInfoStep }
            }
            .navigationTitle(step == 1 ? "Add Participants" : "New Group")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if step == 1 {
                        Button("Cancel") { dismiss() }
                    } else {
                        Button { step = 1 } label: { Image(systemName: "chevron.left") }
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    if step == 1 {
                        Button("Next") { step = 2 }
                            .disabled(selectedMembers.isEmpty)
                            .foregroundColor(selectedMembers.isEmpty ? .secondary : .primaryGreen)
                    } else {
                        Button("Create") { createGroup() }
                            .disabled(groupName.isEmpty || isCreating)
                            .foregroundColor(groupName.isEmpty ? .secondary : .primaryGreen)
                    }
                }
            }
        }
    }

    private var memberSelectionStep: some View {
        VStack(spacing: 0) {
            if !selectedMembers.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(Array(selectedMembers)) { member in
                            VStack(spacing: 4) {
                                ZStack(alignment: .topTrailing) {
                                    AsyncImage(url: URL(string: member.profileImageURL ?? "")) { img in
                                        img.resizable().scaledToFill()
                                    } placeholder: {
                                        Circle().fill(Color(.systemGray4))
                                            .overlay(Text(member.displayName.prefix(1))
                                                .font(.headline).foregroundColor(.white))
                                    }
                                    .frame(width: 48, height: 48).clipShape(Circle())

                                    Button { selectedMembers.remove(member) } label: {
                                        Circle().fill(Color.gray)
                                            .frame(width: 18, height: 18)
                                            .overlay(Image(systemName: "xmark")
                                                .font(.system(size: 9, weight: .bold)).foregroundColor(.white))
                                    }
                                }
                                Text(member.displayName.components(separatedBy: " ").first ?? "")
                                    .font(.caption2).lineLimit(1)
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                }
                .frame(height: 70)
                .background(Color(.systemBackground))
                Divider()
            }

            List(contactsVM.contacts) { user in
                HStack {
                    ContactRow(user: user)
                    Spacer()
                    if selectedMembers.contains(user) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.primaryGreen)
                    } else {
                        Circle().stroke(Color(.systemGray4), lineWidth: 1.5)
                            .frame(width: 24, height: 24)
                    }
                }
                .contentShape(Rectangle())
                .onTapGesture {
                    if selectedMembers.contains(user) {
                        selectedMembers.remove(user)
                    } else if selectedMembers.count < Constants.maxGroupMembers - 1 {
                        selectedMembers.insert(user)
                    }
                }
            }
            .listStyle(.plain)
            .searchable(text: $contactsVM.searchText, prompt: "Search participants")
        }
    }

    private var groupInfoStep: some View {
        VStack(spacing: 24) {
            // Group photo
            PhotosPicker(selection: $selectedPhoto, matching: .images) {
                ZStack {
                    if let img = groupImage {
                        Image(uiImage: img).resizable().scaledToFill()
                    } else {
                        Circle().fill(Color(.systemGray4))
                            .overlay(Image(systemName: "camera.fill")
                                .font(.system(size: 32)).foregroundColor(.white))
                    }
                }
                .frame(width: 100, height: 100).clipShape(Circle())
                .overlay(Circle().stroke(Color.primaryGreen, lineWidth: 2))
            }
            .onChange(of: selectedPhoto) { _, item in
                Task {
                    if let data = try? await item?.loadTransferable(type: Data.self),
                       let img = UIImage(data: data) { groupImage = img }
                }
            }

            VStack(spacing: 16) {
                TextField("Group name", text: $groupName)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                TextField("Group description (optional)", text: $groupDescription)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
            }

            VStack(alignment: .leading) {
                Text("Participants: \(selectedMembers.count + 1)")
                    .font(.caption.bold())
                    .foregroundColor(.secondary)
                    .padding(.horizontal)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(Array(selectedMembers)) { member in
                            VStack(spacing: 4) {
                                AsyncImage(url: URL(string: member.profileImageURL ?? "")) { img in
                                    img.resizable().scaledToFill()
                                } placeholder: {
                                    Circle().fill(Color(.systemGray4))
                                        .overlay(Text(member.displayName.prefix(1)).foregroundColor(.white))
                                }
                                .frame(width: 48, height: 48).clipShape(Circle())
                                Text(member.displayName.components(separatedBy: " ").first ?? "")
                                    .font(.caption2).lineLimit(1)
                            }
                        }
                    }
                    .padding(.horizontal)
                }
            }

            Spacer()

            if isCreating { ProgressView("Creating group...") }
        }
        .padding(.top, 24)
    }

    private func createGroup() {
        isCreating = true
        Task {
            do {
                var imageURL: String? = nil
                if let img = groupImage, let uid = AuthService.shared.currentUserId {
                    imageURL = try? await StorageService.shared.uploadProfileImage(img, userId: "group_\(UUID().uuidString)")
                }
                let _ = try await ChatService.shared.createGroup(
                    name: groupName,
                    description: groupDescription.isEmpty ? nil : groupDescription,
                    imageURL: imageURL,
                    members: Array(selectedMembers)
                )
                dismiss()
            } catch { print("Error creating group: \(error)") }
            isCreating = false
        }
    }
}
