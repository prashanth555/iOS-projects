import Foundation
import FirebaseFirestore

struct Chat: Identifiable, Codable, Hashable {
    @DocumentID var id: String?
    var chatId: String
    var type: ChatType
    var participants: [String]
    var participantDetails: [String: ParticipantInfo]
    var lastMessage: LastMessagePreview? = nil
    var unreadCount: [String: Int]
    var createdAt: Timestamp
    var updatedAt: Timestamp
    var mutedBy: [String]
    var pinnedBy: [String]
    var archivedBy: [String]
    var disappearingMessages: DisappearingMessageSetting

    // Group-specific fields
    var groupName: String? = nil
    var groupDescription: String? = nil
    var groupImageURL: String? = nil
    var groupAdmins: [String]
    var createdBy: String? = nil

    enum ChatType: String, Codable {
        case individual
        case group
        case broadcast
    }

    struct ParticipantInfo: Codable, Hashable {
        var uid: String
        var displayName: String
        var profileImageURL: String? = nil
        var isOnline: Bool
        var lastSeen: Timestamp? = nil
        var role: ParticipantRole? = nil

        enum ParticipantRole: String, Codable {
            case admin
            case member
        }
    }

    struct LastMessagePreview: Codable, Hashable {
        var messageId: String
        var content: String
        var type: Message.MessageType
        var senderId: String
        var senderName: String
        var timestamp: Timestamp
        var isDeleted: Bool
    }

    enum DisappearingMessageSetting: String, Codable {
        case off
        case twentyFourHours = "24h"
        case sevenDays = "7d"
        case ninetyDays = "90d"
    }

    var displayName: String {
        if type == .group { return groupName ?? "Group" }
        let otherId = participants.first { $0 != AuthService.shared.currentUserId } ?? ""
        return participantDetails[otherId]?.displayName ?? "Unknown"
    }

    var displayImageURL: String? {
        if type == .group { return groupImageURL }
        let otherId = participants.first { $0 != AuthService.shared.currentUserId } ?? ""
        return participantDetails[otherId]?.profileImageURL
    }

    var isOtherPersonOnline: Bool {
        guard type == .individual else { return false }
        let otherId = participants.first { $0 != AuthService.shared.currentUserId } ?? ""
        return participantDetails[otherId]?.isOnline ?? false
    }

    var currentUserUnreadCount: Int {
        return unreadCount[AuthService.shared.currentUserId ?? ""] ?? 0
    }

    var isMutedByCurrentUser: Bool {
        guard let uid = AuthService.shared.currentUserId else { return false }
        return mutedBy.contains(uid)
    }

    var isPinnedByCurrentUser: Bool {
        guard let uid = AuthService.shared.currentUserId else { return false }
        return pinnedBy.contains(uid)
    }

    func hash(into hasher: inout Hasher) { hasher.combine(chatId) }
    static func == (lhs: Chat, rhs: Chat) -> Bool { lhs.chatId == rhs.chatId }
}
