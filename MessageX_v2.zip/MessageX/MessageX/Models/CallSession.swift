import Foundation
import FirebaseFirestore

struct CallSession: Identifiable, Codable {
    @DocumentID var id: String?
    var callId: String
    var callerId: String
    var callerName: String
    var callerProfileURL: String?
    var receiverId: String
    var receiverName: String
    var receiverProfileURL: String?
    var type: CallType
    var status: CallStatus
    var startedAt: Timestamp?
    var endedAt: Timestamp?
    var duration: Int?  // seconds
    var chatId: String

    // WebRTC Signaling
    var offer: RTCSessionData?
    var answer: RTCSessionData?
    var callerCandidates: [RTCCandidate]
    var receiverCandidates: [RTCCandidate]

    enum CallType: String, Codable {
        case audio
        case video
    }

    enum CallStatus: String, Codable {
        case calling
        case ringing
        case connected
        case ended
        case declined
        case missed
        case busy
        case failed
    }

    struct RTCSessionData: Codable {
        var sdp: String
        var type: String
    }

    struct RTCCandidate: Codable {
        var candidate: String
        var sdpMid: String?
        var sdpMLineIndex: Int32?
    }

    init(callerId: String, callerName: String, receiverId: String, receiverName: String,
         type: CallType, chatId: String) {
        self.callId = UUID().uuidString
        self.callerId = callerId
        self.callerName = callerName
        self.receiverId = receiverId
        self.receiverName = receiverName
        self.type = type
        self.status = .calling
        self.chatId = chatId
        self.callerCandidates = []
        self.receiverCandidates = []
    }

    var durationText: String {
        guard let duration = duration else { return "0:00" }
        let minutes = duration / 60
        let seconds = duration % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}

struct CallHistoryItem: Identifiable, Codable {
    var id: String { callId }
    var callId: String
    var participantId: String
    var participantName: String
    var participantImageURL: String?
    var type: CallSession.CallType
    var status: CallSession.CallStatus
    var timestamp: Timestamp
    var duration: Int?
    var isIncoming: Bool
}
