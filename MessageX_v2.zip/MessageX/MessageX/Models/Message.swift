import Foundation
import FirebaseFirestore

struct Message: Identifiable, Codable, Hashable {
    @DocumentID var id: String?
    var messageId: String
    var chatId: String
    var senderId: String
    var senderName: String
    var content: String
    var type: MessageType
    var mediaURL: String?
    var mediaData: MediaData?
    var replyTo: ReplyPreview?
    var reactions: [String: [String]] // emoji: [userId]
    var readBy: [String]
    var deliveredTo: [String]
    var timestamp: Timestamp
    var editedAt: Timestamp?
    var isDeleted: Bool
    var isForwarded: Bool
    var mentionedUsers: [String]
    var linkPreview: LinkPreview?

    enum MessageType: String, Codable {
        case text
        case image
        case video
        case audio
        case gif
        case document
        case pdf
        case location
        case contact
        case sticker
        case voiceNote
        case callMissed
        case callEnded
        case groupCreated
        case groupUpdated
        case memberAdded
        case memberRemoved
    }

    struct MediaData: Codable, Hashable {
        var url: String
        var thumbnailURL: String? = nil
        var fileName: String? = nil
        var fileSize: Int64? = nil
        var duration: Double? = nil
        var width: Int? = nil
        var height: Int? = nil
        var mimeType: String? = nil
        var localPath: String? = nil
    }

    struct ReplyPreview: Codable, Hashable {
        var messageId: String
        var senderId: String
        var senderName: String
        var content: String
        var type: MessageType
        var mediaURL: String?
    }

    struct LinkPreview: Codable, Hashable {
        var url: String
        var title: String?
        var description: String?
        var imageURL: String?
        var domain: String?
    }

    init(chatId: String, senderId: String, senderName: String, content: String, type: MessageType) {
        self.messageId = UUID().uuidString
        self.chatId = chatId
        self.senderId = senderId
        self.senderName = senderName
        self.content = content
        self.type = type
        self.reactions = [:]
        self.readBy = [senderId]
        self.deliveredTo = [senderId]
        self.timestamp = Timestamp(date: Date())
        self.isDeleted = false
        self.isForwarded = false
        self.mentionedUsers = []
    }

    var isFromCurrentUser: Bool {
        senderId == AuthService.shared.currentUserId
    }

    var statusIcon: String {
        guard isFromCurrentUser else { return "" }
        // Double blue ticks = read, double grey = delivered, single grey = sent
        if !readBy.filter({ $0 != senderId }).isEmpty { return "checkmark.message.fill" }
        if !deliveredTo.filter({ $0 != senderId }).isEmpty { return "checkmark.message" }
        return "checkmark"
    }

    func hash(into hasher: inout Hasher) { hasher.combine(messageId) }
    static func == (lhs: Message, rhs: Message) -> Bool { lhs.messageId == rhs.messageId }
}
