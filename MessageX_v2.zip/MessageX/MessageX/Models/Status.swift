import Foundation
import FirebaseFirestore

struct UserStatus: Identifiable, Codable {
    @DocumentID var id: String?
    var statusId: String
    var userId: String
    var userName: String
    var userProfileURL: String?
    var items: [StatusItem]
    var createdAt: Timestamp
    var expiresAt: Timestamp

    struct StatusItem: Identifiable, Codable, Hashable {
        var id: String
        var type: StatusType
        var content: String       // text or media URL
        var caption: String? = nil
        var backgroundColor: String? = nil
        var textColor: String? = nil
        var font: String? = nil
        var duration: Double      // display duration in seconds (default 5 for image, actual for video)
        var viewers: [String]     // user IDs who viewed
        var timestamp: Timestamp
        var privacy: Privacy

        enum StatusType: String, Codable {
            case text
            case image
            case video
            case gif
        }

        enum Privacy: String, Codable {
            case everyone
            case contacts
            case except
            case only
        }
    }

    var isViewed: Bool {
        guard let uid = AuthService.shared.currentUserId else { return false }
        return items.allSatisfy { $0.viewers.contains(uid) }
    }

    var viewerCount: Int {
        items.flatMap { $0.viewers }.filter { $0 != userId }.count
    }
}
