import Foundation
import FirebaseFirestore

struct MXUser: Identifiable, Codable, Hashable {
    @DocumentID var id: String?
    var uid: String
    var phoneNumber: String
    var username: String
    var displayName: String
    var email: String?
    var profileImageURL: String?
    var bio: String?
    var fcmToken: String?
    var isOnline: Bool
    var lastSeen: Timestamp
    var createdAt: Timestamp
    var blockedUsers: [String]
    var isTyping: Bool

    // Privacy settings
    var showLastSeen: PrivacySetting
    var showProfilePhoto: PrivacySetting
    var showStatus: PrivacySetting

    enum PrivacySetting: String, Codable, CaseIterable {
        case everyone = "everyone"
        case contacts = "contacts"
        case nobody = "nobody"
    }

    init(uid: String, phoneNumber: String, displayName: String) {
        self.uid = uid
        self.phoneNumber = phoneNumber
        self.username = phoneNumber
        self.displayName = displayName
        self.isOnline = true
        self.lastSeen = Timestamp(date: Date())
        self.createdAt = Timestamp(date: Date())
        self.blockedUsers = []
        self.isTyping = false
        self.showLastSeen = .everyone
        self.showProfilePhoto = .everyone
        self.showStatus = .everyone
    }

    var lastSeenText: String {
        let date = lastSeen.dateValue()
        let calendar = Calendar.current
        if isOnline { return "online" }
        if calendar.isDateInToday(date) {
            let formatter = DateFormatter()
            formatter.timeStyle = .short
            return "last seen today at \(formatter.string(from: date))"
        } else if calendar.isDateInYesterday(date) {
            let formatter = DateFormatter()
            formatter.timeStyle = .short
            return "last seen yesterday at \(formatter.string(from: date))"
        } else {
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            return "last seen \(formatter.string(from: date))"
        }
    }

    func hash(into hasher: inout Hasher) { hasher.combine(uid) }
    static func == (lhs: MXUser, rhs: MXUser) -> Bool { lhs.uid == rhs.uid }
}
