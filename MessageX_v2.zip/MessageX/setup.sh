#!/bin/bash
# MessageX iOS App — Mac Setup Script
set -e

echo "================================"
echo "  MessageX iOS App Setup"
echo "================================"

# Check Homebrew
if ! command -v brew &> /dev/null; then
    echo "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

# Install XcodeGen
if ! command -v xcodegen &> /dev/null; then
    echo "Installing XcodeGen..."
    brew install xcodegen
fi

# Install CocoaPods
if ! command -v pod &> /dev/null; then
    echo "Installing CocoaPods..."
    sudo gem install cocoapods
fi

# Generate Xcode project
echo "Generating Xcode project..."
xcodegen generate

# Install pods
echo "Installing CocoaPods dependencies..."
pod install

echo ""
echo "================================"
echo "  Setup Complete!"
echo "================================"
echo ""
echo "IMPORTANT: Before building:"
echo "1. Download GoogleService-Info.plist from Firebase Console"
echo "   and place it in MessageX/Resources/"
echo "2. Open MessageX.xcworkspace (NOT .xcodeproj)"
echo "3. Set your Development Team in Signing & Capabilities"
echo "4. Build and run on a real device (some features need a device)"
echo ""
echo "Opening Xcode workspace..."
open MessageX.xcworkspace
