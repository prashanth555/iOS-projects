/**
 * MessageX — Firebase Cloud Functions
 *
 * Deploy:
 *   npm install -g firebase-tools
 *   firebase login
 *   firebase init functions   (select this project)
 *   cd functions && npm install
 *   firebase deploy --only functions
 */

const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();
const db = getFirestore();

/**
 * Triggered when a new document is added to `notificationQueue`.
 * Reads the recipient's FCM token from `users/{uid}` and delivers the push.
 */
exports.sendPushNotification = onDocumentCreated(
  "notificationQueue/{docId}",
  async (event) => {
    const data = event.data.data();
    const { recipientUid, title, body, data: extraData } = data;

    if (!recipientUid) return;

    // Fetch recipient's FCM token
    const userSnap = await db.collection("users").doc(recipientUid).get();
    if (!userSnap.exists) return;
    const fcmToken = userSnap.data().fcmToken;
    if (!fcmToken) return;

    const message = {
      token: fcmToken,
      notification: { title, body },
      data: extraData || {},
      apns: {
        payload: {
          aps: { sound: "default", badge: 1 },
        },
      },
      android: {
        priority: "high",
        notification: { sound: "default" },
      },
    };

    try {
      await getMessaging().send(message);
      // Mark as processed so we don't retry
      await event.data.ref.update({ processed: true, sentAt: new Date() });
    } catch (err) {
      console.error("FCM send error:", err);
      await event.data.ref.update({ error: err.message });
    }
  }
);

/**
 * Triggered when a new message is written to any chat.
 * Sends a push to all participants who haven't muted the chat.
 */
exports.onNewMessage = onDocumentCreated(
  "chats/{chatId}/messages/{messageId}",
  async (event) => {
    const message = event.data.data();
    const { chatId } = event.params;

    if (!message || message.isDeleted) return;

    // Fetch chat metadata
    const chatSnap = await db.collection("chats").doc(chatId).get();
    if (!chatSnap.exists) return;
    const chat = chatSnap.data();

    const recipients = (chat.participants || []).filter(
      (uid) => uid !== message.senderId
    );

    const preview = messagePreview(message);

    for (const uid of recipients) {
      const isMuted = (chat.mutedBy || []).includes(uid);
      if (isMuted) continue;

      await db.collection("notificationQueue").add({
        recipientUid: uid,
        title: chat.type === "group"
          ? `${chat.groupName}: ${message.senderName}`
          : message.senderName,
        body: preview,
        data: { chatId, type: "message", messageId: message.messageId || "" },
        createdAt: new Date(),
        processed: false,
      });
    }
  }
);

/**
 * Triggered when a call document is created (caller initiates).
 * Sends a push to the receiver so the app wakes up and shows incoming call UI.
 */
exports.onIncomingCall = onDocumentCreated(
  "calls/{callId}",
  async (event) => {
    const call = event.data.data();
    if (!call || call.status !== "calling") return;

    const receiverSnap = await db.collection("users").doc(call.receiverId).get();
    if (!receiverSnap.exists) return;
    const fcmToken = receiverSnap.data().fcmToken;
    if (!fcmToken) return;

    const message = {
      token: fcmToken,
      data: {
        callId: event.params.callId,
        type: "incoming_call",
        callType: call.type,
        callerName: call.callerName,
        callerProfileURL: call.callerProfileURL || "",
      },
      apns: {
        payload: {
          aps: {
            "content-available": 1,
            sound: "default",
          },
        },
        headers: { "apns-push-type": "voip" },
      },
      android: { priority: "high" },
    };

    try {
      await getMessaging().send(message);
    } catch (err) {
      console.error("Call push error:", err);
    }
  }
);

function messagePreview(msg) {
  switch (msg.type) {
    case "image": return "📷 Photo";
    case "video": return "🎥 Video";
    case "voiceNote": return "🎤 Voice message";
    case "gif": return "GIF";
    case "pdf": return "📋 PDF";
    case "document": return `📄 ${msg.mediaData?.fileName || "Document"}`;
    case "location": return "📍 Location";
    case "audio": return "🎵 Audio";
    default: return msg.content || "";
  }
}
