# MessageX — Full-Featured iOS Messaging App

A complete WhatsApp/Telegram-style iOS messaging app built with Swift + SwiftUI.

## Features

| Feature | Status |
|---|---|
| Phone number authentication (OTP) | ✅ |
| Real-time text messaging | ✅ |
| Photo & video sharing | ✅ |
| PDF & document sharing | ✅ |
| GIF support (Giphy) | ✅ |
| Voice/audio messages | ✅ |
| Audio calls (WebRTC + CallKit) | ✅ |
| Video calls (WebRTC + CallKit) | ✅ |
| Group chats (up to 256 members) | ✅ |
| Stories/Status (24h expiry) | ✅ |
| Message reactions (emoji) | ✅ |
| Reply, edit, delete messages | ✅ |
| Read receipts (double tick) | ✅ |
| Typing indicators | ✅ |
| Online/offline status | ✅ |
| Push notifications | ✅ |
| Contact sync | ✅ |
| Pin, mute, archive chats | ✅ |
| Image viewer with zoom/pan | ✅ |
| PDF viewer | ✅ |
| Profile & privacy settings | ✅ |
| Call media encrypted (WebRTC DTLS-SRTP) | ✅ |
| Messages stored server-side (Firebase TLS in transit) | ✅ |

## Tech Stack

- **Language**: Swift 5.9
- **UI**: SwiftUI
- **Backend**: Firebase (Auth, Firestore, Storage, FCM)
- **Calling**: WebRTC (GoogleWebRTC pod) + CallKit
- **GIFs**: Giphy SDK
- **Architecture**: MVVM

## Setup on Mac

### Prerequisites
- Mac with Xcode 15+
- CocoaPods
- Node.js (for Firebase CLI, optional)

### Quick Start

```bash
# Clone or copy the project to your Mac, then:
chmod +x setup.sh
./setup.sh
```

This will:
1. Install XcodeGen (generates .xcodeproj from project.yml)
2. Install CocoaPods dependencies
3. Open the workspace

### Manual Setup

```bash
brew install xcodegen
xcodegen generate
pod install
open MessageX.xcworkspace
```

## Firebase Configuration

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a new project
3. Add an iOS app with bundle ID: `com.messagex.app`
4. Download `GoogleService-Info.plist`
5. Place it in `MessageX/Resources/`
6. Enable these Firebase services:
   - **Authentication** → Phone, Email/Password
   - **Cloud Firestore** → Start in production mode
   - **Firebase Storage** → Default bucket
   - **Cloud Messaging** → Enable

### Firestore Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth.uid == userId;
    }
    match /chats/{chatId} {
      allow read, write: if request.auth.uid in resource.data.participants;
      match /messages/{messageId} {
        allow read, write: if request.auth.uid in get(/databases/$(database)/documents/chats/$(chatId)).data.participants;
      }
    }
    match /status/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth.uid == userId;
    }
    match /calls/{callId} {
      allow read, write: if request.auth.uid == resource.data.callerId 
                        || request.auth.uid == resource.data.receiverId;
    }
  }
}
```

## Push Notifications (Cloud Functions)

Push notifications are delivered via Firebase Cloud Functions so the server key never lives in the client app.

```bash
# From the project root:
npm install -g firebase-tools
firebase login
firebase init functions   # choose your project, select JavaScript
# Replace functions/ with the ones already in this repo
cd functions && npm install
firebase deploy --only functions
```

The three deployed functions:
- **`sendPushNotification`** — triggered when the iOS app writes to `notificationQueue`, delivers via FCM Admin SDK
- **`onNewMessage`** — triggered on every new Firestore message, enqueues a push to non-muted participants
- **`onIncomingCall`** — triggered when a call document is created, sends a VoIP push to wake the receiver

## Giphy API Key

1. Go to [developers.giphy.com](https://developers.giphy.com)
2. Create a free account & app
3. Copy your API key
4. Replace `YOUR_GIPHY_API_KEY` in `GIFPickerView.swift`

## Project Structure

```
MessageX/
├── App/
│   ├── MessageXApp.swift       # @main entry point
│   └── AppDelegate.swift       # Firebase, notifications, keyboard
├── Core/
│   ├── Authentication/         # Login, OTP, profile setup
│   ├── Chat/                   # Chat list, chat view, message bubble
│   ├── Calls/                  # Audio call, video call, incoming call
│   ├── Contacts/               # Contacts list, search, new chat
│   ├── Status/                 # Stories viewer, create status
│   ├── Groups/                 # Create group
│   └── Settings/               # Profile edit, privacy, notifications
├── Models/
│   ├── User.swift
│   ├── Message.swift           # All message types
│   ├── Chat.swift
│   ├── CallSession.swift       # WebRTC call data
│   └── Status.swift
├── Services/
│   ├── AuthService.swift       # Firebase Auth
│   ├── ChatService.swift       # Firestore real-time messaging
│   ├── StorageService.swift    # Firebase Storage (all media)
│   ├── WebRTCClient.swift      # WebRTC peer connection
│   ├── CallService.swift       # CallKit + WebRTC orchestration
│   ├── NotificationService.swift
│   └── ContactsService.swift
├── Components/
│   ├── DocumentPickerView.swift
│   ├── GIFPickerView.swift
│   ├── PDFPreviewView.swift
│   ├── ImageViewerView.swift
│   └── VideoPlayerView.swift
└── Utilities/
    ├── Constants.swift
    └── Extensions.swift
```

## Running on Device

Some features require a **physical device**:
- Push notifications
- WebRTC calls (camera/microphone)
- CallKit

Set your **Development Team** in Xcode → Signing & Capabilities before building.
