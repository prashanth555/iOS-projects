#!/bin/bash
# MessageX — Build Verification Script
# Runs on Mac. Uses the pre-generated MessageX.xcodeproj (SPM, no pod install needed).
# No Firebase account required — the stub GoogleService-Info.plist is already included.
# Firebase reads credentials at runtime, not compile time, so the build succeeds.
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

step() { echo -e "\n${GREEN}▶ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠ $1${NC}"; }
fail() { echo -e "${RED}✗ $1${NC}"; exit 1; }

# ── 1. Prerequisites ────────────────────────────────────────────────
step "Checking prerequisites"
command -v xcodebuild &>/dev/null || fail "Xcode not found. Install Xcode from the App Store."

# ── 2. Find a simulator ─────────────────────────────────────────────
step "Finding iOS simulator"
SIMULATOR=$(xcrun simctl list devices available -j \
    | python3 -c "
import sys, json
d = json.load(sys.stdin)
for runtime, devices in d.get('devices', {}).items():
    for dev in devices:
        if dev.get('isAvailable') and 'iPhone' in dev.get('name',''):
            print(dev['udid']); sys.exit(0)
" 2>/dev/null || echo "")

if [ -z "$SIMULATOR" ]; then
    DEST="generic/platform=iOS Simulator"
    warn "No specific simulator found — building for generic iOS Simulator."
else
    DEST="id=$SIMULATOR"
    SIM_NAME=$(xcrun simctl list devices available -j \
        | python3 -c "
import sys, json
d = json.load(sys.stdin)
for runtime, devices in d.get('devices', {}).items():
    for dev in devices:
        if dev.get('udid') == '$SIMULATOR':
            print(dev['name']); sys.exit(0)
" 2>/dev/null || echo "$SIMULATOR")
    echo "   Using simulator: $SIM_NAME ($SIMULATOR)"
fi

# ── 3. Resolve SPM packages ─────────────────────────────────────────
step "Resolving Swift Package Manager dependencies (first run downloads ~200 MB)"
xcodebuild \
    -project MessageX.xcodeproj \
    -scheme MessageX \
    -resolvePackageDependencies \
    -clonedSourcePackagesDirPath SourcePackages \
    CODE_SIGNING_ALLOWED=NO

# ── 4. Build ─────────────────────────────────────────────────────────
step "Building MessageX for simulator (this takes 2–5 minutes first time)"
xcodebuild \
    -project MessageX.xcodeproj \
    -scheme MessageX \
    -destination "$DEST" \
    -configuration Debug \
    -clonedSourcePackagesDirPath SourcePackages \
    CODE_SIGNING_ALLOWED=NO \
    build 2>&1 | tee /tmp/messagex_build.log | tail -50

BUILD_STATUS=${PIPESTATUS[0]}

echo ""
if [ $BUILD_STATUS -eq 0 ]; then
    echo -e "${GREEN}✓ BUILD SUCCEEDED${NC}"
    echo ""
    echo "Full build log: /tmp/messagex_build.log"
    echo ""
    echo "Next steps:"
    echo "  1. Replace MessageX/Resources/GoogleService-Info.plist with the real one"
    echo "     from Firebase Console → Project settings → iOS app → Download"
    echo "  2. In Xcode → Signing & Capabilities → set your Apple Developer Team"
    echo "  3. Press ⌘R to run on the simulator (Demo Mode works without Firebase)"
    echo "  4. For GIF search: add GIPHY_API_KEY in Xcode → Edit Scheme → Env Vars"
    echo "  5. For push: cd functions && npm install && firebase deploy --only functions"
else
    echo -e "${RED}✗ BUILD FAILED — see errors above${NC}"
    echo ""
    echo "Copy the error lines and paste them back to Claude for fixes."
    echo "Full log: /tmp/messagex_build.log"
    exit 1
fi
